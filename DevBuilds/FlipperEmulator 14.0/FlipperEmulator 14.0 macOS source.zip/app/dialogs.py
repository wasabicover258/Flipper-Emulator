"""Flipper Emulator for macOS - dialogs (port of FlipConfirmDialog, FlipFeedbackDialog
and the firmware version dialog)."""
import math

from PySide6.QtCore import Qt, QRectF
from PySide6.QtGui import QFontMetrics, QImage, QPainter
from PySide6.QtWidgets import (QDialog, QLabel, QLineEdit, QPushButton, QWidget, QComboBox, QMessageBox, QFrame)

from theme import theme, scale, S, font, mono, round_path, icon
from widgets import Surface, Label, Picture, Button, Card


def _btn_style(bg, fg, border):
    return ("QPushButton { background: %s; color: %s; border: %s; border-radius: 4px; }"
            "QPushButton:disabled { background: %s; color: %s; }" % (bg, fg, border, bg, fg))


class ConfirmDialog(QDialog):
    """typed phrase confirmation (DELETE / YES / RESET)"""

    def __init__(self, parent, title, heading, body, phrase, confirm_label, tone, case_sensitive):
        super().__init__(parent)
        p = theme().cur
        accent = theme().tone(tone)
        self.setWindowTitle(title)
        self.setModal(True)
        f_body = font(9.25)
        body_h = int(math.ceil(QFontMetrics(f_body).boundingRect(0, 0, S(496), 2000, int(Qt.TextWordWrap), body).height() / scale().f)) + 6
        y = 24
        H = 24 + 34 + body_h + 14 + 24 + 34 + 26 + 54 + 22
        self.setFixedSize(S(548), S(H))
        self.setStyleSheet("QDialog { background: %s; }" % p.Bg.name())
        bar = QFrame(self)
        bar.setGeometry(0, 0, S(548), S(4))
        bar.setStyleSheet("background: %s;" % accent.name())

        def lab(t, f, color, x, yy, w, h, wrap=False):
            l = QLabel(t, self)
            l.setFont(f)
            l.setStyleSheet("color: %s; background: transparent;" % color.name())
            l.setWordWrap(wrap)
            l.setAlignment(Qt.AlignLeft | Qt.AlignTop)
            l.setTextFormat(Qt.PlainText)
            l.setGeometry(S(x), S(yy), S(w), S(h))
            return l

        lab(heading, font(16, True), p.Text, 26, y, 496, 32)
        y += 38
        lab(body, f_body, p.Muted, 26, y, 496, body_h, True)
        y += body_h + 14
        lab("Type " + phrase + " to continue", font(9.5, True), accent, 26, y, 496, 22)
        y += 26
        self.tb = QLineEdit(self)
        self.tb.setGeometry(S(26), S(y), S(496), S(30))
        self.tb.setFont(mono(12))
        self.tb.setStyleSheet("QLineEdit { background: %s; color: %s; border: 1px solid %s; padding: 2px 4px; }"
                              % (p.LogBg.name(), p.Text.name(), p.Border.name()))
        y += 40
        lab("The button becomes available when the word matches.", font(8.25), p.Faint, 26, y, 496, 20)
        y += 36
        cancel = QPushButton("Cancel", self)
        cancel.setGeometry(S(244), S(y), S(106), S(36))
        cancel.setFont(font(9.5))
        cancel.setCursor(Qt.PointingHandCursor)
        cancel.setStyleSheet(_btn_style(p.Track.name(), p.Text.name(), "1px solid " + p.Border.name()))
        cancel.clicked.connect(self.reject)
        self.ok = QPushButton(confirm_label, self)
        self.ok.setGeometry(S(362), S(y), S(160), S(36))
        self.ok.setFont(font(9.5))
        self.ok.setEnabled(False)
        self.ok.setStyleSheet(_btn_style(p.Track.name(), p.Faint.name(), "none"))
        self.ok.clicked.connect(lambda: self.accept() if self.ok.isEnabled() else None)

        def changed(t):
            match = (t == phrase) if case_sensitive else (t.lower() == phrase.lower())
            self.ok.setEnabled(match)
            self.ok.setDefault(match)
            self.ok.setStyleSheet(_btn_style(accent.name() if match else p.Track.name(),
                                             "#ffffff" if match else p.Faint.name(), "none"))
            self.ok.setCursor(Qt.PointingHandCursor if match else Qt.ArrowCursor)
        self.tb.textChanged.connect(changed)
        self.tb.returnPressed.connect(lambda: self.accept() if self.ok.isEnabled() else None)
        self.tb.setFocus()

    @staticmethod
    def confirm(parent, title, heading, body, phrase, confirm_label, tone, case_sensitive):
        d = ConfirmDialog(parent, title, heading, body, phrase, confirm_label, tone, case_sensitive)
        return d.exec() == QDialog.Accepted


class FeedbackDialog(QDialog):
    def __init__(self, parent):
        super().__init__(parent)
        self.choice = ""
        self.setWindowTitle("Community & Feedback")
        self.setModal(True)
        self.setFixedSize(S(520), S(584))
        root = Surface(self, role="Bg")
        root.setGeometry(0, 0, S(520), S(584))
        head = Surface(root, role="Card", backdrop="Bg", rounded=True, bordered=True, radius=16)
        head.place(24, 22, 472, 150)
        badge = QImage(92, 92, QImage.Format_ARGB32_Premultiplied)
        badge.fill(Qt.transparent)
        bp = QPainter(badge)
        bp.setRenderHint(QPainter.Antialiasing, True)
        bp.fillPath(round_path(QRectF(1, 1, 90, 90), 24), theme().cur.Accent)
        icon(bp, "chat", 46, 46, 48, theme().cur.OnAccent)
        bp.end()
        Picture(head, badge).place(20, 20, 46, 46)
        Label(head, "Talk to the community", 15, True, "Text").place(80, 18, 372, 30)
        Label(head, "Flipper Emulator lives from your input", 9, True, "AccentText").place(80, 48, 372, 20)
        Label(head, "Whatever is on your mind, you are welcome to write: questions, wishes, ideas, feedback, or results "
                    "you achieved thanks to the emulator. Nothing is too small, and showing what you built motivates everyone.",
              9.5, False, "Muted").place(20, 78, 432, 64)
        self._opt(root, 188, "bug", "Report a bug", "Something does not work or looks wrong.", "bug", "Danger")
        self._opt(root, 188 + 80, "idea", "Suggest an idea", "A feature, a change or a wish for the next version.", "idea", "Warn")
        self._opt(root, 188 + 160, "result", "Show what you made", "Share a success or a project that exists thanks to the emulator.", "star", "Success")
        self._opt(root, 188 + 240, "other", "Ask a question or say hello", "Questions, thanks, feedback or anything else.", "chat", "Accent")
        Label(root, "Opens GitHub in your browser. Posts there are public and need a free GitHub account. Only the version "
                    "numbers of this program and of macOS are filled in. Flipper Emulator is an unofficial project and not "
                    "affiliated with GitHub.", 8.25, False, "Faint").place(26, 508, 372, 60)
        close = Button(root, "Close", "Ghost", "", "Bg")
        close.place(520 - 24 - 84, 522, 84, 34)
        close.clicked.connect(self.reject)

    def _opt(self, parent, y, key, title, desc, ic, tone):
        c = Card(parent, title, desc, ic, tone, backdrop="Bg", key=key)
        c.place(24, y, 472, 72)
        c.action.connect(lambda k: self._pick(k))

    def _pick(self, k):
        self.choice = k
        self.accept()


class VersionDialog(QDialog):
    def __init__(self, parent, items, current):
        super().__init__(parent)
        self.setWindowTitle("Firmware version")
        self.setModal(True)
        self.setFixedSize(S(440), S(196))
        lbl = QLabel("Choose the same firmware version that your real Flipper Zero runs (qFlipper > device info). "
                     "Apps (.fap) are built for one firmware version: on a newer emulated firmware they stop with "
                     "'Outdated App'.\n\nYou can also type a version number.", self)
        lbl.setWordWrap(True)
        lbl.setFont(font(9))
        lbl.setGeometry(S(16), S(14), S(408), S(76))
        self.combo = QComboBox(self)
        self.combo.setEditable(True)
        self.combo.addItem("Latest")
        for i in items:
            self.combo.addItem(i)
        self.combo.setCurrentText(current or "Latest")
        self.combo.setGeometry(S(16), S(100), S(408), S(26))
        ok = QPushButton("OK", self)
        ok.setGeometry(S(264), S(152), S(76), S(28))
        ok.setDefault(True)
        ok.clicked.connect(self.accept)
        cancel = QPushButton("Cancel", self)
        cancel.setGeometry(S(348), S(152), S(76), S(28))
        cancel.clicked.connect(self.reject)

    @staticmethod
    def ask(parent, items, current):
        d = VersionDialog(parent, items, current)
        if d.exec() == QDialog.Accepted:
            return d.combo.currentText().strip()
        return None


def message(parent, text, title="Flipper Emulator", kind="Information"):
    icon_map = {"Warning": QMessageBox.Warning, "Error": QMessageBox.Critical}
    m = QMessageBox(icon_map.get(kind, QMessageBox.Information), title or "Flipper Emulator", text, QMessageBox.Ok, parent)
    m.exec()


def yes_no(parent, text, title, default_no=True, warning=False):
    m = QMessageBox(QMessageBox.Warning if warning else QMessageBox.Question, title, text,
                    QMessageBox.Yes | QMessageBox.No, parent)
    m.setDefaultButton(QMessageBox.No if default_no else QMessageBox.Yes)
    return m.exec() == QMessageBox.Yes
