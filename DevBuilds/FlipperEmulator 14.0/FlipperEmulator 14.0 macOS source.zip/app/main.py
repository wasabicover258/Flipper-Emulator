"""Flipper Emulator for macOS - start of the app window."""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
# The bundled Python has no certificate store of its own: use the one macOS ships.
if not os.environ.get("SSL_CERT_FILE") and os.path.isfile("/etc/ssl/cert.pem"):
    os.environ["SSL_CERT_FILE"] = "/etc/ssl/cert.pem"

from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon, QImage
from PySide6.QtWidgets import QApplication

import theme
from mainwindow import MainWindow
from controller import Controller, COLORWAYS


def res_dir():
    return os.environ.get("FLIP_RES") or os.path.dirname(HERE)


def main():
    res = res_dir()
    version = open(os.path.join(res, "VERSION")).read().strip()
    QApplication.setApplicationName("Flipper Emulator")
    QApplication.setApplicationDisplayName("Flipper Emulator")
    QApplication.setOrganizationName("Flipper Emulator")
    app = QApplication(sys.argv)
    theme.load_fonts(os.path.join(res, "fonts"))
    img = lambda n: QImage(os.path.join(res, "img", n))
    icon = QIcon(os.path.join(res, "img", "icon.png")) if os.path.exists(os.path.join(res, "img", "icon.png")) else None
    if icon:
        app.setWindowIcon(icon)
    form = MainWindow(version, img("one.png"), img("zero.png"), icon)
    form.set_feedback_logo(img("github.png"))
    form.set_colorway_thumbs([img("thumb-%s.png" % k) for k in COLORWAYS])
    ctl = Controller(form, res, version)
    form.show()
    form.layout_all()
    ctl.refresh_status(True)
    ctl.add_message("Flipper Emulator %s is ready." % version)
    import vm as vmmod
    if sys.platform == "darwin" and not vmmod.multipass() and "--shot" not in sys.argv:
        # first start after the .pkg: install Multipass right away (macOS asks for the password once)
        from PySide6.QtCore import QTimer
        QTimer.singleShot(1200, lambda: ctl.start_action("setup"))
    if "--shot" in sys.argv:
        from PySide6.QtCore import QTimer
        out = sys.argv[sys.argv.index("--shot") + 1]
        mode = sys.argv[sys.argv.index("--mode") + 1] if "--mode" in sys.argv else "one"
        def shot():
            form.grab().save(out)
            app.quit()
        if mode == "zero":
            QTimer.singleShot(300, lambda: form.set_mode(True, False))
        QTimer.singleShot(2500, shot)
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
