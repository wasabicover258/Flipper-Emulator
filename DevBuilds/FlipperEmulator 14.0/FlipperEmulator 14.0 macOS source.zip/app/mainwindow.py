"""Flipper Emulator for macOS - main window (port of FlipperMainForm in UiSource.cs).
Positions and sizes are the design units of the Windows/Linux window."""
import math
import sys

from PySide6.QtCore import Qt, Signal, QTimer
from PySide6.QtGui import QImage, QPainter, QIcon
from PySide6.QtWidgets import QWidget, QScrollArea, QFrame

from theme import theme, scale, S, font, named, round_path, icon, mix, LEFT, CENTER, RIGHT, VTOP, VCENTER, VBOTTOM
from widgets import Surface, Label, Picture, Button, Card, Segment, Badge, LogBox, Progress, Toggle

SIDE_W = 272
SYMBOL_FAMILY = "Helvetica" if sys.platform == "darwin" else "DejaVu Sans"
HOST_NAME = "Mac" if sys.platform == "darwin" else "PC"


class MainWindow(QWidget):
    action_requested = Signal(str)
    mode_changed = Signal(bool)
    firmware_changed = Signal(int)
    closing = Signal()

    NEED_ONE = 506
    NEED_ZERO = 440

    def __init__(self, version, img_one, img_zero, app_icon=None):
        super().__init__()
        self.version = version
        self.zero_mode = False
        self.busy = False
        self.z_installed = False
        self.z_running = False
        self.custom_name = ""
        self.momentum_label = "Momentum (latest)"
        self.official_label = "Official"
        self.thumbs = []
        self.interactive = []
        self.feedback_logo = None
        self.setWindowTitle("Flipper Emulator " + version)
        if app_icon is not None:
            self.setWindowIcon(app_icon)
        self.setAutoFillBackground(False)
        # as large as designed (1140 x 790), never larger than the screen
        cw, ch = 1140, 790
        try:
            from PySide6.QtGui import QGuiApplication, QCursor
            scr = QGuiApplication.screenAt(QCursor.pos()) or QGuiApplication.primaryScreen()
            wa = scr.availableGeometry()
            cw = min(cw, wa.width() - 32)
            ch = min(ch, wa.height() - 72)
        except Exception:
            pass
        cw = max(cw, int(scale().REF_W * scale().MIN_F))
        ch = max(ch, int(scale().REF_H * scale().MIN_F))
        scale().set(scale().for_size(cw, ch))
        self.resize(cw, ch)
        self.setMinimumSize(int(scale().REF_W * scale().MIN_F), int(scale().REF_H * scale().MIN_F))
        theme().changed.connect(self.update)
        self._build_side(img_one, img_zero)
        self._build_main(img_zero)
        self.set_mode(False, False)

    # ------------------------------------------------------------------ helpers
    def paintEvent(self, e):
        p = QPainter(self)
        p.fillRect(self.rect(), theme().cur.Bg)

    def L(self, parent, txt, size, semi, tone, **kw):
        return Label(parent, txt, size, semi, tone, **kw)

    def _card(self, parent, key, title, desc, ic, tone):
        c = Card(parent, title, desc, ic, tone, backdrop="Bg", key=key)
        c.action.connect(self.raise_action)
        self.interactive.append(c)
        return c

    def _btn(self, parent, txt, kind, ic, backdrop, size=9.5):
        return Button(parent, txt, kind, ic, backdrop, size)

    def raise_action(self, key):
        if self.busy and key not in ("exit", "refresh", "cancel") and not key.startswith("feedback"):
            return
        self.action_requested.emit(key)

    # ------------------------------------------------------------------ build
    def _build_side(self, img_one, img_zero):
        self.side = Surface(self, role="Side")
        self.toggle = Toggle(self.side, img_one, img_zero)
        self.toggle.toggled.connect(lambda: self.set_mode(self.toggle.is_zero, True))
        self.lblBrand = self.L(self.side, "Flipper Emulator", 16, True, "Text")
        self.lblVersion = self.L(self.side, "VERSION " + self.version, 8.5, True, "AccentText")
        self.lblTag = self.L(self.side, "Unofficial community helper", 8.5, False, "Muted")
        self.statusCard = Surface(self.side, role="Card", backdrop="Side", rounded=True, bordered=True, radius=12)
        self.lblStatusDot = self.L(self.statusCard, "●", 14, False, "Faint", family=SYMBOL_FAMILY)
        self.lblStatusTitle = self.L(self.statusCard, "STOPPED", 10.5, True, "Text")
        self.lblStatusDetail = self.L(self.statusCard, "Checking the current state...", 8.5, False, "Muted")
        self.lblLive = self.L(self.statusCard, "Updated automatically", 7.5, False, "Faint")
        self.lblSvcHead = self.L(self.side, "LOCAL SERVICES", 7.8, True, "Faint")
        self.lblSvc1 = self.L(self.side, "Flipper OS      port 8899", 8.5, False, "Muted")
        self.lblSvc2 = self.L(self.side, "File Manager    port 8898", 8.5, False, "Muted")
        self.lblSvc3 = self.L(self.side, "Everything stays on this %s." % HOST_NAME, 8, False, "Faint")
        self.lblFooter = self.L(self.side, "Unofficial community helper\nNot affiliated with Flipper Devices\nor GitHub.", 7.8, False, "Faint")
        self.btnUpdate = self._btn(self.side, "Check for updates", "Ghost", "", "Side", 8.75)
        self.btnUpdate.clicked.connect(lambda: self.raise_action("update-check"))
        self.interactive.append(self.btnUpdate)
        self.btnFeedback = self._btn(self.side, "Community & Feedback", "Primary", "chat", "Side", 9.5)
        self.btnFeedback.clicked.connect(self.show_feedback)
        self.interactive.append(self.btnFeedback)

    def _build_main(self, img_zero):
        self.main = Surface(self, role="Bg")
        self.lblTitle = self.L(self.main, "Actions", 20, True, "Text")
        self.lblSub = self.L(self.main, "", 9, False, "Muted")
        self.btnRefresh = self._btn(self.main, "Refresh", "Ghost", "", "Bg")
        self.btnRefresh.clicked.connect(lambda: self.raise_action("refresh"))
        self.btnExit = self._btn(self.main, "Exit App", "Ghost", "", "Bg")
        self.btnExit.clicked.connect(lambda: self.raise_action("exit"))

        self.pageHost = QScrollArea(self.main)
        self.pageHost.setFrameShape(QFrame.NoFrame)
        self.pageHost.setWidgetResizable(False)
        self.pageHost.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.hostInner = Surface(None, role="Bg")
        self.pageHost.setWidget(self.hostInner)
        self.pageOne = Surface(self.hostInner, role="Bg")
        self.pageZero = Surface(self.hostInner, role="Bg")
        self._style_scroll()
        theme().changed.connect(self._style_scroll)

        po = self.pageOne
        self.gStart = self.L(po, "START", 7.8, True, "Faint")
        self.gManage = self.L(po, "MANAGE", 7.8, True, "Faint")
        self.gMaint = self.L(po, "MAINTENANCE", 7.8, True, "Faint")
        self.cardReal = self._card(po, "real", "Real Flipper OS", "Boots the experimental operating system in QEMU.", "os", "Accent")
        self.cardReal.featured = True
        self.cardReal.option_text = "Open File Manager too"
        self.cardReal.option_checked = True
        self.cardPreview = self._card(po, "preview", "FlipCTL Preview", "Fast, stable browser preview. No QEMU needed.", "preview", "Accent")
        self.cardPower = self._card(po, "powermeter", "Power Meter Demo", "Opens the online Power Meter demo in your browser.", "bolt", "Success")
        self.cardStop = self._card(po, "stop", "Stop Everything", "Stops the preview, the hidden browser and QEMU.", "stop", "Warn")
        self.cardLog = self._card(po, "log", "Show Server Log", "Shows the latest preview server messages here.", "log", "Muted")
        self.cardBackup = self._card(po, "backup", "Open %s File Backup" % HOST_NAME, "Opens the folder with your File Manager backup.", "folder", "Muted")
        self.cardReset = self._card(po, "reset", "Reset Flipper OS", "Deletes the OS image and the file backup. Fresh start.", "reset", "Danger")
        self.cardReinstall = self._card(po, "reinstall", "Reinstall", "Removes everything, downloads it fresh, restores files.", "reinstall", "Warn")
        self.cardWipe = self._card(po, "wipe", "Uninstall Everything", "Removes every trace from this %s and frees the disk space." % HOST_NAME, "trash", "Danger")
        self.gLook = self.L(po, "APPEARANCE", 7.8, True, "Faint")
        self.colorStrip = Surface(po, role="Card", backdrop="Bg", rounded=True, bordered=True, radius=14)
        self.cPic = Picture(self.colorStrip)
        self.cLabel = self.L(self.colorStrip, "Flipper One colorway", 9, True, "Muted", v=VCENTER)
        self.cHint = self.L(self.colorStrip, "Used by the FlipCTL preview and the real Flipper OS.", 8.5, False, "Faint", v=VCENTER)
        self.segColor = Segment(self.colorStrip, ["Stock", "Snow", "Desert", "EVA-01", "Moss"])
        self.segColor.selected_changed.connect(lambda i: (self.update_color_pic(), self.raise_action("colorway")))
        self.interactive.append(self.segColor)

        pz = self.pageZero
        self.hero = Surface(pz, role="Card", backdrop="Bg", rounded=True, bordered=True, radius=14)
        self.zPic = Picture(self.hero, img_zero)
        self.zHeroTitle = self.L(self.hero, "Flipper Zero Emulator", 16, True, "Text")
        self.zHeroDesc = self.L(self.hero, "Runs the real Flipper Zero firmware on an emulated STM32WB55 chip (Renode).", 9, False, "Muted")
        self.zBadge = Badge(self.hero, "Checking...", "Faint", "Card")
        self.zInstall = self._btn(self.hero, "Install Emulator", "Primary", "download", "Card")
        self.zInstall.clicked.connect(lambda: self.raise_action("zero-reinstall" if self.z_installed else "zero-install"))
        self.interactive.append(self.zInstall)
        self.launcher = Surface(pz, role="Card", backdrop="Bg", rounded=True, bordered=True, radius=14)
        self.zLaunchHead = self.L(self.launcher, "LAUNCHER", 7.8, True, "Faint")
        self.zFwLabel = self.L(self.launcher, "Firmware", 9, True, "Muted", v=VCENTER)
        self.segFirmware = Segment(self.launcher, ["Official", "Momentum", "Custom file"])
        self.segFirmware.selected_changed.connect(lambda i: (self.update_zero_layout_state(), self.firmware_changed.emit(i)))
        self.interactive.append(self.segFirmware)
        self.zBrowse = self._btn(self.launcher, "Browse...", "Secondary", "", "Card", 9)
        self.zBrowse.clicked.connect(lambda: self.raise_action("zero-browse" if self.segFirmware.selected == 2 else "zero-version"))
        self.interactive.append(self.zBrowse)
        self.zCustomName = self.L(self.launcher, "", 8.75, False, "Muted", v=VCENTER, wrap=False)
        self.zStart = self._btn(self.launcher, "Start", "Primary", "play", "Card", 12)
        self.zStart.clicked.connect(lambda: self.raise_action("zero-start"))
        self.interactive.append(self.zStart)
        self.zDisplay = self._btn(self.launcher, "Open Display", "Secondary", "display", "Card")
        self.zDisplay.clicked.connect(lambda: self.raise_action("zero-show"))
        self.interactive.append(self.zDisplay)
        self.zHint = self.L(self.launcher, "In the display window:  arrows / WASD = D-pad   ·   Enter / Space = OK   ·   Backspace / Esc = Back   ·   Q = close", 8.5, False, "Faint")
        self.zMaint = self.L(pz, "MAINTENANCE", 7.8, True, "Faint")
        self.zReset = self._card(pz, "zero-reset", "Reset Flash", "Restores the bundled stock firmware in the emulated flash.", "reset", "Warn")
        self.zWipe = self._card(pz, "wipe", "Uninstall Everything", "Removes every trace from this %s and frees the disk space." % HOST_NAME, "trash", "Danger")

        self.activity = Surface(self.main, role="Card", backdrop="Bg", rounded=True, bordered=True, radius=12)
        self.lblActivity = self.L(self.activity, "ACTIVITY", 7.8, True, "Faint", v=VCENTER)
        self.lblActState = self.L(self.activity, "Ready", 8.5, False, "Faint", h=RIGHT, v=VCENTER, wrap=False)
        self.btnClear = self._btn(self.activity, "Clear", "Ghost", "", "Card", 8.5)
        self.btnClear.clicked.connect(lambda: self.log.clear())
        self.btnCancel = self._btn(self.activity, "Cancel", "Danger", "", "Card", 8.5)
        self.btnCancel.setVisible(False)
        self.btnCancel.clicked.connect(lambda: self.raise_action("cancel"))
        self.logWrap = Surface(self.activity, role="Log", backdrop="Card", rounded=True, radius=8)
        self.log = LogBox(self.logWrap)
        self.progress = Progress(self.activity)
        self.progress.setVisible(False)

    def _style_scroll(self):
        pal = theme().cur
        self.pageHost.setStyleSheet(
            "QScrollArea { background: %s; border: none; }"
            "QScrollBar:vertical { background: %s; width: 12px; margin: 0; }"
            "QScrollBar::handle:vertical { background: %s; border-radius: 5px; min-height: 30px; }"
            "QScrollBar::add-line, QScrollBar::sub-line { height: 0; }" % (pal.Bg.name(), pal.Bg.name(), pal.Border.name()))
        self.pageHost.viewport().setStyleSheet("background: %s;" % pal.Bg.name())

    # ------------------------------------------------------------------ layout
    def resizeEvent(self, e):
        self.layout_all()

    def layout_all(self):
        if self.width() < 100 or self.height() < 100:
            return
        scale().set(scale().for_size(self.width(), self.height()))
        F = scale().f
        W = int(math.floor(self.width() / F))
        H = int(math.floor(self.height() / F))
        self.side.setGeometry(0, 0, S(SIDE_W), self.height())
        self.main.setGeometry(S(SIDE_W), 0, self.width() - S(SIDE_W), self.height())
        sx, sw = 24, SIDE_W - 48
        self.toggle.place(sx, 24, sw, 72)
        self.lblBrand.place(sx, 112, sw, 28)
        self.lblVersion.place(sx, 142, sw, 18)
        self.lblTag.place(sx, 162, sw, 18)
        self.statusCard.place(sx, 200, sw, 122)
        self.lblStatusDot.place(12, 10, 24, 26)
        self.lblStatusTitle.place(40, 12, sw - 52, 22)
        self.lblStatusDetail.place(40, 38, sw - 52, 62)
        self.lblLive.place(14, 100, sw - 28, 16)
        self.lblSvcHead.place(sx, 342, sw, 16)
        self.lblSvc1.place(sx, 364, sw, 18)
        self.lblSvc2.place(sx, 384, sw, 18)
        self.lblSvc3.place(sx, 408, sw, 18)
        self.lblFooter.place(sx, H - 62, sw, 52)
        self.btnUpdate.place(sx, H - 100, sw, 32)
        self.btnFeedback.place(sx, H - 150, sw, 42)

        mw = W - SIDE_W
        px, pw = 28, mw - 2 * 28
        self.lblTitle.place(px, 20, pw - 210, 36)
        self.lblSub.place(px, 58, pw - 210, 22)
        self.btnExit.place(mw - px - 96, 26, 96, 34)
        self.btnRefresh.place(mw - px - 96 - 10 - 92, 26, 92, 34)
        act_h = 150
        act_y = H - act_h - 20
        self.activity.place(px, act_y, pw, act_h)
        ax, aw = 14, pw
        self.btnCancel.place(aw - ax - 66, 10, 66, 24)
        clear_x = aw - ax - 66 - 8 - 58 if self.btnCancel.isVisible() else aw - ax - 58
        self.btnClear.place(clear_x, 10, 58, 24)
        self.lblActivity.place(ax, 10, 120, 24)
        self.lblActState.place(160, 10, clear_x - 160 - 10, 24)
        lw, lh = aw - 2 * ax, act_h - 40 - 24
        self.logWrap.place(ax, 40, lw, lh)
        self.log.place(8, 6, lw - 16, lh - 12)
        self.progress.place(ax, act_h - 18, aw - 2 * ax, 8)

        top = 92
        host_h = act_y - top - 14
        self.pageHost.setGeometry(S(px - 4), S(top), S(pw + 8), S(host_h))
        host_w = int(math.floor(self.pageHost.viewport().width() / F)) if False else pw + 8
        self._layout_one(host_w, host_h)
        self._layout_zero(host_w, host_h)
        self._update_scroll()

    def _layout_one(self, host_w, host_h):
        scroll = host_h < self.NEED_ONE
        hh = max(host_h, self.NEED_ONE)
        ox, w = 4, host_w - 8 - (20 if scroll else 0)
        self.pageOne.place(0, 0, host_w, hh)
        gap, cw, label_h, strip_h = 14, (w - 2 * 14) // 3, 20, 76
        free = hh - (2 + 4 * (label_h + 2) + 3 * 12 + 4 + strip_h)
        h1 = min(140, max(112, int(free * 0.38)))
        h23 = min(112, max(90, (free - h1) // 2))
        y = 2
        self.gStart.place(ox + 2, y, 200, label_h); y += label_h + 2
        self.cardReal.place(ox, y, cw, h1)
        self.cardPreview.place(ox + cw + gap, y, cw, h1)
        self.cardPower.place(ox + 2 * (cw + gap), y, w - 2 * (cw + gap), h1)
        y += h1 + 12
        self.gLook.place(ox + 2, y, 200, label_h); y += label_h + 2
        self.colorStrip.place(ox, y, w, strip_h)
        self.cPic.place(16, 8, 118, strip_h - 16)
        tx = 16 + 118 + 20
        self.cLabel.place(tx, 9, 170, 20)
        self.cHint.place(tx + 176, 9, max(40, w - tx - 176 - 16), 20)
        self.segColor.place(tx, 33, max(300, min(500, w - tx - 16)), 34)
        y += strip_h + 12
        self.gManage.place(ox + 2, y, 200, label_h); y += label_h + 2
        self.cardStop.place(ox, y, cw, h23)
        self.cardLog.place(ox + cw + gap, y, cw, h23)
        self.cardBackup.place(ox + 2 * (cw + gap), y, w - 2 * (cw + gap), h23)
        y += h23 + 12
        self.gMaint.place(ox + 2, y, 200, label_h); y += label_h + 2
        self.cardReset.place(ox, y, cw, h23)
        self.cardReinstall.place(ox + cw + gap, y, cw, h23)
        self.cardWipe.place(ox + 2 * (cw + gap), y, w - 2 * (cw + gap), h23)
        y += h23 + 4
        self.pageOne.place(0, 0, host_w, max(hh, y))

    def _layout_zero(self, host_w, host_h):
        scroll = host_h < self.NEED_ZERO
        hh = max(host_h, self.NEED_ZERO)
        ox, w = 4, host_w - 8 - (20 if scroll else 0)
        self.pageZero.place(0, 0, host_w, hh)
        y, hero_h, pic_w = 2, 120, 180
        self.hero.place(ox, y, w, hero_h)
        self.zPic.place(18, 12, pic_w, hero_h - 24)
        tx = 18 + pic_w + 22
        self.zHeroTitle.place(tx, 16, w - tx - 220, 30)
        self.zBadge.setGeometry(S(tx), S(50), self.zBadge.preferred_width(), S(26))
        self.zHeroDesc.place(tx, 80, w - tx - 220, 36)
        self.zInstall.place(w - 18 - 190, (hero_h - 42) // 2, 190, 42)
        y += hero_h + 14
        launch_h = 176
        self.launcher.place(ox, y, w, launch_h)
        self.zLaunchHead.place(20, 12, 200, 16)
        self.zFwLabel.place(20, 36, 80, 38)
        seg_w = max(240, min(400, w - 20 - 90 - 230))
        self.segFirmware.place(100, 36, seg_w, 38)
        self.zBrowse.place(100 + seg_w + 12, 38, 96, 34)
        self.zCustomName.place(100 + seg_w + 12 + 96 + 10, 36, max(40, w - (100 + seg_w + 12 + 96 + 10) - 20), 38)
        self.zStart.place(20, 88, 230, 50)
        self.zDisplay.place(20 + 230 + 12, 88, 190, 50)
        self.zHint.place(20, 146, w - 40, 22)
        y += launch_h + 14
        self.zMaint.place(ox + 2, y, 200, 20); y += 22
        gap = 14
        cw = (w - gap) // 2
        self.zReset.place(ox, y, cw, 92)
        self.zWipe.place(ox + cw + gap, y, w - cw - gap, 92)
        y += 96
        self.pageZero.place(0, 0, host_w, max(hh, y))
        self.update_zero_layout_state()

    def _update_scroll(self):
        page = self.pageZero if self.zero_mode else self.pageOne
        need = S(self.NEED_ZERO if self.zero_mode else self.NEED_ONE)
        vh = self.pageHost.height()
        scroll = vh < need
        self.pageHost.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded if scroll else Qt.ScrollBarAlwaysOff)
        self.hostInner.resize(self.pageHost.width() - (12 if scroll else 0), max(vh, page.height()) if scroll else vh)

    # ------------------------------------------------------------------ behaviour
    def set_mode(self, zero, animate):
        self.zero_mode = zero
        if self.toggle.is_zero != zero:
            self.toggle.set_zero(zero, animate, False)
        self.pageOne.setVisible(not zero)
        self.pageZero.setVisible(zero)
        self.pageHost.verticalScrollBar().setValue(0)
        if zero:
            self.lblTitle.setText("Launcher")
            self.lblSub.setText("Choose a firmware and press Start. The real Flipper Zero firmware runs on your %s." % HOST_NAME)
            self.lblSvcHead.setText("EMULATOR")
            self.lblSvc1.setText("Engine         Renode")
            self.lblSvc2.setText("Firmware      " + self.firmware_name())
        else:
            self.lblTitle.setText("Actions")
            self.lblSub.setText("Choose what you want to do. Long operations keep running and report in the activity log.")
            self.lblSvcHead.setText("LOCAL SERVICES")
            self.lblSvc1.setText("Flipper OS      port 8899")
            self.lblSvc2.setText("File Manager    port 8898")
        self.lblSvc3.setText("Everything stays on this %s." % HOST_NAME)
        self.lblTag.setText("Flipper Zero emulator" if zero else "Unofficial community helper")
        theme().animate_to(zero)
        self.layout_all()
        self.update_zero_layout_state()
        self.mode_changed.emit(zero)

    def firmware_name(self):
        i = self.segFirmware.selected
        if i == 1:
            return self.momentum_label
        if i == 2:
            return self.custom_name or "Custom file"
        return self.official_label

    def update_zero_layout_state(self):
        custom = self.segFirmware.selected == 2
        self.zBrowse.setText("Browse..." if custom else "Version...")
        self.zCustomName.setText((self.custom_name or "No file chosen yet") if custom else self.firmware_name())
        if self.zero_mode:
            self.lblSvc2.setText("Firmware      " + self.firmware_name())

    def set_official_label(self, s):
        self.official_label = s
        self.update_zero_layout_state()

    def set_momentum_label(self, s):
        self.momentum_label = s
        self.update_zero_layout_state()

    def set_custom_firmware(self, name):
        self.custom_name = name or ""
        self.update_zero_layout_state()

    @property
    def firmware_index(self):
        return self.segFirmware.selected

    @firmware_index.setter
    def firmware_index(self, i):
        self.segFirmware.set_selected(i)
        self.update_zero_layout_state()

    @property
    def colorway_index(self):
        return self.segColor.selected

    @colorway_index.setter
    def colorway_index(self, i):
        self.segColor.set_selected(i)
        self.update_color_pic()

    @property
    def open_file_manager(self):
        return self.cardReal.option_checked

    def set_feedback_logo(self, img):
        self.feedback_logo = img
        self.btnFeedback.logo = img
        self.btnFeedback.update()

    def show_feedback(self):
        from dialogs import FeedbackDialog
        d = FeedbackDialog(self)
        d.exec()
        if d.choice:
            self.raise_action("feedback-" + d.choice)

    def set_colorway_thumbs(self, thumbs):
        self.thumbs = thumbs
        self.update_color_pic()

    def update_color_pic(self):
        i = self.segColor.selected
        self.cPic.img = self.thumbs[i] if 0 <= i < len(self.thumbs) else None
        self.cPic.update()

    def set_status(self, title, detail, tone):
        self.lblStatusTitle.setText(title)
        self.lblStatusDetail.setText(detail)
        self.lblStatusDot.setTone(tone)

    def set_service_lines(self, l1, l2):
        if self.zero_mode:
            return
        self.lblSvc1.setText(l1)
        self.lblSvc2.setText(l2)

    def set_zero_state(self, installed, running):
        self.z_installed, self.z_running = installed, running
        self.zInstall.setText("Reinstall Emulator" if installed else "Install Emulator")
        self.zInstall.icon_name = "reinstall" if installed else "download"
        self.zInstall.kind = "Secondary" if installed else "Primary"
        self.zInstall.update()
        self.zBadge.caption = "Running" if running else ("Installed" if installed else "Not installed")
        self.zBadge.tone = "Success" if (running or installed) else "Warn"
        self.zBadge.resize(self.zBadge.preferred_width(), self.zBadge.height())
        self.zBadge.update()
        self.zStart.setText("Stop" if running else "Start")
        self.zStart.icon_name = "stop" if running else "play"
        self.zStart.kind = "Stop" if running else "Primary"
        self.zStart.update()
        self.apply_enabled()

    def set_busy(self, b):
        self.busy = b
        self.btnCancel.setVisible(b)
        self.progress.setVisible(b)
        self.progress.marquee = b
        self.apply_enabled()
        self.layout_all()

    def apply_enabled(self):
        for c in self.interactive:
            c.setEnabled(not self.busy)
        if not self.busy:
            self.zStart.setEnabled(self.z_installed)
            self.zDisplay.setEnabled(self.z_installed and self.z_running)
            self.zReset.setEnabled(self.z_installed and not self.z_running)
            self.segFirmware.setEnabled(not self.z_running)
            self.zBrowse.setEnabled(not self.z_running)
        else:
            self.zStart.setEnabled(False)
            self.zDisplay.setEnabled(False)

    def set_activity(self, s, tone):
        self.lblActState.setText(s)
        self.lblActState.setTone(tone)

    def append_log(self, s):
        self.log.append_text(s)

    def closeEvent(self, e):
        self.closing.emit()
        super().closeEvent(e)
