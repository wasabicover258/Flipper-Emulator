"""Flipper Emulator for macOS - theme, scale, fonts and vector icons.

A 1:1 port of the custom-painted WinForms look (UiSource.cs: FlipPalette,
FlipTheme, FlipScale, FlipFonts, FlipDraw). Sizes are design units of the
1140 x 790 window; S() turns them into pixels.
"""
import math
import os
import time

from PySide6.QtCore import QObject, QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QFontDatabase, QPainter, QPainterPath, QPen, QBrush, QPolygonF


def rgb(r, g, b):
    return QColor(r, g, b)


class Palette:
    KEYS = ("Bg", "Side", "Card", "CardHover", "Border", "Text", "Muted", "Faint", "Accent", "AccentText",
            "Danger", "Success", "Warn", "Track", "LogBg", "LogText", "OnAccent")

    def __init__(self, **kw):
        for k in self.KEYS:
            setattr(self, k, kw.get(k, QColor(0, 0, 0)))

    @staticmethod
    def lerp(a, b, t):
        p = Palette()
        for k in Palette.KEYS:
            setattr(p, k, mix(getattr(a, k), getattr(b, k), t))
        return p


def mix(a, b, t):
    return QColor(int(round(a.red() + (b.red() - a.red()) * t)),
                  int(round(a.green() + (b.green() - a.green()) * t)),
                  int(round(a.blue() + (b.blue() - a.blue()) * t)))


DARK = Palette(Bg=rgb(13, 13, 13), Side=rgb(20, 20, 20), Card=rgb(28, 28, 28), CardHover=rgb(40, 40, 40),
               Border=rgb(51, 51, 51), Text=rgb(242, 242, 242), Muted=rgb(160, 160, 160), Faint=rgb(107, 107, 107),
               Accent=rgb(255, 140, 0), AccentText=rgb(255, 140, 0), Danger=rgb(229, 57, 53), Success=rgb(76, 175, 80),
               Warn=rgb(255, 170, 60), Track=rgb(38, 38, 38), LogBg=rgb(10, 10, 10), LogText=rgb(208, 208, 208),
               OnAccent=rgb(255, 255, 255))
LIGHT = Palette(Bg=rgb(244, 241, 236), Side=rgb(255, 255, 255), Card=rgb(255, 255, 255), CardHover=rgb(255, 246, 234),
                Border=rgb(226, 219, 208), Text=rgb(32, 28, 24), Muted=rgb(110, 102, 92), Faint=rgb(158, 150, 140),
                Accent=rgb(255, 122, 0), AccentText=rgb(226, 104, 0), Danger=rgb(211, 47, 47), Success=rgb(46, 157, 75),
                Warn=rgb(230, 126, 0), Track=rgb(234, 228, 219), LogBg=rgb(250, 248, 244), LogText=rgb(52, 46, 40),
                OnAccent=rgb(255, 255, 255))

TONES = ("Text", "Muted", "Faint", "Accent", "AccentText", "Danger", "Success", "Warn")


class _Theme(QObject):
    changed = Signal()
    DURATION = 0.48

    def __init__(self):
        super().__init__()
        self.cur = DARK
        self.amount = 0.0
        self._timer = None
        self._from = 0.0
        self._to = 0.0
        self._t0 = 0.0

    @property
    def animating(self):
        return self._timer is not None and self._timer.isActive()

    def tone(self, name):
        if name not in TONES:
            name = "Text"
        return getattr(self.cur, name)

    def role(self, name):
        return {"Side": self.cur.Side, "Card": self.cur.Card, "Log": self.cur.LogBg}.get(name, self.cur.Bg)

    def set_amount(self, a):
        self.amount = max(0.0, min(1.0, a))
        self.cur = Palette.lerp(DARK, LIGHT, self.amount)
        self.changed.emit()

    def animate_to(self, light):
        if self._timer is None:
            self._timer = QTimer()
            self._timer.setInterval(15)
            self._timer.timeout.connect(self._tick)
        self._from = self.amount
        self._to = 1.0 if light else 0.0
        self._t0 = time.monotonic()
        self._timer.start()

    def _tick(self):
        p = (time.monotonic() - self._t0) / self.DURATION
        if p >= 1.0:
            p = 1.0
            self._timer.stop()
        eased = 4.0 * p * p * p if p < 0.5 else 1.0 - math.pow(-2.0 * p + 2.0, 3.0) / 2.0
        self.set_amount(self._from + (self._to - self._from) * eased)


THEME = None


def theme():
    global THEME
    if THEME is None:
        THEME = _Theme()
    return THEME


class _Scale(QObject):
    changed = Signal()
    REF_W, REF_H, MIN_F = 1140, 790, 0.5

    def __init__(self):
        super().__init__()
        self.f = 1.0

    def S(self, v):
        return int(round(v * self.f))

    def for_size(self, w, h):
        f = min(1.0, min(w / float(self.REF_W), h / float(self.REF_H)))
        f = math.floor(f * 40.0) / 40.0
        return max(self.MIN_F, min(1.0, f))

    def set(self, f):
        f = max(self.MIN_F, min(1.0, f))
        if abs(f - self.f) < 0.001:
            return
        self.f = f
        self.changed.emit()


SCALE = None


def scale():
    global SCALE
    if SCALE is None:
        SCALE = _Scale()
    return SCALE


def S(v):
    return scale().S(v)


# ------------------------------------------------------------------ fonts
# WinForms sizes are points at 96 dpi; Qt on macOS counts 72 dpi per point, so
# fonts are set in pixels (pt * 4/3) to get exactly the same size everywhere.
FAMILY = "Selawik"
FAMILY_SEMI = "Selawik Semibold"
MONO_FAMILY = "Menlo"
_font_cache = {}


def load_fonts(font_dir):
    global FAMILY, FAMILY_SEMI, MONO_FAMILY
    fams = set()
    if font_dir and os.path.isdir(font_dir):
        for n in sorted(os.listdir(font_dir)):
            if n.lower().endswith((".ttf", ".otf")):
                fid = QFontDatabase.addApplicationFont(os.path.join(font_dir, n))
                if fid >= 0:
                    fams.update(QFontDatabase.applicationFontFamilies(fid))
    if "Selawik" in fams:
        FAMILY = "Selawik"
        FAMILY_SEMI = "Selawik Semibold" if "Selawik Semibold" in fams else "Selawik"
    available = set(QFontDatabase.families())
    for m in ("Menlo", "Consolas", "DejaVu Sans Mono", "Liberation Mono", "Monaco"):
        if m in available:
            MONO_FAMILY = m
            break
    _font_cache.clear()


def _px(size, unscaled=False):
    f = scale().f
    if unscaled or f >= 0.999:
        return size
    return max(4.0, round(size * f * 0.96 * 100.0) / 100.0)


def named(family, size, unscaled=False, semibold=False):
    pt = _px(size, unscaled)
    key = (family, round(pt, 2), semibold)
    f = _font_cache.get(key)
    if f is None:
        f = QFont(family)
        f.setPixelSize(max(1, int(round(pt * 96.0 / 72.0))))
        if semibold and family == FAMILY:
            f.setWeight(QFont.DemiBold)
        f.setHintingPreference(QFont.PreferNoHinting)
        f.setStyleStrategy(QFont.PreferAntialias)
        _font_cache[key] = f
    return f


def font(size, semibold=False):
    # Selawik Semibold = Selawik with weight 600 (like "Segoe UI Semibold" on Windows)
    return named(FAMILY, size, semibold=semibold)


def mono(size):
    return named(MONO_FAMILY, size)


# ------------------------------------------------------------------ drawing
def round_path(r, radius):
    p = QPainterPath()
    d = min(radius * 2.0, min(r.width(), r.height()))
    if d < 1.0:
        p.addRect(r)
        return p
    p.addRoundedRect(r, d / 2.0, d / 2.0)
    return p


def begin(painter, widget):
    """starts drawing in design units; returns the widget size in design units"""
    f = scale().f
    painter.setRenderHint(QPainter.Antialiasing, True)
    painter.setRenderHint(QPainter.TextAntialiasing, True)
    painter.setRenderHint(QPainter.SmoothPixmapTransform, True)
    if f < 0.999:
        painter.scale(f, f)
    return widget.width() / f, widget.height() / f


# TextFormatFlags of WinForms used by the window
LEFT, CENTER, RIGHT = 0, 1, 2
VTOP, VCENTER, VBOTTOM = 0, 1, 2


def text(painter, s, fnt, rect, color, h=LEFT, v=VCENTER, wrap=False, ellipsis=False):
    """rect in design units (like FlipDraw.Text); the font is already scaled"""
    f = scale().f
    painter.save()
    if f < 0.999:
        painter.scale(1.0 / f, 1.0 / f)
        rect = QRectF(rect.x() * f, rect.y() * f, rect.width() * f, rect.height() * f)
    painter.setFont(fnt)
    painter.setPen(color)
    flags = {LEFT: Qt.AlignLeft, CENTER: Qt.AlignHCenter, RIGHT: Qt.AlignRight}[h]
    flags |= {VTOP: Qt.AlignTop, VCENTER: Qt.AlignVCenter, VBOTTOM: Qt.AlignBottom}[v]
    if wrap:
        flags |= Qt.TextWordWrap
    if ellipsis and not wrap:
        s = painter.fontMetrics().elidedText(s, Qt.ElideRight, int(rect.width()))
    painter.drawText(rect, int(flags), s)
    painter.restore()


def measure(s, fnt):
    """size of a text in design units"""
    from PySide6.QtGui import QFontMetrics
    fm = QFontMetrics(fnt)
    f = scale().f
    w = fm.horizontalAdvance(s)
    return int(math.ceil(w / f)), int(math.ceil(fm.height() / f))


def _poly(pts):
    return QPolygonF([QPointF(x, y) for x, y in pts])


def _arc(painter, x, y, w, h, start, sweep):
    # GDI: clockwise degrees from 3 o'clock; Qt: counter-clockwise 1/16 degrees
    painter.drawArc(QRectF(x, y, w, h), int(round(-start * 16)), int(round(-sweep * 16)))


def icon(painter, name, cx, cy, size, color):
    """Vector icons, drawn centred on (cx, cy) inside a square of the given size."""
    painter.save()
    painter.setRenderHint(QPainter.Antialiasing, True)
    s = float(size)
    x0 = cx - s / 2.0
    y0 = cy - s / 2.0
    lw = max(1.6, s / 11.0)
    pen = QPen(color, lw)
    pen.setCapStyle(Qt.RoundCap)
    pen.setJoinStyle(Qt.RoundJoin)
    br = QBrush(color)
    X = lambda t: x0 + s * t
    Y = lambda t: y0 + s * t

    def line(a, b, c, d):
        painter.setPen(pen)
        painter.setBrush(Qt.NoBrush)
        painter.drawLine(QPointF(X(a), Y(b)), QPointF(X(c), Y(d)))

    def fillpoly(pts):
        painter.setPen(Qt.NoPen)
        painter.setBrush(br)
        painter.drawPolygon(_poly([(X(a), Y(b)) for a, b in pts]))

    def drawpoly(pts):
        painter.setPen(pen)
        painter.setBrush(Qt.NoBrush)
        painter.drawPolygon(_poly([(X(a), Y(b)) for a, b in pts]))

    def drawpath(p):
        painter.setPen(pen)
        painter.setBrush(Qt.NoBrush)
        painter.drawPath(p)

    def fillpath(p):
        painter.setPen(Qt.NoPen)
        painter.setBrush(br)
        painter.drawPath(p)

    def fillell(x, y, w, h):
        painter.setPen(Qt.NoPen)
        painter.setBrush(br)
        painter.drawEllipse(QRectF(x, y, w, h))

    def drawell(x, y, w, h):
        painter.setPen(pen)
        painter.setBrush(Qt.NoBrush)
        painter.drawEllipse(QRectF(x, y, w, h))

    def arc(x, y, w, h, a, sw):
        painter.setPen(pen)
        painter.setBrush(Qt.NoBrush)
        _arc(painter, x, y, w, h, a, sw)

    if name == "play":
        fillpoly([(0.22, 0.12), (0.88, 0.5), (0.22, 0.88)])
    elif name == "stop":
        fillpath(round_path(QRectF(X(0.18), Y(0.18), s * 0.64, s * 0.64), s * 0.1))
    elif name == "bolt":
        fillpoly([(0.58, 0.04), (0.2, 0.56), (0.46, 0.56), (0.38, 0.96), (0.8, 0.4), (0.54, 0.4)])
    elif name == "os":
        drawpath(round_path(QRectF(X(0.2), Y(0.2), s * 0.6, s * 0.6), s * 0.1))
        painter.drawRect(QRectF(X(0.38), Y(0.38), s * 0.24, s * 0.24))
        for i in range(3):
            t = 0.34 + i * 0.16
            line(t, 0.06, t, 0.2)
            line(t, 0.8, t, 0.94)
            line(0.06, t, 0.2, t)
            line(0.8, t, 0.94, t)
    elif name == "preview":
        drawpath(round_path(QRectF(X(0.08), Y(0.18), s * 0.84, s * 0.64), s * 0.1))
        line(0.08, 0.36, 0.92, 0.36)
        fillell(X(0.17), Y(0.255), s * 0.06, s * 0.06)
        fillell(X(0.28), Y(0.255), s * 0.06, s * 0.06)
    elif name == "folder":
        drawpoly([(0.08, 0.24), (0.38, 0.24), (0.48, 0.36), (0.92, 0.36), (0.92, 0.8), (0.08, 0.8)])
    elif name == "log":
        line(0.14, 0.28, 0.86, 0.28)
        line(0.14, 0.5, 0.7, 0.5)
        line(0.14, 0.72, 0.78, 0.72)
    elif name == "reset":
        arc(X(0.16), Y(0.16), s * 0.68, s * 0.68, -40, -280)
        fillpoly([(0.18, 0.12), (0.18, 0.46), (0.46, 0.3)])
    elif name == "reinstall":
        arc(X(0.16), Y(0.16), s * 0.68, s * 0.68, 140, 280)
        fillpoly([(0.82, 0.88), (0.82, 0.54), (0.54, 0.7)])
    elif name == "trash":
        line(0.14, 0.26, 0.86, 0.26)
        line(0.38, 0.26, 0.38, 0.14)
        line(0.38, 0.14, 0.62, 0.14)
        line(0.62, 0.14, 0.62, 0.26)
        drawpoly([(0.22, 0.26), (0.28, 0.88), (0.72, 0.88), (0.78, 0.26)])
        line(0.42, 0.42, 0.43, 0.72)
        line(0.58, 0.42, 0.57, 0.72)
    elif name == "download":
        line(0.5, 0.12, 0.5, 0.6)
        line(0.3, 0.42, 0.5, 0.62)
        line(0.7, 0.42, 0.5, 0.62)
        line(0.14, 0.86, 0.86, 0.86)
    elif name == "display":
        drawpath(round_path(QRectF(X(0.1), Y(0.16), s * 0.8, s * 0.54), s * 0.08))
        line(0.5, 0.7, 0.5, 0.84)
        line(0.3, 0.86, 0.7, 0.86)
    elif name == "check":
        line(0.2, 0.54, 0.42, 0.74)
        line(0.42, 0.74, 0.82, 0.28)
    elif name == "chat":
        drawpath(round_path(QRectF(X(0.08), Y(0.14), s * 0.84, s * 0.56), s * 0.14))
        line(0.3, 0.7, 0.26, 0.9)
        line(0.26, 0.9, 0.5, 0.7)
        for i in range(3):
            fillell(X(0.3 + 0.2 * i) - s * 0.05, Y(0.42) - s * 0.05, s * 0.1, s * 0.1)
    elif name == "bug":
        fillell(X(0.38), Y(0.08), s * 0.24, s * 0.2)
        drawell(X(0.3), Y(0.3), s * 0.4, s * 0.56)
        line(0.5, 0.32, 0.5, 0.86)
        line(0.3, 0.45, 0.1, 0.36)
        line(0.3, 0.58, 0.08, 0.58)
        line(0.32, 0.74, 0.12, 0.84)
        line(0.7, 0.45, 0.9, 0.36)
        line(0.7, 0.58, 0.92, 0.58)
        line(0.68, 0.74, 0.88, 0.84)
    elif name == "idea":
        drawell(X(0.22), Y(0.06), s * 0.56, s * 0.56)
        line(0.36, 0.56, 0.38, 0.74)
        line(0.64, 0.56, 0.62, 0.74)
        line(0.36, 0.8, 0.64, 0.8)
        line(0.42, 0.92, 0.58, 0.92)
    elif name == "star":
        pts = []
        for i in range(10):
            a = -math.pi / 2 + i * math.pi / 5
            rr = s * 0.46 if i % 2 == 0 else s * 0.2
            pts.append((cx + math.cos(a) * rr, y0 + s * 0.54 + math.sin(a) * rr))
        painter.setPen(Qt.NoPen)
        painter.setBrush(br)
        painter.drawPolygon(_poly(pts))
    elif name == "cross":
        line(0.24, 0.24, 0.76, 0.76)
        line(0.76, 0.24, 0.24, 0.76)
    painter.restore()
