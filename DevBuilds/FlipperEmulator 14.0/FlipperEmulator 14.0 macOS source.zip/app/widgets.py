"""Flipper Emulator for macOS - custom painted controls (port of UiSource.cs)."""
import math
import time

from PySide6.QtCore import QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QLinearGradient, QPainter, QPen, QBrush, QTextOption
from PySide6.QtWidgets import QPlainTextEdit, QWidget, QFrame

from theme import (theme, scale, S, font, mono, named, round_path, begin, text, measure, icon, mix,
                   LEFT, CENTER, RIGHT, VTOP, VCENTER, VBOTTOM)

WHITE = QColor(255, 255, 255)
BLACK = QColor(0, 0, 0)


class FlipWidget(QWidget):
    """repaints on theme changes; geometry is given in design units with place()"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_OpaquePaintEvent, False)
        self.design = (0, 0, 0, 0)
        theme().changed.connect(self.update)

    def place(self, x, y, w, h):
        self.design = (x, y, w, h)
        self.setGeometry(S(x), S(y), max(1, S(w)), max(1, S(h)))

    def replace(self):
        if self.design[2] > 0:
            self.place(*self.design)


class Surface(FlipWidget):
    def __init__(self, parent=None, role="Bg", backdrop="Bg", rounded=False, bordered=False, radius=12):
        super().__init__(parent)
        self.role, self.backdrop, self.rounded, self.bordered, self.radius = role, backdrop, rounded, bordered, radius

    def paintEvent(self, e):
        p = QPainter(self)
        pal = theme().cur
        if not self.rounded:
            p.fillRect(self.rect(), theme().role(self.role))
            return
        p.fillRect(self.rect(), theme().role(self.backdrop))
        p.setRenderHint(QPainter.Antialiasing, True)
        r = QRectF(0.5, 0.5, self.width() - 2, self.height() - 2)
        path = round_path(r, self.radius * scale().f)
        p.fillPath(path, theme().role(self.role))
        if self.bordered:
            p.setPen(QPen(pal.Border, 1.0))
            p.drawPath(path)


class Label(FlipWidget):
    """WinForms Label: top-left text, wraps inside its box"""

    def __init__(self, parent=None, txt="", size=9.0, semibold=False, tone="Text", family=None,
                 h=LEFT, v=VTOP, wrap=True):
        super().__init__(parent)
        self._text = txt
        self.size, self.semibold, self.tone, self.family = size, semibold, tone, family
        self.h, self.v, self.wrap = h, v, wrap
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)

    def setText(self, t):
        if t != self._text:
            self._text = t
            self.update()

    def text(self):
        return self._text

    def setTone(self, t):
        self.tone = t
        self.update()

    def paintEvent(self, e):
        p = QPainter(self)
        f = named(self.family, self.size) if self.family else font(self.size, self.semibold)
        p.setFont(f)
        p.setPen(theme().tone(self.tone))
        p.setRenderHint(QPainter.TextAntialiasing, True)
        flags = {LEFT: Qt.AlignLeft, CENTER: Qt.AlignHCenter, RIGHT: Qt.AlignRight}[self.h]
        flags |= {VTOP: Qt.AlignTop, VCENTER: Qt.AlignVCenter, VBOTTOM: Qt.AlignBottom}[self.v]
        if self.wrap:
            flags |= Qt.TextWordWrap
        p.drawText(self.rect(), int(flags), self._text)


class Picture(FlipWidget):
    def __init__(self, parent=None, img=None):
        super().__init__(parent)
        self.img = img
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)

    def paintEvent(self, e):
        if self.img is None or self.img.isNull():
            return
        p = QPainter(self)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)
        iw, ih = self.img.width(), self.img.height()
        sc = min(self.width() / float(iw), self.height() / float(ih))
        w, h = iw * sc, ih * sc
        p.drawImage(QRectF((self.width() - w) / 2.0, (self.height() - h) / 2.0, w, h), self.img)


class Clickable(FlipWidget):
    clicked = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.hover = False
        self.down = False
        self.setCursor(Qt.PointingHandCursor)
        self.setMouseTracking(True)

    def enterEvent(self, e):
        self.hover = True
        self.update()

    def leaveEvent(self, e):
        self.hover = False
        self.down = False
        self.update()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.down = True
            self.update()

    def mouseReleaseEvent(self, e):
        was = self.down
        self.down = False
        self.update()
        if was and e.button() == Qt.LeftButton and self.isEnabled() and self.rect().contains(e.position().toPoint()):
            self.on_click(e)

    def on_click(self, e):
        self.clicked.emit()

    def changeEvent(self, e):
        if e.type() == e.Type.EnabledChange:
            self.setCursor(Qt.PointingHandCursor if self.isEnabled() else Qt.ArrowCursor)
            if not self.isEnabled():
                self.hover = False
            self.update()
        super().changeEvent(e)


class Button(Clickable):
    def __init__(self, parent=None, txt="", kind="Secondary", icon_name="", backdrop="Card", font_size=9.5, logo=None):
        super().__init__(parent)
        self._text = txt
        self.kind, self.icon_name, self.backdrop, self.font_size, self.logo = kind, icon_name, backdrop, font_size, logo

    def setText(self, t):
        self._text = t
        self.update()

    def text(self):
        return self._text

    def paintEvent(self, e):
        p = QPainter(self)
        pal = theme().cur
        p.fillRect(self.rect(), theme().role(self.backdrop))
        hot = self.hover and self.isEnabled()
        k = self.kind
        if k == "Primary":
            fill = mix(pal.Accent, WHITE, 0.12) if hot else pal.Accent
            if self.down:
                fill = mix(pal.Accent, BLACK, 0.12)
            border, tc = fill, pal.OnAccent
        elif k == "Stop":
            fill = mix(pal.Danger, WHITE, 0.1) if hot else pal.Danger
            if self.down:
                fill = mix(pal.Danger, BLACK, 0.12)
            border, tc = fill, WHITE
        elif k == "Danger":
            fill = pal.Danger if hot else mix(pal.Card, pal.Danger, 0.08)
            border, tc = pal.Danger, (WHITE if hot else pal.Danger)
        elif k == "Ghost":
            fill = pal.CardHover if hot else theme().role(self.backdrop)
            border, tc = pal.Border, (pal.Text if hot else pal.Muted)
        else:
            fill = pal.CardHover if hot else pal.Track
            border, tc = (pal.Accent if hot else pal.Border), pal.Text
        if not self.isEnabled():
            fill = mix(pal.Track, theme().role(self.backdrop), 0.35)
            border, tc = pal.Border, pal.Faint
        px = 1.0 / scale().f
        W, H = begin(p, self)
        path = round_path(QRectF(0.5 * px, 0.5 * px, W - 2 * px, H - 2 * px), 9)
        p.fillPath(path, fill)
        p.setPen(QPen(border, px))
        p.drawPath(path)
        f = font(self.font_size, True)
        tw, th = measure(self._text, f)
        has_logo = self.logo is not None and not self.logo.isNull()
        has_icon = (not has_logo) and bool(self.icon_name)
        isz = min(H * 0.5, 22.0)
        if has_logo:
            isz = min(H * 0.56, 24.0)
        total = tw + ((isz + 8.0) if (has_icon or has_logo) else 0.0)
        x = (W - total) / 2.0
        if has_logo:
            p.drawImage(QRectF(x, (H - isz) / 2.0, isz, isz), self.logo)
            x += isz + 8.0
        elif has_icon:
            icon(p, self.icon_name, x + isz / 2.0, H / 2.0, isz, tc)
            x += isz + 8.0
        text(p, self._text, f, QRectF(int(x), 0, tw + 4, math.ceil(H)), tc, LEFT, VCENTER)


class Card(Clickable):
    """Action card: icon, title, description and an optional checkbox row."""
    action = Signal(str)
    option_toggled = Signal()

    def __init__(self, parent=None, title="", desc="", icon_name="", tone="Accent", featured=False,
                 option_text="", option_checked=False, backdrop="Bg", key=""):
        super().__init__(parent)
        self.title, self.desc, self.icon_name, self.tone = title, desc, icon_name, tone
        self.featured, self.option_text, self.option_checked = featured, option_text, option_checked
        self.backdrop, self.key = backdrop, key
        self.over_option = False

    def _option_rect(self):
        if not self.option_text:
            return None
        tw, th = measure(self.option_text, font(8.75))
        return QRectF(14, round(self.height() / scale().f) - 38, 16 + 8 + tw + 12 + 14, 28)

    def _over_option(self, pos):
        r = self._option_rect()
        return r is not None and r.contains(QPointF(pos.x() / scale().f, pos.y() / scale().f))

    def mouseMoveEvent(self, e):
        o = self._over_option(e.position())
        if o != self.over_option:
            self.over_option = o
            self.update()

    def leaveEvent(self, e):
        self.over_option = False
        super().leaveEvent(e)

    def on_click(self, e):
        if self._over_option(e.position()):
            self.option_checked = not self.option_checked
            self.update()
            self.option_toggled.emit()
            return
        self.action.emit(self.key)
        self.clicked.emit()

    def paintEvent(self, e):
        p = QPainter(self)
        pal = theme().cur
        p.fillRect(self.rect(), theme().role(self.backdrop))
        tone = theme().tone(self.tone)
        en = self.isEnabled()
        hot = self.hover and en
        fill = pal.CardHover if hot else pal.Card
        if self.featured:
            fill = mix(fill, pal.Accent, 0.10 if hot else 0.06)
        if self.down and en:
            fill = mix(fill, BLACK, 0.06)
        border = tone if hot else (mix(pal.Border, pal.Accent, 0.55) if self.featured else pal.Border)
        px = 1.0 / scale().f
        W, H = begin(p, self)
        Wd, Hd = int(round(W)), int(round(H))
        path = round_path(QRectF(0.5 * px, 0.5 * px, W - 2 * px, H - 2 * px), 12)
        p.fillPath(path, fill)
        p.setPen(QPen(border, (1.5 if self.featured else 1.0) * px))
        p.drawPath(path)
        shown = tone if en else pal.Faint
        ib = 42.0
        p.fillPath(round_path(QRectF(16, 16, ib, ib), 11), mix(fill, shown, 0.16 if en else 0.06))
        if self.icon_name:
            icon(p, self.icon_name, 16 + ib / 2, 16 + ib / 2, 22, shown)
        title_c = pal.Text if en else pal.Faint
        desc_c = pal.Muted if en else pal.Faint
        tx = 16 + int(ib) + 14
        text(p, self.title, font(11.5, True), QRectF(tx, 15, Wd - tx - 34, 24), title_c, LEFT, VCENTER, ellipsis=True)
        has_opt = bool(self.option_text)
        desc_h = Hd - 44 - (40 if has_opt else 14)
        text(p, self.desc, font(8.75), QRectF(tx, 42, Wd - tx - 16, max(20, desc_h + 6)), desc_c, LEFT, VTOP, wrap=True)
        cp = QPen(tone if hot else pal.Faint, 1.8)
        cp.setCapStyle(Qt.RoundCap)
        p.setPen(cp)
        cx, cy = Wd - 20.0, 27.0
        p.drawLine(QPointF(cx - 3, cy - 5), QPointF(cx + 2, cy))
        p.drawLine(QPointF(cx + 2, cy), QPointF(cx - 3, cy + 5))
        if has_opt:
            r = self._option_rect()
            oh = self.over_option and en
            op = round_path(r, 8)
            p.fillPath(op, mix(fill, tone, 0.14) if oh else mix(fill, pal.Track, 0.8))
            p.setPen(QPen(tone if oh else pal.Border, px))
            p.drawPath(op)
            box = QRectF(r.x() + 8, r.y() + 6, 16, 16)
            bx = round_path(box, 4)
            if self.option_checked:
                p.fillPath(bx, pal.Accent if en else pal.Faint)
                icon(p, "check", box.x() + 8, box.y() + 8, 14, WHITE)
            else:
                p.setPen(QPen(pal.Muted, 1.4))
                p.setBrush(Qt.NoBrush)
                p.drawPath(bx)
            text(p, self.option_text, font(8.75), QRectF(r.x() + 32, r.y(), r.width() - 34, r.height()),
                 pal.Text if en else pal.Faint, LEFT, VCENTER)


class Segment(FlipWidget):
    selected_changed = Signal(int)

    def __init__(self, parent=None, items=None):
        super().__init__(parent)
        self.items = list(items or [])
        self._sel = 0
        self.hover_index = -1
        self.setCursor(Qt.PointingHandCursor)
        self.setMouseTracking(True)

    @property
    def selected(self):
        return self._sel

    def set_selected(self, i):
        if i != self._sel:
            self._sel = i
            self.update()

    def _hit(self, x):
        if not self.items:
            return -1
        i = int((x - 3) / ((self.width() - 6) / float(len(self.items))))
        return max(0, min(len(self.items) - 1, i))

    def mouseMoveEvent(self, e):
        h = self._hit(e.position().x())
        if h != self.hover_index:
            self.hover_index = h
            self.update()

    def leaveEvent(self, e):
        self.hover_index = -1
        self.update()

    def mouseReleaseEvent(self, e):
        if not self.isEnabled() or e.button() != Qt.LeftButton:
            return
        i = self._hit(e.position().x())
        if i < 0 or i == self._sel:
            return
        self._sel = i
        self.update()
        self.selected_changed.emit(i)

    def paintEvent(self, e):
        p = QPainter(self)
        pal = theme().cur
        p.fillRect(self.rect(), pal.Card)
        p.setRenderHint(QPainter.Antialiasing, True)
        W, H = self.width(), self.height()
        tp = round_path(QRectF(0.5, 0.5, W - 2, H - 2), H / 2.0)
        p.fillPath(tp, pal.Track)
        p.setPen(QPen(pal.Border, 1.0))
        p.drawPath(tp)
        if not self.items:
            return
        en = self.isEnabled()
        sw = (W - 6) / float(len(self.items))
        f = font(9.25, True)
        for i, it in enumerate(self.items):
            seg = QRectF(3 + i * sw, 3, sw, H - 6)
            sel = i == self._sel
            if sel:
                p.fillPath(round_path(seg, (H - 6) / 2.0), pal.Accent if en else pal.Faint)
            c = pal.OnAccent if sel else (pal.Text if (i == self.hover_index and en) else pal.Muted)
            if not en and not sel:
                c = pal.Faint
            p.setFont(f)
            p.setPen(c)
            p.drawText(QRectF(int(seg.x()), int(seg.y()), int(seg.width()), int(seg.height())), int(Qt.AlignCenter),
                       p.fontMetrics().elidedText(it, Qt.ElideRight, int(seg.width())))


class Badge(FlipWidget):
    def __init__(self, parent=None, caption="", tone="Faint", backdrop="Card"):
        super().__init__(parent)
        self.caption, self.tone, self.backdrop = caption, tone, backdrop

    def preferred_width(self):
        from PySide6.QtGui import QFontMetrics
        return QFontMetrics(font(8.5, True)).horizontalAdvance(self.caption) + S(38)

    def paintEvent(self, e):
        p = QPainter(self)
        p.fillRect(self.rect(), theme().role(self.backdrop))
        tone = theme().tone(self.tone)
        W, H = begin(p, self)
        px = 1.0 / scale().f
        path = round_path(QRectF(0.5 * px, 0.5 * px, W - 2 * px, H - 2 * px), H / 2.0)
        p.fillPath(path, mix(theme().role(self.backdrop), tone, 0.14))
        p.setPen(Qt.NoPen)
        p.setBrush(tone)
        p.drawEllipse(QRectF(11, H / 2.0 - 4, 8, 8))
        text(p, self.caption, font(8.5, True), QRectF(26, 0, round(W) - 28, round(H)), tone, LEFT, VCENTER)


class LogBox(QPlainTextEdit):
    """read-only activity log without a context menu"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setReadOnly(True)
        self.setContextMenuPolicy(Qt.NoContextMenu)
        self.setFrameShape(QFrame.NoFrame)
        self.setWordWrapMode(QTextOption.WrapAtWordBoundaryOrAnywhere)
        self.design = (0, 0, 0, 0)
        theme().changed.connect(self.restyle)
        self.restyle()

    def place(self, x, y, w, h):
        self.design = (x, y, w, h)
        self.setGeometry(S(x), S(y), max(1, S(w)), max(1, S(h)))
        self.setFont(mono(9))

    def replace(self):
        if self.design[2] > 0:
            self.place(*self.design)

    def restyle(self):
        pal = theme().cur
        self.setStyleSheet("QPlainTextEdit { background: %s; color: %s; border: none; selection-background-color: %s; }"
                           "QScrollBar:vertical { background: %s; width: 10px; margin: 0; }"
                           "QScrollBar::handle:vertical { background: %s; border-radius: 4px; min-height: 24px; }"
                           "QScrollBar::add-line, QScrollBar::sub-line { height: 0; }"
                           % (pal.LogBg.name(), pal.LogText.name(), pal.Accent.name(), pal.LogBg.name(), pal.Border.name()))

    def append_text(self, s):
        c = self.textCursor()
        c.movePosition(c.MoveOperation.End)
        c.insertText(s.replace("\r\n", "\n"))
        self.setTextCursor(c)
        self.ensureCursorVisible()


class Progress(FlipWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.value, self.maximum = 0, 100
        self._marquee = False
        self.offset = 0
        self._spin = QTimer(self)
        self._spin.setInterval(30)
        self._spin.timeout.connect(self._tick)

    def _tick(self):
        self.offset += 7
        if self.isVisible():
            self.update()

    @property
    def marquee(self):
        return self._marquee

    @marquee.setter
    def marquee(self, v):
        self._marquee = v
        if v:
            self._spin.start()
        else:
            self._spin.stop()
        self.update()

    def paintEvent(self, e):
        p = QPainter(self)
        pal = theme().cur
        p.fillRect(self.rect(), pal.Card)
        p.setRenderHint(QPainter.Antialiasing, True)
        W, H = self.width(), self.height()
        p.fillPath(round_path(QRectF(0, 0, W - 1, H - 1), H / 2.0), pal.Track)
        if self._marquee:
            bw = max(24, W // 5)
            x = self.offset % (W + bw) - bw
            fr = QRectF(max(0, x), 0, min(bw, min(x + bw, W - max(0, x))), H - 1)
            if fr.width() > 2:
                p.fillPath(round_path(fr, H / 2.0), pal.Accent)
        else:
            fw = int(float(self.value) / self.maximum * (W - 1))
            if fw > 2:
                p.fillPath(round_path(QRectF(0, 0, fw, H - 1), H / 2.0), pal.Accent)


class Toggle(FlipWidget):
    """Slider that switches between the Flipper One (left) and Flipper Zero (right)."""
    toggled = Signal()

    def __init__(self, parent=None, img_one=None, img_zero=None):
        super().__init__(parent)
        self.img_one, self.img_zero = img_one, img_zero
        self.is_zero = False
        self.pos = 0.0
        self.target = 0.0
        self.start = 0.0
        self.t0 = 0.0
        self.hover = False
        self._timer = None
        self.setCursor(Qt.PointingHandCursor)

    def set_zero(self, zero, animate=True, raise_event=False):
        if zero == self.is_zero and abs(self.pos - (1.0 if zero else 0.0)) < 0.001:
            return
        self.is_zero = zero
        self.target = 1.0 if zero else 0.0
        if not animate:
            self.pos = self.target
            self.update()
        else:
            if self._timer is None:
                self._timer = QTimer(self)
                self._timer.setInterval(12)
                self._timer.timeout.connect(self._tick)
            self.start = self.pos
            self.t0 = time.monotonic()
            self._timer.start()
        if raise_event:
            self.toggled.emit()

    def _tick(self):
        t = (time.monotonic() - self.t0) / 0.26
        if t >= 1.0:
            t = 1.0
            self._timer.stop()
        eased = 1.0 - math.pow(1.0 - t, 3.0)
        self.pos = self.start + (self.target - self.start) * eased
        self.update()

    def enterEvent(self, e):
        self.hover = True
        self.update()

    def leaveEvent(self, e):
        self.hover = False
        self.update()

    def mouseReleaseEvent(self, e):
        if e.button() != Qt.LeftButton:
            return
        want = e.position().x() >= self.width() / 2
        if want != self.is_zero:
            self.set_zero(want, True, True)

    def paintEvent(self, e):
        p = QPainter(self)
        pal = theme().cur
        p.fillRect(self.rect(), pal.Side)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)
        px = 1.0 / scale().f
        W, H = begin(p, self)
        w, h = int(round(W)), int(round(H))
        track = round_path(QRectF(0.5 * px, 0.5 * px, W - 2 * px, H - 2 * px), h / 2.0)
        p.fillPath(track, pal.Track)
        p.setPen(QPen(pal.Accent if self.hover else pal.Border, px))
        p.drawPath(track)
        text(p, "ONE", font(9, True), QRectF(0, 0, w // 2, h), pal.Faint, CENTER, VCENTER)
        text(p, "ZERO", font(9, True), QRectF(w // 2, 0, w // 2, h), pal.Faint, CENTER, VCENTER)
        tw = w * 0.66
        th = h - 8.0
        x = 4.0 + (w - tw - 8.0) * self.pos
        thumb = QRectF(x, 4.0, tw, th)
        g = QLinearGradient(thumb.topLeft(), thumb.bottomLeft())
        g.setColorAt(0, QColor(255, 170, 50))
        g.setColorAt(1, QColor(255, 122, 0))
        p.fillPath(round_path(thumb, th / 2.0), QBrush(g))
        za = max(0.0, min(1.0, (self.pos - 0.25) / 0.5))
        box = QRectF(thumb.x() + th * 0.26, thumb.y() + 4, thumb.width() - th * 0.52, thumb.height() - 8)
        self._fit(p, self.img_one, box, 1.0 - za)
        self._fit(p, self.img_zero, box, za)

    @staticmethod
    def _fit(p, img, box, alpha):
        if img is None or img.isNull() or alpha <= 0.01:
            return
        sc = min(box.width() / img.width(), box.height() / img.height())
        iw, ih = img.width() * sc, img.height() * sc
        p.save()
        p.setOpacity(alpha)
        p.drawImage(QRectF(box.x() + (box.width() - iw) / 2, box.y() + (box.height() - ih) / 2, iw, ih), img)
        p.restore()
