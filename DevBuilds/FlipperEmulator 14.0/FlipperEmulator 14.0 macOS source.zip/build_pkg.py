#!/usr/bin/env python3
"""Builds FlipperEmulator-<version>.pkg (macOS flat installer package) on Linux.

No Mac tools are needed: the package is written directly (xar archive with a
Distribution file, one payload-free component package whose Scripts archive
carries "Flipper Emulator.app" and the postinstall script).

  python3 build_pkg.py <version> <FlipperEmulator <version>.sh> <out dir>
"""
import gzip
import io
import os
import stat
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "pkgtools"))
import xartool  # noqa: E402

IDENT = "io.github.wasabicover258.flipper-emulator"
APP = "Flipper Emulator.app"


def tpl(name, version):
    return open(os.path.join(HERE, "pkg", name), encoding="utf-8").read().replace("@VERSION@", version)


def icns(png_path):
    """AppIcon.icns from the 256 px app icon (PNG entries, scaled with Lanczos)."""
    from PIL import Image
    src = Image.open(png_path).convert("RGBA")
    out = []
    for kind, px in (("icp4", 16), ("icp5", 32), ("icp6", 64), ("ic07", 128), ("ic08", 256), ("ic09", 512),
                     ("ic10", 1024), ("ic11", 32), ("ic12", 64), ("ic13", 256), ("ic14", 512)):
        b = io.BytesIO()
        src.resize((px, px), Image.LANCZOS).save(b, "PNG", optimize=True)
        data = b.getvalue()
        out.append(kind.encode() + (8 + len(data)).to_bytes(4, "big") + data)
    body = b"".join(out)
    return b"icns" + (8 + len(body)).to_bytes(4, "big") + body


class Tree(object):
    """Files for the Scripts archive: path -> (bytes or None for dir, mode)."""

    def __init__(self):
        self.items = {".": (None, 0o755)}

    def dir(self, path):
        if not path or path == ".":
            return
        parts = path.split("/")
        for i in range(1, len(parts) + 1):
            self.items.setdefault("/".join(parts[:i]), (None, 0o755))

    def add(self, path, data, mode=0o644):
        if isinstance(data, str):
            data = data.encode("utf-8")
        self.dir(os.path.dirname(path))
        self.items[path] = (data, mode)

    def add_tree(self, dst, src, skip=("__pycache__",)):
        for root, dirs, files in os.walk(src, followlinks=True):
            dirs[:] = sorted(d for d in dirs if d not in skip)
            rel = os.path.relpath(root, src)
            base = dst if rel == "." else dst + "/" + rel
            self.dir(base)
            for f in sorted(files):
                if f.endswith((".pyc", ".pyo")):
                    continue
                p = os.path.join(root, f)
                mode = 0o755 if os.stat(p).st_mode & stat.S_IXUSR else 0o644
                self.add(base + "/" + f, open(p, "rb").read(), mode)

    def cpio_gz(self, mtime):
        """odc ("portable ASCII") cpio, gzip-compressed - the format pkgbuild uses for Scripts."""
        out = io.BytesIO()
        ino = 0
        for path in sorted(self.items, key=lambda p: (p != ".", p)):
            data, mode = self.items[path]
            ino += 1
            name = (path if path == "." else "./" + path).encode("utf-8") + b"\0"
            body = b"" if data is None else data
            m = (stat.S_IFDIR if data is None else stat.S_IFREG) | mode
            out.write(b"070707" + b"%06o%06o%06o%06o%06o%06o%06o%011o%06o%011o" % (
                0, ino, m, 0, 0, 2 if data is None else 1, 0, int(mtime), len(name), len(body)))
            out.write(name)
            out.write(body)
        out.write(b"070707" + b"%06o%06o%06o%06o%06o%06o%06o%011o%06o%011o" % (0, 0, 0, 0, 0, 1, 0, 0, 11, 0) + b"TRAILER!!!\0")
        return gzip.compress(out.getvalue(), 9, mtime=int(mtime))


def build(version, linux_sh, out_dir, devres=None):
    devres = devres or os.path.join(HERE, "devres")
    mtime = time.time()
    t = Tree()
    c = APP + "/Contents"
    t.add(c + "/Info.plist", tpl("Info.plist", version))
    t.add(c + "/PkgInfo", "APPL????")
    t.add(c + "/MacOS/FlipperEmulator", tpl("launcher.sh", version), 0o755)
    t.add(c + "/Resources/AppIcon.icns", icns(os.path.join(devres, "img", "icon.png")))
    t.add(c + "/Resources/VERSION", version + "\n")
    t.add_tree(c + "/Resources/app", os.path.join(HERE, "app"))
    t.add_tree(c + "/Resources/img", os.path.join(devres, "img"))
    t.add_tree(c + "/Resources/fonts", os.path.join(devres, "fonts"))
    t.add_tree(c + "/Resources/zero-ui", os.path.join(devres, "zero-ui"))
    t.add(c + "/Resources/linux/FlipperEmulator.sh", open(linux_sh, "rb").read(), 0o755)
    t.add("postinstall", tpl("postinstall.in", version), 0o755)
    scripts = t.cpio_gz(mtime)

    app_bytes = sum(len(d) for d, _ in t.items.values() if d)
    package_info = (
        '<?xml version="1.0" encoding="utf-8"?>\n'
        '<pkg-info overwrite-permissions="true" relocatable="false" identifier="%s" postinstall-action="none" '
        'version="%s" format-version="2" generator-version="FlipperEmulator build_pkg.py" auth="root">\n'
        '    <bundle-version/>\n    <upgrade-bundle/>\n    <update-bundle/>\n    <atomic-update-bundle/>\n'
        '    <strict-identifier/>\n    <relocate/>\n'
        '    <scripts>\n        <postinstall file="./postinstall" timeout="3600"/>\n    </scripts>\n'
        '</pkg-info>\n') % (IDENT, version)

    # runtime after unpacking: Python ~45 MB + Qt for Python ~330 MB (+ the app)
    install_kb = 400000 + app_bytes // 1024
    distribution = '''<?xml version="1.0" encoding="utf-8" standalone="no"?>
<installer-gui-script minSpecVersion="2">
    <title>Flipper Emulator %(v)s</title>
    <allowed-os-versions>
        <os-version min="14.0"/>
    </allowed-os-versions>
    <welcome file="Welcome.html" mime-type="text/html"/>
    <conclusion file="Conclusion.html" mime-type="text/html"/>
    <options customize="never" require-scripts="false" allow-external-scripts="no" hostArchitectures="x86_64,arm64"/>
    <domains enable_anywhere="false" enable_currentUserHome="false" enable_localSystem="true"/>
    <installation-check script="InstallationCheck();"/>
    <script>
        function InstallationCheck()
        {
            if (system.sysctl("kern.hv_support") != 1)
            {
                my.result.title = "Virtualization is not available";
                my.result.message = "Flipper Emulator needs the virtualization of this Mac (Hypervisor framework) for its private Linux environment. It is not available here, so the installation cannot continue.";
                my.result.type = "Fatal";
                return false;
            }
            return true;
        }
    </script>
    <choices-outline>
        <line choice="default">
            <line choice="%(id)s"/>
        </line>
    </choices-outline>
    <choice id="default"/>
    <choice id="%(id)s" visible="false">
        <pkg-ref id="%(id)s"/>
    </choice>
    <pkg-ref id="%(id)s" version="%(v)s" installKBytes="%(kb)d" onConclusion="none">#flipper-emulator.pkg</pkg-ref>
</installer-gui-script>
''' % {"v": version, "id": IDENT, "kb": install_kb}

    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, "FlipperEmulator-%s.pkg" % version)
    xartool.write(out, [
        ("Distribution", distribution.encode("utf-8"), 0o644),
        ("Resources", None, 0o755),
        ("Resources/Welcome.html", tpl("Welcome.html", version).encode("utf-8"), 0o644),
        ("Resources/Conclusion.html", tpl("Conclusion.html", version).encode("utf-8"), 0o644),
        ("flipper-emulator.pkg", None, 0o755),
        ("flipper-emulator.pkg/PackageInfo", package_info.encode("utf-8"), 0o644),
        ("flipper-emulator.pkg/Scripts", scripts, 0o644),
    ], mtime)
    return out


if __name__ == "__main__":
    if len(sys.argv) < 4:
        sys.exit(__doc__)
    p = build(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4] if len(sys.argv) > 4 else None)
    print(p, os.path.getsize(p))
