# -*- coding: utf-8 -*-
"""
Flipper Emulator - desktop window for the emulated Flipper Zero.

The window is the user interface of qFlipper (GPL-3.0, Copyright (C) Flipper
Devices Inc., https://github.com/flipperdevices/qFlipper), modified: names and
logos are removed and the backend is replaced by this program, which talks to
the emulator (screen, buttons, SD card) instead of a USB device.

This Python backend is new code, released under GPL-3.0-or-later like the
user interface it drives. See LICENSE-GPL-3.0 and NOTICE in the app folder.
"""
import argparse
import datetime
import itertools
import json
import os
import shutil
import socket
import subprocess
import sys
import threading
import time
import uuid
from enum import IntEnum

from PySide6.QtCore import (QAbstractListModel, QByteArray, QCoreApplication, QDate, QEvent, QModelIndex,
                            QObject, QPointF, QRectF, QResource, QSettings, QSize, QStandardPaths, Qt, QTimer,
                            QUrl, Property, Signal, Slot, QEnum, QMetaObject, QLocale)
from PySide6.QtGui import QClipboard, QColor, QFontDatabase, QGuiApplication, QIcon, QImage, QPainter, QTransform
from PySide6.QtQml import (QQmlApplicationEngine, QQmlPropertyMap, qmlRegisterSingletonInstance, qmlRegisterType,
                           qmlRegisterUncreatableType)
from PySide6.QtQuick import QQuickPaintedItem, QQuickWindow
from PySide6.QtQuickControls2 import QQuickStyle
from PySide6.QtWidgets import QApplication, QFileDialog

APP_NAME = 'Flipper Emulator'
APP_VERSION = '13.7'
FB_SIZE = 8192
MAX_UPLOAD_SIZE_BYTES = 2000000
NEW_DIR_INVALID = -10

IS_WINDOWS = os.name == 'nt'
NO_WINDOW = 0x08000000 if IS_WINDOWS else 0


def wsl_path(p):
    """C:\\Users\\x -> /mnt/c/Users/x (used when the helper runs inside WSL)."""
    p = p.replace('\\', '/')
    if len(p) > 1 and p[1] == ':':
        return '/mnt/' + p[0].lower() + p[2:]
    return p


# ============================================================ configuration
class Config(object):
    def __init__(self, ns):
        self.fb = ns.fb
        self.sd_img = ns.sd_img
        self.distro = ns.distro
        self.helper = ns.helper
        self.local_fs = ns.local_fs
        self.port = ns.port
        self.fw_name = ns.fw_name
        self.fw_version = ns.fw_version
        self.fw_branch = ns.fw_branch
        self.fw_date = ns.fw_date
        self.data_dir = ns.data_dir
        self.rcc = ns.rcc
        self.shot = ns.shot
        self.no_monitor = ns.no_monitor
        # macOS (14.0): the SD helper runs inside the Ubuntu VM; local files go
        # through the folder that is shared with the VM (HOST=VM)
        self.remote_cmd = json.loads(ns.remote_cmd) if ns.remote_cmd else None
        self.share_host, self.share_vm = '', ''
        if ns.share_map and '=' in ns.share_map:
            self.share_host, self.share_vm = ns.share_map.split('=', 1)


# ================================================================= logging
class Logger(QObject):
    logTextChanged = Signal()
    errorCountChanged = Signal()

    COLORS = {'info': '#ffb347', 'warn': '#ffd24a', 'error': '#ff6b6b', 'debug': '#b0865a'}

    def __init__(self, data_dir):
        QObject.__init__(self)
        self._lines = []
        self._errors = 0
        self._dir = data_dir
        os.makedirs(self._dir, exist_ok=True)
        self._file = os.path.join(self._dir, 'flipper-emulator.log')
        self._lock = threading.Lock()
        self._pending = False
        self._flush = QTimer(self)
        self._flush.setSingleShot(True)
        self._flush.setInterval(120)
        self._flush.timeout.connect(self.logTextChanged)
        try:
            if os.path.exists(self._file) and os.path.getsize(self._file) > 400000:
                os.replace(self._file, self._file + '.old')
        except Exception:
            pass

    @Property(QUrl, constant=True)
    def logsPath(self):
        return QUrl.fromLocalFile(self._dir)

    @Property(QUrl, constant=True)
    def logsFile(self):
        return QUrl.fromLocalFile(self._file)

    def _get_errors(self):
        return self._errors

    def _set_errors(self, v):
        if v != self._errors:
            self._errors = v
            self.errorCountChanged.emit()

    errorCount = Property(int, _get_errors, _set_errors, notify=errorCountChanged)

    @Property(str, notify=logTextChanged)
    def logText(self):
        return ''.join(self._lines)

    def log(self, msg, level='info'):
        stamp = time.strftime('%H:%M:%S')
        esc = (str(msg).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;'))
        line = '<font color="%s">[%s] %s</font><br/>' % (self.COLORS.get(level, '#ffb347'), stamp, esc)
        with self._lock:
            self._lines.append(line)
            if len(self._lines) > 1500:
                del self._lines[:300]
            try:
                with open(self._file, 'a', encoding='utf-8') as fh:
                    fh.write('[%s] %s: %s\n' % (time.strftime('%Y-%m-%d %H:%M:%S'), level, msg))
            except Exception:
                pass
        if level == 'error':
            self._errors += 1
            post(self.errorCountChanged.emit)
        post(self._flush.start)


LOG = None


def log(msg, level='info'):
    if LOG is not None:
        try:
            LOG.log(msg, level)
        except Exception:
            pass


class Dispatcher(QObject):
    """Runs callables on the Qt thread."""
    _call = Signal(object)

    def __init__(self):
        QObject.__init__(self)
        self._call.connect(self._run, Qt.QueuedConnection)

    @Slot(object)
    def _run(self, fn):
        try:
            fn()
        except Exception as ex:  # pragma: no cover
            log('Internal error: %r' % (ex,), 'error')

    def post(self, fn):
        self._call.emit(fn)


DISPATCH = None


def post(fn):
    DISPATCH.post(fn)


# =========================================================== preferences
class Preferences(QObject):
    updateChannelChanged = Signal()
    appUpdateChannelChanged = Signal()
    checkAppUpdatesChanged = Signal()
    showHiddenFilesChanged = Signal()

    def __init__(self):
        QObject.__init__(self)
        self._s = QSettings()

    def _val(self, key, default):
        try:
            return self._s.value(key, default)
        except Exception:
            return default

    def _get_uc(self):
        return str(self._val('updateChannel', 'release'))

    def _set_uc(self, v):
        self._s.setValue('updateChannel', v)
        self.updateChannelChanged.emit()

    updateChannel = Property(str, _get_uc, _set_uc, notify=updateChannelChanged)

    def _get_auc(self):
        return str(self._val('appUpdateChannel', 'release'))

    def _set_auc(self, v):
        self._s.setValue('appUpdateChannel', v)
        self.appUpdateChannelChanged.emit()

    appUpdateChannel = Property(str, _get_auc, _set_auc, notify=appUpdateChannelChanged)

    @Property(bool, notify=checkAppUpdatesChanged)
    def checkAppUpdates(self):
        return False

    def _get_hidden(self):
        return str(self._val('showHiddenFiles', 'false')).lower() in ('true', '1')

    def _set_hidden(self, v):
        self._s.setValue('showHiddenFiles', bool(v))
        self.showHiddenFilesChanged.emit()

    showHiddenFiles = Property(bool, _get_hidden, _set_hidden, notify=showHiddenFilesChanged)

    def last_folder(self):
        v = self._val('lastFolder', '')
        if v and os.path.isdir(str(v)):
            return str(v)
        return QStandardPaths.writableLocation(QStandardPaths.HomeLocation)

    def set_last_folder(self, p):
        self._s.setValue('lastFolder', p)


# ======================================================== enum containers
class BackendError(QObject):
    @QEnum
    class ErrorType(IntEnum):
        NoError = 0
        UnknownError = 1
        InvalidDevice = 2
        InternetError = 3
        BackupError = 4
        DiskError = 5
        DataError = 6
        SerialAccessError = 7
        RecoveryAccessError = 8
        OperationError = 9
        UpdaterError = 10
        SerialError = 11
        RecoveryError = 12
        ProtocolError = 13
        TimeoutError = 14
        FileError = 15


class InputEvent(QObject):
    @QEnum
    class Key(IntEnum):
        Up = 0
        Down = 1
        Right = 2
        Left = 3
        Ok = 4
        Back = 5

    @QEnum
    class Type(IntEnum):
        Press = 0
        Release = 1
        Short = 2
        Long = 3
        Repeat = 4


class ApplicationUpdater(QObject):
    stateChanged = Signal()
    progressChanged = Signal()

    @QEnum
    class State(IntEnum):
        Idle = 0
        Downloading = 1
        Updating = 2
        ErrorOccured = 3

    @Property(int, notify=stateChanged)
    def state(self):
        return 0

    @Property(float, notify=progressChanged)
    def progress(self):
        return 0.0


class SystemFileDialog(QObject):
    accepted = Signal()
    finished = Signal()

    @QEnum
    class StandardLocation(IntEnum):
        LastLocation = 0
        HomeLocation = 1
        DownloadsLocation = 2
        PicturesLocation = 3
        DocumentsLocation = 4
        DefaultLocation = 5

    def __init__(self, prefs):
        QObject.__init__(self)
        self._prefs = prefs
        self._dlg = None

    @Property(str, constant=True)
    def selectedNameFilter(self):
        return self._dlg.selectedNameFilter() if self._dlg else ''

    @Property(QUrl, constant=True)
    def fileUrl(self):
        u = self.fileUrls
        return u[0] if u else QUrl()

    @Property('QVariantList', constant=True)
    def fileUrls(self):
        return list(self._dlg.selectedUrls()) if self._dlg else []

    def _location(self, loc):
        sp = QStandardPaths
        if loc == 0:
            return self._prefs.last_folder()
        if loc == 2:
            return sp.writableLocation(sp.DownloadLocation)
        if loc == 3:
            return sp.writableLocation(sp.PicturesLocation)
        if loc == 4:
            return sp.writableLocation(sp.DocumentsLocation)
        return sp.writableLocation(sp.HomeLocation)

    def _begin(self, loc, accept_mode, file_mode, filters=None, default_name=''):
        if self._dlg is not None:
            self._dlg.deleteLater()
        d = QFileDialog()
        self._dlg = d
        d.setFileMode(file_mode)
        d.setAcceptMode(accept_mode)
        d.setDirectory(self._location(loc))
        if default_name:
            d.selectFile(default_name)
        if filters:
            d.setNameFilters(list(filters))
        d.accepted.connect(self.accepted)
        d.finished.connect(self._on_finished)
        d.exec()

    def _on_finished(self, *_):
        try:
            self._prefs.set_last_folder(self._dlg.directory().absolutePath())
        except Exception:
            pass
        self.finished.emit()
        # one-shot connections made by the QML side
        for sig in (self.accepted, self.finished):
            try:
                sig.disconnect()
            except Exception:
                pass
        self.finished.connect(lambda *a: None)

    @Slot(int, 'QStringList')
    def beginOpenFiles(self, loc, filters):
        self._begin(loc, QFileDialog.AcceptOpen, QFileDialog.ExistingFiles, filters)

    @Slot(int, 'QStringList')
    def beginOpenFile(self, loc, filters):
        self._begin(loc, QFileDialog.AcceptOpen, QFileDialog.ExistingFile, filters)

    @Slot(int)
    def beginOpenDir(self, loc):
        self._begin(loc, QFileDialog.AcceptOpen, QFileDialog.Directory)

    @Slot(int, 'QStringList', str)
    def beginSaveFile(self, loc, filters, default_name):
        self._begin(loc, QFileDialog.AcceptSave, QFileDialog.AnyFile, filters, default_name)

    @Slot(int)
    def beginSaveDir(self, loc):
        self._begin(loc, QFileDialog.AcceptOpen, QFileDialog.Directory)

    @Slot()
    def close(self):
        if self._dlg is not None and self._dlg.isVisible():
            self._dlg.reject()


# ======================================================== screen canvas
class ScreenFrame(QObject):
    updated = Signal()

    def __init__(self):
        QObject.__init__(self)
        self.pixels = b''
        self.width = 128
        self.height = 64

    @Property(int, constant=True)
    def frameWidth(self):
        return self.width


class ScreenCanvas(QQuickPaintedItem):
    zoomFactorChanged = Signal()
    foregroundColorChanged = Signal()
    backgroundColorChanged = Signal()
    frameChanged = Signal()
    canvasSizeChanged = Signal()

    def __init__(self, parent=None):
        QQuickPaintedItem.__init__(self, parent)
        self._fg = QColor(0, 0, 0)
        self._bg = QColor(255, 255, 255)
        self._zoom = 1.0
        self._frame = None
        self._canvas = QImage(128, 64, QImage.Format_RGB32)
        self._canvas.fill(self._bg)
        self._raw = None
        self.zoomFactorChanged.connect(self._implicit)
        self.canvasSizeChanged.connect(self._implicit)
        self._implicit()

    def _implicit(self):
        self.setImplicitSize(self._zoom * self._canvas.width(), self._zoom * self._canvas.height())

    def _get_zoom(self):
        return self._zoom

    def _set_zoom(self, v):
        if abs(v - self._zoom) > 1e-9:
            self._zoom = v
            self.zoomFactorChanged.emit()

    zoomFactor = Property(float, _get_zoom, _set_zoom, notify=zoomFactorChanged)

    def _get_fg(self):
        return self._fg

    def _set_fg(self, c):
        c = QColor(c)
        if c != self._fg:
            self._fg = c
            self.foregroundColorChanged.emit()
            self._rebuild()

    foregroundColor = Property(QColor, _get_fg, _set_fg, notify=foregroundColorChanged)

    def _get_bg(self):
        return self._bg

    def _set_bg(self, c):
        c = QColor(c)
        if c != self._bg:
            self._bg = c
            self.backgroundColorChanged.emit()
            self._rebuild()

    backgroundColor = Property(QColor, _get_bg, _set_bg, notify=backgroundColorChanged)

    def _get_frame(self):
        return self._frame

    def _set_frame(self, f):
        if f is self._frame:
            return
        if self._frame is not None:
            try:
                self._frame.updated.disconnect(self._rebuild)
            except Exception:
                pass
        self._frame = f
        if f is not None:
            f.updated.connect(self._rebuild)
        self.frameChanged.emit()
        self._rebuild()

    frame = Property(QObject, _get_frame, _set_frame, notify=frameChanged)

    def _rebuild(self):
        f = self._frame
        if f is None or len(f.pixels) < f.width * f.height:
            return
        w, h = f.width, f.height
        # nonzero source pixel -> palette index 1 (lit)
        table = bytes([0]) + bytes([1]) * 255
        data = bytes(f.pixels[:w * h]).translate(table)
        img = QImage(data, w, h, w, QImage.Format_Indexed8)
        img.setColorTable([self._bg.rgb(), self._fg.rgb()])
        if (w, h) != (self._canvas.width(), self._canvas.height()):
            self._canvas = QImage(w, h, QImage.Format_RGB32)
            self.canvasSizeChanged.emit()
        self._canvas = img.convertToFormat(QImage.Format_RGB32)
        self.update()

    def _canvas_rect(self):
        tw, th = self.width(), self.height()
        cw, ch = self._canvas.width(), self._canvas.height()
        ar = float(cw) / ch
        dw = tw
        dh = float(int(dw / ar))
        if dh > th:
            dh = th
            dw = th * ar
        if dw > cw:
            dw -= int(dw) % cw
        if dh > ch:
            dh -= int(dh) % ch
        return QRectF((tw - dw) / 2, (th - dh) / 2, dw, dh)

    def paint(self, painter):
        painter.drawImage(self._canvas_rect(), self._canvas)

    def _scaled(self, scale):
        s = self._zoom if scale == 0 else scale
        return self._canvas.scaled(int(self._canvas.width() * s), int(self._canvas.height() * s))

    @Slot(QUrl, int, result=bool)
    def saveImage(self, url, scale=0):
        return self._scaled(scale).save(url.toLocalFile())

    @Slot(int)
    def copyToClipboard(self, scale=0):
        QGuiApplication.clipboard().setImage(self._scaled(scale))


# =========================================================== emulator link
class Monitor(object):
    """Renode monitor: button presses (queued, ordered) and pause/resume."""
    PINS = {
        0: ('gpioPortB', 10, True),   # Up      (active low)
        1: ('gpioPortC', 6, True),    # Down
        2: ('gpioPortB', 12, True),   # Right
        3: ('gpioPortB', 11, True),   # Left
        4: ('gpioPortH', 3, False),   # Ok      (active high)
        5: ('gpioPortC', 13, True),   # Back
    }
    MIN_HOLD = 0.05

    def __init__(self, port, disabled=False):
        self.port = port
        self.disabled = disabled
        self._q = []
        self._cv = threading.Condition()
        self._sock = None
        self._pressed = {}
        self._released_at = {}
        self._connected = False
        self._stop = False
        self._pause_depth = 0
        self._plock = threading.Lock()
        self._slock = threading.RLock()
        self.t = threading.Thread(target=self._loop, daemon=True)
        self.t.start()

    @property
    def connected(self):
        return self._connected

    def key(self, key, pressed):
        with self._cv:
            self._q.append((int(key), bool(pressed)))
            self._cv.notify()

    def _open(self):
        s = socket.create_connection(('127.0.0.1', self.port), timeout=0.6)
        # Flipper Emulator 13.8: the monitor of the emulator only answers to clients that
        # know the secret of this emulator start (no other program, no virtual machine).
        token = os.environ.get('FLIPPER_MONITOR_TOKEN', '')
        if token:
            s.sendall(('FLIPPER-AUTH %s\n' % token).encode('ascii'))
        s.settimeout(1.0)
        return s

    def _connect(self):
        try:
            s = self._open()
        except Exception:
            return False
        self._sock = s
        self._connected = True
        for k, (port, pin, low) in self.PINS.items():
            self._send('%s OnGPIO %d %s' % (port, pin, 'true' if low else 'false'))
        self._pressed = {}
        log('Connected to the emulator monitor.', 'debug')
        return True

    def _send(self, line):
        with self._slock:
            if self._sock is None:
                return False
            try:
                self._sock.sendall((line + '\n').encode('ascii'))
                try:
                    self._sock.settimeout(0.001)
                    self._sock.recv(65536)
                except Exception:
                    pass
                self._sock.settimeout(1.0)
                return True
            except Exception:
                self._connected = False
                try:
                    self._sock.close()
                except Exception:
                    pass
                self._sock = None
                return False

    def _apply(self, key, pressed):
        port, pin, low = self.PINS[key]
        level = (not pressed) if low else pressed
        return self._send('%s OnGPIO %d %s' % (port, pin, 'true' if level else 'false'))

    def _loop(self):
        while not self._stop:
            with self._cv:
                while not self._q and not self._stop:
                    self._cv.wait(1.0)
                    if not self._connected and not self.disabled:
                        break
                item = self._q.pop(0) if self._q else None
            if self.disabled:
                continue
            if not self._connected:
                if not self._connect():
                    time.sleep(0.5)
                    if item is None:
                        continue
                    # drop key events while the emulator is not reachable
                    continue
            if item is None:
                continue
            key, pressed = item
            if pressed:
                if key in self._pressed:
                    continue
                gap = self.MIN_HOLD - (time.time() - self._released_at.get(key, 0.0))
                if gap > 0:
                    time.sleep(gap)   # the firmware needs a clear gap between two presses
                if self._apply(key, True):
                    self._pressed[key] = time.time()
            else:
                t0 = self._pressed.get(key)
                if t0 is None:
                    continue
                wait = self.MIN_HOLD - (time.time() - t0)
                if wait > 0:
                    time.sleep(wait)
                if self._apply(key, False):
                    self._pressed.pop(key, None)
                    self._released_at[key] = time.time()

    def release_all(self):
        for k in list(self._pressed.keys()):
            try:
                self._apply(k, False)
            except Exception:
                pass
        self._pressed = {}

    def command(self, line):
        """Send one monitor command over the same connection as the buttons (keeps the order)."""
        if self.disabled:
            return False
        with self._slock:
            if not self._connected and not self._connect():
                return False
            ok = self._send(line)
        time.sleep(0.12)
        return ok

    class _Paused(object):
        def __init__(self, mon):
            self.mon = mon

        def __enter__(self):
            with self.mon._plock:
                self.mon._pause_depth += 1
                if self.mon._pause_depth == 1:
                    self.mon.command('pause')
            return self

        def __exit__(self, *a):
            with self.mon._plock:
                self.mon._pause_depth -= 1
                if self.mon._pause_depth == 0:
                    self.mon.command('start')
            return False

    def paused(self):
        return Monitor._Paused(self)

    def close(self):
        self._stop = True
        with self._cv:
            self._cv.notify_all()


class FsError(Exception):
    pass


class FsClient(object):
    """Talks to flipfs.py (JSON lines) that edits the SD card image."""

    def __init__(self, cfg):
        self.cfg = cfg
        self.proc = None
        self.lock = threading.RLock()
        self.ids = itertools.count(1)
        self.resp = []
        self.cv = threading.Condition()
        self.err_tail = []

    def _command(self):
        c = self.cfg
        if c.remote_cmd:
            return list(c.remote_cmd) + ['python3', '-u', c.helper, c.sd_img]
        if c.local_fs:
            return [sys.executable, c.helper, c.sd_img]
        return ['wsl.exe', '-d', c.distro, '--', 'python3', '-u', wsl_path(c.helper), c.sd_img]

    def _start(self):
        self.stop()
        self.resp = []
        self.proc = subprocess.Popen(self._command(), stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE, creationflags=NO_WINDOW)
        threading.Thread(target=self._read, args=(self.proc,), daemon=True).start()
        threading.Thread(target=self._read_err, args=(self.proc,), daemon=True).start()
        first = self._wait(0, None, 45.0)
        if not first.get('ok'):
            self.stop()
            raise FsError(first.get('error') or 'The SD card helper could not start.')

    def _read(self, proc):
        try:
            for raw in proc.stdout:
                try:
                    obj = json.loads(raw.decode('utf-8', 'replace'))
                except Exception:
                    continue
                with self.cv:
                    self.resp.append(obj)
                    self.cv.notify_all()
        except Exception:
            pass
        with self.cv:
            self.resp.append({'id': -1, 'ok': False, 'error': 'The SD card helper stopped.', 'dead': True})
            self.cv.notify_all()

    def _read_err(self, proc):
        try:
            for raw in proc.stderr:
                t = raw.decode('utf-8', 'replace').strip()
                if t:
                    self.err_tail = (self.err_tail + [t])[-8:]
        except Exception:
            pass

    def _wait(self, rid, progress, timeout):
        end = time.time() + timeout
        while True:
            with self.cv:
                while not self.resp:
                    left = end - time.time()
                    if left <= 0:
                        raise FsError('The SD card helper did not answer in time.')
                    self.cv.wait(min(left, 0.5))
                obj = self.resp.pop(0)
            if obj.get('dead'):
                tail = ' '.join(self.err_tail)
                raise FsError('The SD card helper stopped. ' + tail)
            if obj.get('id') != rid:
                continue
            if 'progress' in obj and 'ok' not in obj:
                if progress:
                    progress(obj['progress'])
                continue
            return obj

    # ---- macOS: local paths <-> the folder shared with the VM
    def _vm_path(self, local):
        c = self.cfg
        host = os.path.realpath(c.share_host)
        real = os.path.realpath(local)
        if real == host or real.startswith(host.rstrip('/') + '/'):
            return c.share_vm.rstrip('/') + real[len(host.rstrip('/')):]
        return None

    def _stage_dir(self):
        d = os.path.join(self.cfg.share_host, 'zero-transfer', uuid.uuid4().hex[:12])
        os.makedirs(d, exist_ok=True)
        try:
            os.chmod(d, 0o777)   # the VM user writes downloads into it (the folder is inside the private app data)
        except OSError:
            pass
        return d

    def request(self, req, progress=None, timeout=600.0):
        c = self.cfg
        op = req.get('op')
        if not (c.remote_cmd and c.share_host and op in ('put', 'restore', 'get', 'backup')):
            return self._request(req, progress, timeout)
        req = dict(req)
        stage = None
        try:
            if op in ('put', 'restore'):
                src = req['src']
                vm = self._vm_path(src)
                if vm is None:
                    stage = self._stage_dir()
                    tmp = os.path.join(stage, os.path.basename(src.rstrip('/')))
                    if os.path.isdir(src):
                        shutil.copytree(src, tmp, symlinks=False)
                    else:
                        shutil.copy2(src, tmp)
                    vm = self._vm_path(tmp)
                req['src'] = vm
                return self._request(req, progress, timeout)
            dst = req['dst']
            vm = self._vm_path(dst)
            if vm is not None:
                req['dst'] = vm
                return self._request(req, progress, timeout)
            stage = self._stage_dir()
            tmp = os.path.join(stage, os.path.basename(dst.rstrip('/')) or 'download')
            req['dst'] = self._vm_path(tmp)
            res = self._request(req, progress, timeout)
            if os.path.isdir(dst) and not os.path.isdir(tmp):
                dst = os.path.join(dst, os.path.basename(tmp))
            if os.path.isdir(tmp) and os.path.isdir(dst):
                shutil.rmtree(dst)
            shutil.move(tmp, dst)
            return res
        finally:
            if stage:
                shutil.rmtree(stage, ignore_errors=True)

    def _request(self, req, progress=None, timeout=600.0):
        with self.lock:
            if self.proc is None or self.proc.poll() is not None:
                self._start()
            rid = next(self.ids)
            req = dict(req)
            req['id'] = rid
            try:
                self.proc.stdin.write((json.dumps(req) + '\n').encode('utf-8'))
                self.proc.stdin.flush()
            except Exception:
                self.stop()
                raise FsError('The SD card helper stopped.')
            res = self._wait(rid, progress, timeout)
            if not res.get('ok'):
                raise FsError(res.get('error') or 'Unknown SD card error.')
            return res

    def stop(self):
        p, self.proc = self.proc, None
        if p is not None:
            try:
                p.stdin.close()
            except Exception:
                pass
            try:
                p.kill()
            except Exception:
                pass


# =============================================================== models
def make_map(parent, values):
    m = QQmlPropertyMap(parent)
    for k, v in values.items():
        m.insert(k, v)
    return m


class DeviceState(QObject):
    deviceInfoChanged = Signal()
    isPersistentChanged = Signal()
    isOnlineChanged = Signal()
    isErrorChanged = Signal()
    statusStringChanged = Signal()
    progressChanged = Signal()

    def __init__(self, cfg):
        QObject.__init__(self)
        self._cfg = cfg
        self._online = True
        self._error = False
        self._errorString = ''
        self._status = ''
        self._progress = -1.0
        date = QDate.currentDate()
        try:
            y, m, d = [int(x) for x in cfg.fw_date.split('-')]
            date = QDate(y, m, d)
        except Exception:
            pass
        self._hw = make_map(self, {'version': '12', 'target': 'F7', 'body': 'B9', 'connect': 'C6'})
        self._fw = make_map(self, {'version': cfg.fw_version, 'commit': cfg.fw_version, 'branch': cfg.fw_branch,
                                   'channel': 'release', 'date': date})
        self._st = make_map(self, {'internalFree': 100, 'externalFree': 100, 'isExternalPresent': True,
                                   'isAssetsInstalled': False})
        self._info = make_map(self, {'name': cfg.fw_name, 'model': 'Flipper Zero', 'fusVersion': '',
                                     'radioVersion': 'Emulated', 'systemLocation': 'Emulator (Renode)',
                                     'stackType': 0, 'hardware': self._hw, 'firmware': self._fw,
                                     'storage': self._st})

    def set_storage(self, free_pct, present, assets):
        self._st.insert('externalFree', int(free_pct))
        self._st.insert('isExternalPresent', bool(present))
        self._st.insert('isAssetsInstalled', bool(assets))
        self.deviceInfoChanged.emit()

    @Property(QObject, notify=deviceInfoChanged)
    def info(self):
        return self._info

    @Property(bool, notify=isPersistentChanged)
    def isPersistent(self):
        return True

    @Property(bool, notify=isOnlineChanged)
    def isOnline(self):
        return self._online

    @Property(bool, notify=isErrorChanged)
    def isError(self):
        return self._error

    @Property(bool, notify=deviceInfoChanged)
    def isRecoveryMode(self):
        return False

    @Property(str, notify=statusStringChanged)
    def statusString(self):
        return self._status

    @Property(str, notify=isErrorChanged)
    def errorString(self):
        return self._errorString

    @Property(float, notify=progressChanged)
    def progress(self):
        return self._progress

    def set_progress(self, v):
        if abs(v - self._progress) > 1e-6:
            self._progress = v
            self.progressChanged.emit()

    def set_status(self, s):
        if s != self._status:
            self._status = s
            self.statusStringChanged.emit()


class ScreenStreamer(QObject):
    streamStateChanged = Signal()
    screenFrameChanged = Signal()
    firstFrame = Signal()

    def __init__(self, cfg, monitor):
        QObject.__init__(self)
        self._cfg = cfg
        self._mon = monitor
        self._enabled = True
        self._paused = False
        self._frame = ScreenFrame()
        self._seen = False
        self._stop = False
        self._last = b''
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def _loop(self):
        path = self._cfg.fb
        while not self._stop:
            time.sleep(0.04)
            try:
                with open(path, 'rb') as fh:
                    b = fh.read(FB_SIZE)
            except Exception:
                continue
            if len(b) < FB_SIZE or b == self._last:
                continue
            self._last = b
            post(lambda b=b: self._apply(b))

    def _apply(self, b):
        if self._paused:
            return
        self._frame.pixels = b
        self._frame.updated.emit()
        if not self._seen:
            self._seen = True
            self.firstFrame.emit()

    @Property(QObject, notify=screenFrameChanged)
    def screenFrame(self):
        return self._frame

    def _get_enabled(self):
        return self._enabled

    def _set_enabled(self, v):
        if v != self._enabled:
            self._enabled = v
            self.streamStateChanged.emit()

    isEnabled = Property(bool, _get_enabled, _set_enabled, notify=streamStateChanged)

    def _get_paused(self):
        return self._paused

    def _set_paused(self, v):
        if v != self._paused:
            self._paused = v
            self.streamStateChanged.emit()

    isPaused = Property(bool, _get_paused, _set_paused, notify=streamStateChanged)

    @Slot(int, int)
    def sendInputEvent(self, key, typ):
        if typ == InputEvent.Type.Press:
            self._mon.key(key, True)
        elif typ == InputEvent.Type.Release:
            self._mon.key(key, False)

    def stop(self):
        self._stop = True


class FileManager(QAbstractListModel):
    isBusyChanged = Signal()
    currentPathChanged = Signal()
    newDirectoryIndexChanged = Signal()
    errorOccured = Signal()

    FileName = Qt.UserRole
    FilePath = Qt.UserRole + 1
    FileType = Qt.UserRole + 2
    FileSize = Qt.UserRole + 3

    def __init__(self, fs, monitor, prefs, devstate):
        QAbstractListModel.__init__(self)
        self._fs = fs
        self._mon = monitor
        self._prefs = prefs
        self._dev = devstate
        self._data = []
        self._history = ['']
        self._forward = []
        self._busy = False
        self._busy_timer = QTimer(self)
        self._busy_timer.setSingleShot(True)
        self._busy_timer.setInterval(500)
        self._busy_timer.timeout.connect(self._on_busy_timeout)
        self._new_index = NEW_DIR_INVALID
        self._error = ''
        self._list_seq = 0
        self._busy_count = 0
        self._ops = []
        self._ops_lock = threading.Lock()
        self._worker = None

    def error_string(self):
        return self._error

    # --- roles -----------------------------------------------------------
    def roleNames(self):
        return {self.FileName: QByteArray(b'fileName'), self.FilePath: QByteArray(b'filePath'),
                self.FileType: QByteArray(b'fileType'), self.FileSize: QByteArray(b'fileSize')}

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self._data)

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid() or index.row() >= len(self._data):
            return None
        it = self._data[index.row()]
        if role == self.FileName:
            return it['name']
        if role == self.FilePath:
            return it['path']
        if role == self.FileType:
            return 0 if it['dir'] else 1
        if role == self.FileSize:
            return int(min(it['size'], 2 ** 31 - 1))
        return None

    # --- properties ------------------------------------------------------
    @Property(bool, notify=isBusyChanged)
    def isBusy(self):
        return self._busy

    @Property(bool, notify=currentPathChanged)
    def isRoot(self):
        return self._path() == '/'

    @Property(bool, notify=currentPathChanged)
    def canGoBack(self):
        return len(self._history) > 1

    @Property(bool, notify=currentPathChanged)
    def canGoForward(self):
        return len(self._forward) > 0

    @Property(str, notify=currentPathChanged)
    def currentPath(self):
        return self._path()

    @Property(int, notify=newDirectoryIndexChanged)
    def newDirectoryIndex(self):
        return self._new_index

    def _path(self):
        if len(self._history) == 1:
            return '/'
        return '/'.join(self._history)

    def _remote(self, name):
        p = self._path()
        return ('%s/%s' % (p, name)).lstrip('/') if p == '/' else '%s/%s' % (p, name)

    def _abs(self, name):
        r = self._remote(name)
        return r if r.startswith('/') else '/' + r

    # --- model data ------------------------------------------------------
    def _set_data(self, items):
        self.beginResetModel()
        show_hidden = self._prefs.showHiddenFiles
        self._data = [i for i in items if show_hidden or not i['name'].startswith('.')]
        self._data.sort(key=lambda i: (0 if i['dir'] else 1, i['name'].lower()))
        self.endResetModel()

    def _set_root(self):
        self._set_data([{'name': 'ext', 'path': '/ext', 'dir': True, 'size': 0}])

    def _set_new_index(self, i):
        if i != self._new_index:
            self._new_index = i
            self.newDirectoryIndexChanged.emit()

    # --- busy ------------------------------------------------------------
    def _set_busy(self, busy):
        if busy:
            self._busy_count += 1
            if not self._busy_timer.isActive() and not self._busy:
                self._busy_timer.start()
        else:
            self._busy_count = max(0, self._busy_count - 1)
            if self._busy_count == 0:
                self._busy_timer.stop()
                if self._busy:
                    self._busy = False
                    self.isBusyChanged.emit()

    def _on_busy_timeout(self):
        if self._busy_count > 0:
            self._busy = True
            self.isBusyChanged.emit()

    # --- async plumbing ---------------------------------------------------
    def _run(self, work, done, progress=False, pause=False):
        """work() runs in a thread (emulator paused); done(result, error) on the Qt thread."""
        self._set_busy(True)
        if progress:
            self._dev.set_progress(-1.0)

        def prog(p):
            post(lambda: self._dev.set_progress(p))

        def job():
            res, err = None, None
            try:
                if pause:
                    with self._mon.paused():
                        res = work(prog if progress else None)
                else:
                    res = work(prog if progress else None)
            except FsError as ex:
                err = str(ex)
            except Exception as ex:
                err = 'Internal error: %r' % (ex,)

            def finish():
                self._set_busy(False)
                done(res, err)
            post(finish)
        threading.Thread(target=job, daemon=True).start()

    def _fail(self, message):
        self._error = message
        log(message, 'error')
        self.errorOccured.emit()

    # --- navigation -------------------------------------------------------
    @Slot()
    def reset(self):
        self._forward = []
        self._history = ['']
        self._set_data([])

    @Slot()
    def refresh(self):
        self._list_current()

    @Slot(str)
    def cd(self, name):
        self._pushd(name)
        self._list_current()

    def _pushd(self, name):
        if self._forward:
            if self._forward[-1] != name:
                self._forward = []
            else:
                self._forward.pop()
        self._history.append(name)

    def _popd(self):
        if len(self._history) == 1:
            return
        self._forward.append(self._history.pop())

    @Slot()
    def historyForward(self):
        if not self._forward:
            return
        self._pushd(self._forward[-1])
        self._list_current()

    @Slot()
    def historyBack(self):
        self._popd()
        self._list_current()

    def _list_current(self):
        self._list_seq += 1
        seq = self._list_seq
        if self._path() == '/':
            self._set_root()
            self.currentPathChanged.emit()
            return
        path = self._path()

        def work(_):
            return self._fs.request({'op': 'list', 'path': path})['entries']

        def done(entries, err):
            if seq != self._list_seq:
                return
            if err:
                if 'No such' in err:
                    self.reset()
                    self._list_current()
                else:
                    self._fail(err)
                return
            base = path.rstrip('/')
            self._set_data([{'name': e['name'], 'path': base + '/' + e['name'], 'dir': e['dir'],
                             'size': e['size']} for e in entries])
            self.currentPathChanged.emit()
        self._run(work, done)

    # --- operations ---------------------------------------------------------
    def _op(self, work, progress=False):
        def done(res, err):
            if err:
                self._fail(err)
            self._list_current()
        self._run(work, done, progress, pause=True)

    @Slot(str, str)
    def rename(self, old, new):
        path, name = self._abs(old), new
        self._op(lambda p: self._fs.request({'op': 'rename', 'path': path, 'name': name}))

    @Slot(str, bool)
    def remove(self, name, recursive=False):
        path = self._abs(name)
        self._op(lambda p: self._fs.request({'op': 'remove', 'path': path, 'recursive': True}))

    @Slot()
    def beginMkDir(self):
        n = len(self._data)
        self.beginInsertRows(QModelIndex(), n, n)
        self._data.append({'name': 'New Folder', 'path': '', 'dir': True, 'size': 0})
        self.endInsertRows()
        self._set_new_index(n)

    @Slot(str)
    def commitMkDir(self, name):
        self._set_new_index(NEW_DIR_INVALID)
        path = self._abs(name)
        self._op(lambda p: self._fs.request({'op': 'mkdir', 'path': path}))

    def _local(self, url):
        if isinstance(url, QUrl):
            return url.toLocalFile()
        return QUrl(str(url)).toLocalFile()

    @Slot('QVariantList')
    def upload(self, urls):
        dest = self._path()
        self._upload_to(dest, urls)

    @Slot(str, 'QVariantList')
    def uploadTo(self, remote_dir, urls):
        self._pushd(remote_dir)
        self._upload_to(self._path(), urls)

    def _upload_to(self, dest, urls):
        files = [self._local(u) for u in urls]
        files = [f for f in files if f]
        if not files:
            return
        use_wsl = not self._fs.cfg.local_fs

        def work(prog):
            for i, f in enumerate(files):
                name = os.path.basename(f.rstrip('/\\'))
                src = wsl_path(f) if use_wsl else f
                self._fs.request({'op': 'put', 'src': src, 'dst': dest.rstrip('/') + '/' + name},
                                 (lambda p, i=i: prog((i + p) / len(files))) if prog else None)
        self._op(work, True)

    @Slot(str, QUrl, bool)
    def download(self, name, local_url, recursive=False):
        remote = self._abs(name)
        local = local_url.toLocalFile()
        if recursive:
            local = os.path.join(local, name)
        use_wsl = not self._fs.cfg.local_fs
        dst = wsl_path(local) if use_wsl else local

        def work(prog):
            self._fs.request({'op': 'get', 'src': remote, 'dst': dst}, prog)

        def done(res, err):
            if err:
                self._fail(err)
        self._run(work, done, True)

    @Slot('QVariantList', result=bool)
    def isTooLarge(self, urls):
        total = 0
        for u in urls:
            p = self._local(u)
            if os.path.isfile(p):
                total += os.path.getsize(p)
            elif os.path.isdir(p):
                for root, _, files in os.walk(p):
                    for f in files:
                        try:
                            total += os.path.getsize(os.path.join(root, f))
                        except OSError:
                            pass
        return total > MAX_UPLOAD_SIZE_BYTES


class UpdateModel(QAbstractListModel):
    """Empty model: an emulator has no firmware update channels."""

    def rowCount(self, parent=QModelIndex()):
        return 0

    def data(self, index, role=Qt.DisplayRole):
        return None

    def roleNames(self):
        return {Qt.UserRole: QByteArray(b'name')}

    @Property(int, constant=True)
    def count(self):
        return 0


class ApplicationBackend(QObject):
    backendStateChanged = Signal()
    currentDeviceChanged = Signal()
    firmwareUpdateStateChanged = Signal()
    errorTypeChanged = Signal()
    isQueryInProgressChanged = Signal()

    @QEnum
    class BackendState(IntEnum):
        WaitingForDevices = 0
        Ready = 1
        ScreenStreaming = 2
        UpdatingDevice = 3
        RepairingDevice = 4
        CreatingBackup = 5
        RestoringBackup = 6
        FactoryResetting = 7
        InstallingFirmware = 8
        InstallingWirelessStack = 9
        InstallingFUS = 10
        Finished = 11
        ErrorOccured = 0xff

    @QEnum
    class FirmwareUpdateState(IntEnum):
        Unknown = 0
        Checking = 1
        CanUpdate = 2
        CanInstall = 3
        CanRepair = 4
        NoUpdates = 5
        ErrorOccured = 0xff

    def __init__(self, cfg, prefs):
        QObject.__init__(self)
        self.cfg = cfg
        self.monitor = Monitor(cfg.port, cfg.no_monitor)
        self.fs = FsClient(cfg)
        self._state = int(ApplicationBackend.BackendState.WaitingForDevices)
        self._error = int(BackendError.ErrorType.NoError)
        self._dev = DeviceState(cfg)
        self._streamer = ScreenStreamer(cfg, self.monitor)
        self._fm = FileManager(self.fs, self.monitor, prefs, self._dev)
        self._model = UpdateModel()
        self._latest = make_map(self, {'number': '', 'changelog': ''})
        self._streamer.firstFrame.connect(self._on_first_frame)
        self._fm.errorOccured.connect(self._on_fm_error)
        self._prev_for_stream = int(ApplicationBackend.BackendState.Ready)

    # --- properties --------------------------------------------------------
    @Property(int, notify=backendStateChanged)
    def backendState(self):
        return self._state

    @Property(QObject, notify=currentDeviceChanged)
    def deviceState(self):
        if self._state == int(ApplicationBackend.BackendState.WaitingForDevices):
            return None
        return self._dev

    @Property(QObject, constant=True)
    def screenStreamer(self):
        return self._streamer

    @Property(QObject, constant=True)
    def fileManager(self):
        return self._fm

    @Property(int, notify=firmwareUpdateStateChanged)
    def firmwareUpdateState(self):
        return int(ApplicationBackend.FirmwareUpdateState.NoUpdates)

    @Property(QObject, constant=True)
    def firmwareUpdateModel(self):
        return self._model

    @Property(QObject, notify=firmwareUpdateStateChanged)
    def latestFirmwareVersion(self):
        return self._latest

    @Property(int, notify=errorTypeChanged)
    def errorType(self):
        return self._error

    @Property(bool, notify=isQueryInProgressChanged)
    def isQueryInProgress(self):
        return self._state == int(ApplicationBackend.BackendState.WaitingForDevices)

    # --- state ---------------------------------------------------------------
    def _set_state(self, s):
        s = int(s)
        if s == self._state:
            return
        was_waiting = self._state == int(ApplicationBackend.BackendState.WaitingForDevices)
        self._state = s
        self.backendStateChanged.emit()
        self.isQueryInProgressChanged.emit()
        if was_waiting or s == int(ApplicationBackend.BackendState.WaitingForDevices):
            self.currentDeviceChanged.emit()

    def _set_error(self, typ, message):
        self._error = int(typ)
        self._dev._error = True
        self._dev._errorString = message
        self._dev.isErrorChanged.emit()
        self.errorTypeChanged.emit()
        log(message, 'error')
        self._set_state(ApplicationBackend.BackendState.ErrorOccured)

    def _on_first_frame(self):
        log('The emulated Flipper Zero is up.')
        self._set_state(ApplicationBackend.BackendState.Ready)
        self._fm.reset()
        self.refreshStorageInfo()

    def _on_fm_error(self):
        self._set_error(BackendError.ErrorType.OperationError, self._fm.error_string())

    # --- invokables ------------------------------------------------------------
    @Slot()
    def mainAction(self):
        log('Firmware updates are not available in the emulator. Choose another firmware and start it again.', 'warn')

    @Slot()
    def factoryReset(self):
        log('Erase is not available in the emulator. Use "Reset Flash" in the launcher.', 'warn')

    @Slot(QUrl)
    def installFirmware(self, url):
        log('Installing firmware files is not available in the emulator.', 'warn')

    @Slot(QUrl)
    def installWirelessStack(self, url):
        log('The wireless stack does not exist in the emulator.', 'warn')

    @Slot(QUrl, int)
    def installFUS(self, url, address):
        log('The wireless stack does not exist in the emulator.', 'warn')

    @Slot(QUrl)
    def createBackup(self, url):
        self._backup_job(url.toLocalFile(), True)

    @Slot(QUrl)
    def restoreBackup(self, url):
        self._backup_job(url.toLocalFile(), False)

    def _backup_job(self, local, make):
        use_wsl = not self.cfg.local_fs
        path = wsl_path(local) if use_wsl else local
        self._dev.set_progress(-1.0)
        self._dev.set_status('Saving the SD card ...' if make else 'Restoring the SD card ...')
        self._set_state(ApplicationBackend.BackendState.CreatingBackup if make
                        else ApplicationBackend.BackendState.RestoringBackup)

        def prog(p):
            post(lambda: self._dev.set_progress(p))

        def job():
            err = None
            try:
                if make:
                    self.fs.request({'op': 'backup', 'dst': path}, prog)
                else:
                    with self.monitor.paused():
                        self.fs.request({'op': 'restore', 'src': path}, prog)
            except FsError as ex:
                err = str(ex)
            except Exception as ex:
                err = 'Internal error: %r' % (ex,)

            def finish():
                if err:
                    self._set_error(BackendError.ErrorType.BackupError, err)
                else:
                    log('Backup finished.' if make else 'Restore finished.')
                    self._set_state(ApplicationBackend.BackendState.Finished)
                    QTimer.singleShot(1800, self.finalizeOperation)
            post(finish)
        threading.Thread(target=job, daemon=True).start()

    @Slot()
    def startFullScreenStreaming(self):
        self._streamer.isEnabled = True
        self._set_state(ApplicationBackend.BackendState.ScreenStreaming)

    @Slot()
    def stopFullScreenStreaming(self):
        self._set_state(ApplicationBackend.BackendState.Ready)

    @Slot()
    def refreshStorageInfo(self):
        def job():
            try:
                info = self.fs.request({'op': 'info'})
                ex = self.fs.request({'op': 'exists', 'path': '/ext/Manifest'})
                total = max(1, info['total'])
                pct = int(round(info['free'] * 100.0 / total))
                post(lambda: self._dev.set_storage(pct, True, ex.get('exists', False)))
            except Exception as e:
                post(lambda: (self._dev.set_storage(0, False, False),
                              log('SD card not available: %s' % e, 'warn')))
        threading.Thread(target=job, daemon=True).start()

    @Slot()
    def checkFirmwareUpdates(self):
        pass

    @Slot()
    def finalizeOperation(self):
        if self._state in (int(ApplicationBackend.BackendState.Finished),
                           int(ApplicationBackend.BackendState.ErrorOccured)):
            self._error = int(BackendError.ErrorType.NoError)
            self._dev._error = False
            self._dev._errorString = ''
            self._dev.isErrorChanged.emit()
            self.errorTypeChanged.emit()
            self._set_state(ApplicationBackend.BackendState.Ready)
            self._fm.refresh()
            self.refreshStorageInfo()

    def shutdown(self):
        self._streamer.stop()
        self.monitor.release_all()
        self.monitor.close()
        self.fs.stop()


class App(QObject):
    updateStatusChanged = Signal()
    messageReceived = Signal()
    applicationNameChanged = Signal()
    applicationVersionChanged = Signal()

    @QEnum
    class UpdateStatus(IntEnum):
        NoUpdates = 0
        Checking = 1
        CanUpdate = 2

    def __init__(self):
        QObject.__init__(self)
        self._updater = ApplicationUpdater()

    @Property(str, notify=applicationNameChanged)
    def name(self):
        return APP_NAME

    @Property(str, notify=applicationVersionChanged)
    def version(self):
        return APP_VERSION

    @Property(str, constant=True)
    def commit(self):
        return ''

    @Property(QObject, constant=True)
    def updater(self):
        return self._updater

    @Property(QUrl, constant=True)
    def noticeUrl(self):
        for cand in (os.path.join(os.path.dirname(os.path.abspath(__file__)), 'NOTICE.txt'),):
            if os.path.exists(cand):
                return QUrl.fromLocalFile(cand)
        return QUrl('https://github.com/flipperdevices/qFlipper')

    @Property(bool, constant=True)
    def isDeveloperMode(self):
        return False

    @Property(int, notify=updateStatusChanged)
    def updateStatus(self):
        return 0

    @Slot()
    def selfUpdate(self):
        pass

    @Slot()
    def checkForUpdates(self):
        pass


# ===================================================================== main
def parse_args(argv):
    ap = argparse.ArgumentParser(description=APP_NAME)
    ap.add_argument('--fb', default=r'\\wsl.localhost\FlipperOne\tmp\flipper_fb.raw')
    ap.add_argument('--sd-img', default='/root/flipper-zero-emulator/sdcard/sdcard.img')
    ap.add_argument('--distro', default='FlipperOne')
    ap.add_argument('--helper', default=os.path.join(os.path.dirname(os.path.abspath(__file__)), 'flipfs.py'))
    ap.add_argument('--local-fs', action='store_true', help='run the SD helper locally (testing)')
    ap.add_argument('--port', type=int, default=1234)
    ap.add_argument('--fw-name', default='Emulator')
    ap.add_argument('--fw-version', default='emulated')
    ap.add_argument('--fw-branch', default='release')
    ap.add_argument('--fw-date', default='')
    ap.add_argument('--data-dir', default='')
    ap.add_argument('--rcc', default=os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ui.rcc'))
    ap.add_argument('--shot', default='', help='save a screenshot and quit (testing)')
    ap.add_argument('--no-monitor', action='store_true')
    ap.add_argument('--remote-cmd', default='', help='JSON list: command prefix that runs the SD helper in the VM (macOS)')
    ap.add_argument('--share-map', default='', help='HOSTDIR=VMDIR of the folder shared with the VM (macOS)')
    ns = ap.parse_args(argv)
    if not ns.data_dir:
        base = os.environ.get('LOCALAPPDATA') or os.path.expanduser('~/.local/share')
        ns.data_dir = os.path.join(base, 'FlipperOneDemo', 'zero-ui')
    return ns


def _fix_std_streams(data_dir):
    # pythonw.exe has no console: keep print()/tracebacks from crashing the program.
    try:
        os.makedirs(data_dir, exist_ok=True)
        if sys.stdout is None:
            sys.stdout = open(os.path.join(data_dir, 'stdout.log'), 'a', encoding='utf-8', errors='replace')
        if sys.stderr is None:
            sys.stderr = open(os.path.join(data_dir, 'stderr.log'), 'a', encoding='utf-8', errors='replace')
    except Exception:
        class _Null(object):
            def write(self, *_):
                return 0

            def flush(self):
                pass
        if sys.stdout is None:
            sys.stdout = _Null()
        if sys.stderr is None:
            sys.stderr = _Null()


def main(argv=None, hook=None):
    global LOG, DISPATCH
    ns = parse_args(sys.argv[1:] if argv is None else argv)
    _fix_std_streams(ns.data_dir)
    cfg = Config(ns)
    QCoreApplication.setOrganizationName('FlipperEmulator')
    QCoreApplication.setApplicationName(APP_NAME)
    QGuiApplication.setApplicationDisplayName(APP_NAME)
    QQuickWindow.setDefaultAlphaBuffer(True)
    QQuickWindow.setTextRenderType(QQuickWindow.NativeTextRendering)
    app = QApplication([sys.argv[0]])
    app.setApplicationVersion(APP_VERSION)
    DISPATCH = Dispatcher()
    LOG = Logger(cfg.data_dir)
    log('%s %s' % (APP_NAME, APP_VERSION))

    if not QResource.registerResource(cfg.rcc):
        sys.stderr.write('Cannot load the interface resources: %s\n' % cfg.rcc)
        return 2
    app.setWindowIcon(QIcon(':/assets/icons/app.png'))
    for f in ('haxrcorp-4089.ttf', 'Born2bSportyV2.ttf', 'ProggySquare.ttf', 'ShareTech-Regular.ttf',
              'ShareTechMono-Regular.ttf'):
        QFontDatabase.addApplicationFont(':/assets/fonts/' + f)
    QQuickStyle.setStyle('DefaultAmber')

    prefs = Preferences()
    dialog = SystemFileDialog(prefs)
    backend = ApplicationBackend(cfg, prefs)
    appobj = App()

    qmlRegisterType(ScreenCanvas, 'QFlipper', 1, 0, 'ScreenCanvas')
    qmlRegisterUncreatableType(BackendError, 'QFlipper', 1, 0, 'BackendError', 'enum container')
    qmlRegisterUncreatableType(InputEvent, 'QFlipper', 1, 0, 'InputEvent', 'enum container')
    qmlRegisterUncreatableType(ApplicationBackend, 'QFlipper', 1, 0, 'ApplicationBackend', 'created by the app')
    qmlRegisterUncreatableType(ApplicationUpdater, 'QFlipper', 1, 0, 'ApplicationUpdater', 'created by the app')
    qmlRegisterSingletonInstance(Logger, 'QFlipper', 1, 0, 'Logger', LOG)
    qmlRegisterSingletonInstance(Preferences, 'QFlipper', 1, 0, 'Preferences', prefs)
    qmlRegisterSingletonInstance(ApplicationBackend, 'QFlipper', 1, 0, 'Backend', backend)
    qmlRegisterSingletonInstance(App, 'QFlipper', 1, 0, 'App', appobj)
    qmlRegisterSingletonInstance(SystemFileDialog, 'QFlipper', 1, 0, 'SystemFileDialog', dialog)

    engine = QQmlApplicationEngine()
    engine.addImportPath(':/imports')
    engine.addImportPath(':/styles')
    ctx = engine.rootContext()
    ctx.setContextProperty('qVersionMajor', 6)
    ctx.setContextProperty('qVersionMinor', 0)
    ctx.setContextProperty('qVersionPatch', 0)
    engine.load(QUrl('qrc:/main.qml'))
    if not engine.rootObjects():
        sys.stderr.write('The interface could not be loaded.\n')
        return 3

    try:
        w0 = engine.rootObjects()[0]
        w0.raise_()
        w0.requestActivate()
    except Exception:
        pass

    if cfg.shot:
        win = engine.rootObjects()[0]

        def shoot():
            img = win.grabWindow()
            img.save(cfg.shot)
            app.quit()
        QTimer.singleShot(int(os.environ.get('FLIPEMU_SHOT_MS', '2500')), shoot)

    if hook:
        hook(app, engine.rootObjects()[0], backend, engine)
    app.aboutToQuit.connect(backend.shutdown)
    rc = app.exec()
    backend.shutdown()
    return rc


def _crash_report(text):
    try:
        base = os.environ.get('LOCALAPPDATA') or os.path.expanduser('~/.local/share')
        d = os.path.join(base, 'FlipperOneDemo', 'zero-ui')
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, 'crash.log'), 'a', encoding='utf-8') as fh:
            fh.write('[%s]\n%s\n' % (time.strftime('%Y-%m-%d %H:%M:%S'), text))
    except Exception:
        pass
    if IS_WINDOWS:
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, 'The Flipper Emulator window could not start.\n\n' + text[-900:],
                                             APP_NAME, 0x10)
        except Exception:
            pass


if __name__ == '__main__':
    try:
        rc = main()
    except SystemExit:
        raise
    except BaseException:
        import traceback
        _crash_report(traceback.format_exc())
        rc = 1
    sys.exit(rc)
