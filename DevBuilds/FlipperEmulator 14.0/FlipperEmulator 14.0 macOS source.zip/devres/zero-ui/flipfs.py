#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
flipfs - tiny FAT32 helper for the emulated Flipper Zero SD card image.

Runs inside the Linux environment (WSL) next to the emulator, reads JSON
requests (one per line) on stdin and answers with JSON lines on stdout.
Only the Python standard library is used. Pure FAT32 code: no mount, no root.

Part of Flipper Emulator. Original code (GPL-3.0-or-later).
"""
import json
import os
import struct
import sys
import tarfile
import time

ATTR_RO, ATTR_HID, ATTR_SYS, ATTR_VOL, ATTR_DIR, ATTR_ARC = 0x01, 0x02, 0x04, 0x08, 0x10, 0x20
EOC = 0x0FFFFFF8
CHUNK = 1024 * 1024


class FatError(Exception):
    pass


class Entry(object):
    __slots__ = ('name', 'short', 'attr', 'cluster', 'size', 'slots', 'dir_cluster',
                 'ctime', 'cdate', 'wtime', 'wdate', 'adate')

    @property
    def is_dir(self):
        return bool(self.attr & ATTR_DIR)


def lfn_checksum(short11):
    s = 0
    for c in short11:
        s = ((((s & 1) << 7) + (s >> 1) + c) & 0xFF)
    return s


def fat_now():
    t = time.localtime()
    date = ((max(t.tm_year, 1980) - 1980) << 9) | (t.tm_mon << 5) | t.tm_mday
    tm = (t.tm_hour << 11) | (t.tm_min << 5) | (t.tm_sec // 2)
    return tm, date


_SHORT_OK = set("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!#$%&'()-@^_`{}~")


def _is_plain_short(name):
    if name in ('.', '..') or not name:
        return None
    if name.count('.') > 1:
        return None
    if '.' in name:
        base, ext = name.split('.')
    else:
        base, ext = name, ''
    if not (1 <= len(base) <= 8) or len(ext) > 3:
        return None
    for ch in base + ext:
        if ch not in _SHORT_OK:
            return None
    return (base.ljust(8) + ext.ljust(3)).encode('ascii')


class Fat32(object):
    def __init__(self, path):
        self.path = path
        self.f = open(path, 'r+b', buffering=0)
        self.base = 0
        boot = self._rd(0, 512)
        if boot[510:512] != b'\x55\xaa':
            raise FatError('The SD card image has no valid boot sector.')
        if boot[0] not in (0xEB, 0xE9):
            # Looks like a partition table: use the first usable partition.
            ptype = boot[450]
            if ptype in (0x0B, 0x0C):
                self.base = struct.unpack_from('<I', boot, 454)[0] * 512
                boot = self._rd(0, 512)
                if boot[510:512] != b'\x55\xaa':
                    raise FatError('The SD card image has no valid FAT32 partition.')
            else:
                raise FatError('The SD card image is not FAT32.')
        self.bps = struct.unpack_from('<H', boot, 11)[0]
        self.spc = boot[13]
        self.rsvd = struct.unpack_from('<H', boot, 14)[0]
        self.nfats = boot[16]
        root_ent = struct.unpack_from('<H', boot, 17)[0]
        tot16 = struct.unpack_from('<H', boot, 19)[0]
        fatsz16 = struct.unpack_from('<H', boot, 22)[0]
        tot32 = struct.unpack_from('<I', boot, 32)[0]
        self.fatsz = struct.unpack_from('<I', boot, 36)[0]
        self.root = struct.unpack_from('<I', boot, 44)[0]
        self.fsinfo_sec = struct.unpack_from('<H', boot, 48)[0]
        if root_ent != 0 or fatsz16 != 0 or self.fatsz == 0 or self.bps not in (512, 1024, 2048, 4096) \
                or self.spc == 0 or (self.spc & (self.spc - 1)):
            raise FatError('Only FAT32 SD card images are supported.')
        total = tot32 or tot16
        self.cs = self.bps * self.spc
        self.fat_off = self.rsvd * self.bps
        self.data_off = (self.rsvd + self.nfats * self.fatsz) * self.bps
        data_sectors = total - self.rsvd - self.nfats * self.fatsz
        self.ncl = data_sectors // self.spc
        self.maxc = self.ncl + 1
        self.free_count = None
        self.next_free = 2
        self.dirty_fsinfo = False
        self.label = ''

    # ----------------------------------------------------------------- raw IO
    def _rd(self, off, n):
        self.f.seek(self.base + off)
        data = self.f.read(n)
        if len(data) < n:
            data += b'\x00' * (n - len(data))
        return data

    def _wr(self, off, data):
        self.f.seek(self.base + off)
        self.f.write(data)

    def close(self):
        try:
            self.f.close()
        except Exception:
            pass

    def cluster_off(self, c):
        return self.data_off + (c - 2) * self.cs

    def read_cluster(self, c):
        return self._rd(self.cluster_off(c), self.cs)

    def write_cluster(self, c, data):
        if len(data) < self.cs:
            data = data + b'\x00' * (self.cs - len(data))
        self._wr(self.cluster_off(c), data)

    # -------------------------------------------------------------------- FAT
    def fat_get(self, c):
        return struct.unpack('<I', self._rd(self.fat_off + c * 4, 4))[0] & 0x0FFFFFFF

    def fat_set(self, c, v):
        old = struct.unpack('<I', self._rd(self.fat_off + c * 4, 4))[0]
        new = (old & 0xF0000000) | (v & 0x0FFFFFFF)
        raw = struct.pack('<I', new)
        for i in range(self.nfats):
            self._wr(self.fat_off + i * self.fatsz * self.bps + c * 4, raw)

    def chain(self, first):
        c = first
        n = 0
        while 2 <= c <= self.maxc:
            yield c
            n += 1
            if n > self.ncl + 2:
                raise FatError('The SD card file system is damaged (cluster loop).')
            c = self.fat_get(c)
            if c >= EOC:
                return
        return

    def _scan_free(self, start, limit_clusters):
        """Yield free cluster numbers, beginning at `start`, wrapping around once."""
        total = self.ncl
        c = start
        seen = 0
        per = 16384
        while seen < total:
            if c > self.maxc:
                c = 2
            count = min(per, self.maxc - c + 1, total - seen)
            raw = self._rd(self.fat_off + c * 4, count * 4)
            vals = struct.unpack('<%dI' % count, raw)
            for i, v in enumerate(vals):
                if (v & 0x0FFFFFFF) == 0:
                    yield c + i
            c += count
            seen += count

    def count_free(self):
        n = 0
        c = 2
        per = 65536
        while c <= self.maxc:
            count = min(per, self.maxc - c + 1)
            raw = self._rd(self.fat_off + c * 4, count * 4)
            vals = struct.unpack('<%dI' % count, raw)
            for v in vals:
                if (v & 0x0FFFFFFF) == 0:
                    n += 1
            c += count
        return n

    def begin(self):
        """Called before each request: reload what the emulated firmware may have changed."""
        self.free_count = None
        self.next_free = 2
        if self.fsinfo_sec:
            raw = self._rd(self.fsinfo_sec * self.bps, 512)
            if raw[0:4] == b'RRaA' and raw[484:488] == b'rrAa':
                fc, nf = struct.unpack_from('<II', raw, 488)
                if fc != 0xFFFFFFFF and fc <= self.ncl:
                    self.free_count = fc
                if 2 <= nf <= self.maxc:
                    self.next_free = nf
        self.dirty_fsinfo = False

    def get_free_count(self):
        if self.free_count is None:
            self.free_count = self.count_free()
        return self.free_count

    def flush(self):
        if self.dirty_fsinfo and self.fsinfo_sec:
            off = self.fsinfo_sec * self.bps
            raw = self._rd(off, 512)
            if raw[0:4] == b'RRaA' and raw[484:488] == b'rrAa':
                # exact count (the value stored by the firmware may be stale)
                self.free_count = self.count_free()
                self._wr(off + 488, struct.pack('<II', self.free_count, self.next_free))
        self.dirty_fsinfo = False
        try:
            os.fsync(self.f.fileno())
        except Exception:
            pass

    def alloc(self, n):
        if n <= 0:
            return []
        got = []
        for c in self._scan_free(self.next_free, n):
            got.append(c)
            if len(got) == n:
                break
        if len(got) < n:
            raise FatError('The SD card is full.')
        for i, c in enumerate(got):
            self.fat_set(c, got[i + 1] if i + 1 < n else 0x0FFFFFFF)
        self.next_free = got[-1] + 1 if got[-1] + 1 <= self.maxc else 2
        self.dirty_fsinfo = True
        return got

    def extend(self, last, n):
        new = self.alloc(n)
        self.fat_set(last, new[0])
        return new

    def free_chain(self, first):
        if first < 2:
            return
        cl = list(self.chain(first))
        for c in cl:
            self.fat_set(c, 0)
        self.dirty_fsinfo = True

    # -------------------------------------------------------------- directory
    @staticmethod
    def _short_text(raw11, nt):
        b = bytearray(raw11[:11])
        if b[0] == 0x05:
            b[0] = 0xE5
        base = bytes(b[:8]).decode('cp437', 'replace').rstrip(' ')
        ext = bytes(b[8:11]).decode('cp437', 'replace').rstrip(' ')
        if nt & 0x08:
            base = base.lower()
        if nt & 0x10:
            ext = ext.lower()
        return base + ('.' + ext if ext else '')

    def read_dir(self, first):
        """Return the list of entries (without '.' and '..') of a directory."""
        out = []
        lfn = []
        ended = False
        for cl in self.chain(first):
            if ended:
                break
            data = self.read_cluster(cl)
            base = self.cluster_off(cl)
            for i in range(0, len(data), 32):
                e = data[i:i + 32]
                if e[0] == 0x00:
                    ended = True
                    break
                if e[0] == 0xE5:
                    lfn = []
                    continue
                attr = e[11]
                if (attr & 0x3F) == 0x0F:
                    seq = e[0]
                    chars = e[1:11] + e[14:26] + e[28:32]
                    lfn.append((seq & 0x1F, chars, e[13], base + i, bool(seq & 0x40)))
                    continue
                if attr & ATTR_VOL:
                    lfn = []
                    continue
                ent = Entry()
                ent.short = bytes(e[0:11])
                ent.attr = attr
                ent.ctime, ent.cdate = struct.unpack_from('<HH', e, 14)
                ent.adate = struct.unpack_from('<H', e, 18)[0]
                hi = struct.unpack_from('<H', e, 20)[0]
                ent.wtime, ent.wdate = struct.unpack_from('<HH', e, 22)
                lo = struct.unpack_from('<H', e, 26)[0]
                ent.cluster = (hi << 16) | lo
                ent.size = struct.unpack_from('<I', e, 28)[0]
                ent.dir_cluster = first
                name = None
                slots = [base + i]
                if lfn:
                    chk = lfn_checksum(ent.short)
                    parts = sorted(lfn, key=lambda x: x[0])
                    if all(p[2] == chk for p in parts) and [p[0] for p in parts] == list(range(1, len(parts) + 1)):
                        raw = b''.join(p[1] for p in parts)
                        txt = raw.decode('utf-16-le', 'replace')
                        k = txt.find('\x00')
                        if k >= 0:
                            txt = txt[:k]
                        name = txt
                        slots = [p[3] for p in sorted(lfn, key=lambda x: -x[0])] + slots
                if name is None:
                    name = self._short_text(ent.short, e[12])
                lfn = []
                ent.name = name
                ent.slots = slots
                if name in ('.', '..'):
                    continue
                out.append(ent)
        return out

    def find_in(self, dir_cluster, name):
        low = name.lower()
        for e in self.read_dir(dir_cluster):
            if e.name.lower() == low:
                return e
        return None

    @staticmethod
    def split_path(path):
        parts = [p for p in path.replace('\\', '/').split('/') if p and p != '.']
        for p in parts:
            if p == '..':
                raise FatError('Invalid path.')
        return parts

    def resolve(self, path):
        """Return (cluster, entry_or_None) of a path; the root has entry None."""
        parts = self.split_path(path)
        cluster = self.root
        ent = None
        for i, p in enumerate(parts):
            if ent is not None and not ent.is_dir:
                raise FatError('Not a directory: ' + '/'.join(parts[:i]))
            e = self.find_in(cluster, p)
            if e is None:
                raise FatError('No such file or directory: /' + '/'.join(parts[:i + 1]))
            ent = e
            cluster = e.cluster
        return cluster, ent

    def resolve_parent(self, path):
        parts = self.split_path(path)
        if not parts:
            raise FatError('Invalid path.')
        name = parts[-1]
        cluster = self.root
        for i, p in enumerate(parts[:-1]):
            e = self.find_in(cluster, p)
            if e is None:
                raise FatError('No such directory: /' + '/'.join(parts[:i + 1]))
            if not e.is_dir:
                raise FatError('Not a directory: /' + '/'.join(parts[:i + 1]))
            cluster = e.cluster
        return cluster, name

    # ------------------------------------------------------------ entry write
    def _free_slots(self, dir_cluster, count):
        run = []
        ended = False
        last = dir_cluster
        for cl in self.chain(dir_cluster):
            last = cl
            data = self.read_cluster(cl)
            base = self.cluster_off(cl)
            for i in range(0, len(data), 32):
                b0 = data[i]
                if b0 == 0x00:
                    ended = True
                if ended or b0 == 0xE5:
                    run.append(base + i)
                    if len(run) == count:
                        return run
                else:
                    run = []
        while len(run) < count:
            new = self.extend(last, 1)[0]
            self.write_cluster(new, b'')
            last = new
            base = self.cluster_off(new)
            for i in range(0, self.cs, 32):
                run.append(base + i)
                if len(run) == count:
                    return run
        return run

    def _make_names(self, dir_cluster, name):
        if not name or len(name) > 255 or name.strip(' .') == '':
            raise FatError('Invalid file name.')
        for ch in name:
            if ch in '\\/:*?"<>|' or ord(ch) < 32:
                raise FatError('Invalid character in the file name: %r' % ch)
        plain = _is_plain_short(name)
        if plain is not None:
            return plain, False
        existing = set(e.short for e in self.read_dir(dir_cluster))
        stripped = name.lstrip('. ')
        up = stripped.upper()
        if '.' in up:
            base, _, ext = up.rpartition('.')
        else:
            base, ext = up, ''

        def clean(s, n):
            o = ''
            for ch in s.replace(' ', ''):
                if ch in _SHORT_OK:
                    o += ch
                elif ch == '.':
                    continue
                else:
                    o += '_'
            return o[:n]

        b = clean(base, 8) or '_'
        x = clean(ext, 3)
        for n in range(1, 1000000):
            tail = '~%d' % n
            cand = (b[:8 - len(tail)] + tail).ljust(8) + x.ljust(3)
            raw = cand.encode('ascii')
            if raw not in existing:
                return raw, True
        raise FatError('Cannot create a short name.')

    def _write_entry(self, dir_cluster, name, attr, cluster, size, times=None):
        short, need_lfn = self._make_names(dir_cluster, name)
        entries = []
        if need_lfn:
            u = name.encode('utf-16-le')
            chars = [u[i:i + 2] for i in range(0, len(u), 2)]
            chk = lfn_checksum(short)
            n = (len(chars) + 12) // 13
            chars = chars + [b'\x00\x00'] + [b'\xff\xff'] * (n * 13 - len(chars) - 1)
            chars = chars[:n * 13]
            for seq in range(n, 0, -1):
                part = b''.join(chars[(seq - 1) * 13: seq * 13])
                ent = bytearray(32)
                ent[0] = seq | (0x40 if seq == n else 0)
                ent[1:11] = part[0:10]
                ent[11] = 0x0F
                ent[13] = chk
                ent[14:26] = part[10:22]
                ent[28:32] = part[22:26]
                entries.append(bytes(ent))
        tm, dt = fat_now()
        if times:
            ctime, cdate, wtime, wdate = times
        else:
            ctime = wtime = tm
            cdate = wdate = dt
        s = bytearray(32)
        s[0:11] = short
        s[11] = attr
        struct.pack_into('<HH', s, 14, ctime, cdate)
        struct.pack_into('<H', s, 18, cdate)
        struct.pack_into('<H', s, 20, (cluster >> 16) & 0xFFFF)
        struct.pack_into('<HH', s, 22, wtime, wdate)
        struct.pack_into('<H', s, 26, cluster & 0xFFFF)
        struct.pack_into('<I', s, 28, size)
        entries.append(bytes(s))
        slots = self._free_slots(dir_cluster, len(entries))
        for off, raw in zip(slots, entries):
            self._wr(off, raw)

    def _kill_entry(self, ent):
        for off in ent.slots:
            self._wr(off, b'\xe5')

    # ------------------------------------------------------------- operations
    def listdir(self, path):
        cluster, ent = self.resolve(path)
        if ent is not None and not ent.is_dir:
            raise FatError('Not a directory.')
        res = self.read_dir(cluster)
        res.sort(key=lambda e: (not e.is_dir, e.name.lower()))
        return res

    def stat(self, path):
        cluster, ent = self.resolve(path)
        return ent

    def mkdir(self, path, exist_ok=False):
        parent, name = self.resolve_parent(path)
        old = self.find_in(parent, name)
        if old is not None:
            if exist_ok and old.is_dir:
                return
            raise FatError('Already exists: ' + name)
        c = self.alloc(1)[0]
        zero = bytearray(self.cs)
        tm, dt = fat_now()

        def dot(nm, cl):
            e = bytearray(32)
            e[0:11] = nm
            e[11] = ATTR_DIR
            struct.pack_into('<HH', e, 14, tm, dt)
            struct.pack_into('<H', e, 18, dt)
            struct.pack_into('<H', e, 20, (cl >> 16) & 0xFFFF)
            struct.pack_into('<HH', e, 22, tm, dt)
            struct.pack_into('<H', e, 26, cl & 0xFFFF)
            return bytes(e)

        zero[0:32] = dot(b'.          ', c)
        zero[32:64] = dot(b'..         ', 0 if parent == self.root else parent)
        self.write_cluster(c, bytes(zero))
        self._write_entry(parent, name, ATTR_DIR, c, 0)

    def makedirs(self, path):
        cur = ''
        for p in self.split_path(path):
            cur += '/' + p
            self.mkdir(cur, exist_ok=True)

    def remove(self, path, recursive=False):
        parent, name = self.resolve_parent(path)
        ent = self.find_in(parent, name)
        if ent is None:
            raise FatError('No such file or directory: ' + name)
        self._remove_entry(ent, recursive)

    def _remove_entry(self, ent, recursive):
        if ent.is_dir:
            kids = self.read_dir(ent.cluster)
            if kids and not recursive:
                raise FatError('The folder is not empty.')
            for k in kids:
                self._remove_entry(k, True)
        self._kill_entry(ent)
        if ent.cluster >= 2:
            self.free_chain(ent.cluster)

    def rename(self, path, new_name):
        parent, name = self.resolve_parent(path)
        ent = self.find_in(parent, name)
        if ent is None:
            raise FatError('No such file or directory: ' + name)
        if ent.name == new_name:
            return
        other = self.find_in(parent, new_name)
        if other is not None and other.slots != ent.slots:
            raise FatError('A file or folder with this name already exists.')
        self._write_entry(parent, new_name, ent.attr, ent.cluster, ent.size,
                          (ent.ctime, ent.cdate, ent.wtime, ent.wdate))
        self._kill_entry(ent)

    def write_file(self, path, reader, size, progress=None):
        """reader: object with read(n). Replaces an existing file."""
        parent, name = self.resolve_parent(path)
        old = self.find_in(parent, name)
        if old is not None and old.is_dir:
            raise FatError('A folder with this name already exists.')
        n = (size + self.cs - 1) // self.cs
        clusters = self.alloc(n)
        written = 0
        i = 0
        while i < len(clusters):
            j = i
            while j + 1 < len(clusters) and clusters[j + 1] == clusters[j] + 1 and (j + 1 - i) * self.cs < CHUNK:
                j += 1
            want = min((j - i + 1) * self.cs, size - written)
            buf = b''
            while len(buf) < want:
                part = reader.read(want - len(buf))
                if not part:
                    break
                buf += part
            if len(buf) < want:
                # source shrank while copying: roll back
                for c in clusters:
                    self.fat_set(c, 0)
                self.dirty_fsinfo = True
                raise FatError('The source file changed while copying.')
            if len(buf) % self.cs:
                buf += b'\x00' * (self.cs - len(buf) % self.cs)
            self._wr(self.cluster_off(clusters[i]), buf)
            written += want
            i = j + 1
            if progress and size:
                progress(min(1.0, written / float(size)))
        if old is not None:
            self._kill_entry(old)
            if old.cluster >= 2:
                self.free_chain(old.cluster)
        self._write_entry(parent, name, ATTR_ARC, clusters[0] if clusters else 0, size)

    def open_read(self, ent):
        return FatReader(self, ent)

    def used_free(self):
        free = self.count_free()
        self.free_count = free
        self.dirty_fsinfo = True
        return self.ncl * self.cs, free * self.cs


class FatReader(object):
    def __init__(self, fs, ent):
        self.fs = fs
        self.left = ent.size
        self.it = fs.chain(ent.cluster) if ent.cluster >= 2 and ent.size else iter(())
        self.buf = b''

    def read(self, n=-1):
        if n is None or n < 0:
            n = self.left + len(self.buf)
        while len(self.buf) < n and self.left > 0:
            try:
                c = next(self.it)
            except StopIteration:
                break
            take = min(self.fs.cs, self.left)
            self.buf += self.fs.read_cluster(c)[:take]
            self.left -= take
        out, self.buf = self.buf[:n], self.buf[n:]
        return out


# ---------------------------------------------------------------------- tree IO
def _fs_path(p):
    p = p.replace('\\', '/')
    if p == '/ext' or p == 'ext':
        return '/'
    if p.startswith('/ext/'):
        return p[4:]
    return p


def put_tree(fs, src, dst, progress=None):
    if os.path.isdir(src):
        fs.mkdir(dst, exist_ok=True)
        for name in sorted(os.listdir(src)):
            put_tree(fs, os.path.join(src, name), dst.rstrip('/') + '/' + name, None)
    else:
        size = os.path.getsize(src)
        with open(src, 'rb') as fh:
            fs.write_file(dst, fh, size, progress)


def get_tree(fs, ent, dst, progress=None):
    if ent.is_dir:
        os.makedirs(dst, exist_ok=True)
        for k in fs.read_dir(ent.cluster):
            get_tree(fs, k, os.path.join(dst, k.name), None)
    else:
        rd = fs.open_read(ent)
        done = 0
        with open(dst, 'wb') as fh:
            while True:
                buf = rd.read(CHUNK)
                if not buf:
                    break
                fh.write(buf)
                done += len(buf)
                if progress and ent.size:
                    progress(min(1.0, done / float(ent.size)))


def tree_size(fs, cluster):
    total = 0
    for e in fs.read_dir(cluster):
        total += tree_size(fs, e.cluster) if e.is_dir else e.size
    return total


def backup_tar(fs, dst, progress=None):
    total = max(1, tree_size(fs, fs.root))
    done = [0]
    with tarfile.open(dst, 'w:gz') as tar:
        def walk(cluster, prefix):
            for e in fs.read_dir(cluster):
                arc = prefix + e.name
                ti = tarfile.TarInfo(arc)
                ti.mtime = time.time()
                if e.is_dir:
                    ti.type = tarfile.DIRTYPE
                    ti.mode = 0o755
                    tar.addfile(ti)
                    walk(e.cluster, arc + '/')
                else:
                    ti.size = e.size
                    ti.mode = 0o644
                    tar.addfile(ti, fs.open_read(e))
                    done[0] += e.size
                    if progress:
                        progress(min(1.0, done[0] / float(total)))
        walk(fs.root, '')


def restore_tar(fs, src, progress=None):
    with tarfile.open(src, 'r:*') as tar:
        members = [m for m in tar.getmembers() if m.isdir() or m.isfile()]
        total = max(1, sum(m.size for m in members))
        done = 0
        for m in members:
            name = m.name.replace('\\', '/').lstrip('/')
            if not name or '..' in name.split('/'):
                continue
            if m.isdir():
                fs.makedirs('/' + name)
            else:
                parent = name.rpartition('/')[0]
                if parent:
                    fs.makedirs('/' + parent)
                fs.write_file('/' + name, tar.extractfile(m), m.size)
                done += m.size
                if progress:
                    progress(min(1.0, done / float(total)))


# -------------------------------------------------------------------- protocol
def handle(fs, req, progress):
    op = req.get('op')
    if op == 'ping':
        return {}
    if op == 'info':
        total, free = fs.used_free()
        return {'total': total, 'free': free, 'cluster': fs.cs}
    if op == 'exists':
        try:
            ent = fs.stat(_fs_path(req['path']))
        except FatError:
            return {'exists': False}
        return {'exists': True, 'dir': True if ent is None else ent.is_dir}
    if op == 'list':
        res = []
        for e in fs.listdir(_fs_path(req['path'])):
            res.append({'name': e.name, 'dir': e.is_dir, 'size': e.size,
                        'hidden': bool(e.attr & ATTR_HID) or e.name.startswith('.')})
        return {'entries': res}
    if op == 'mkdir':
        fs.mkdir(_fs_path(req['path']))
        return {}
    if op == 'remove':
        fs.remove(_fs_path(req['path']), bool(req.get('recursive')))
        return {}
    if op == 'rename':
        fs.rename(_fs_path(req['path']), req['name'])
        return {}
    if op == 'put':
        put_tree(fs, req['src'], _fs_path(req['dst']), progress)
        return {}
    if op == 'get':
        ent = fs.stat(_fs_path(req['src']))
        if ent is None:
            raise FatError('Cannot download the root folder.')
        get_tree(fs, ent, req['dst'], progress)
        return {}
    if op == 'backup':
        backup_tar(fs, req['dst'], progress)
        return {}
    if op == 'restore':
        restore_tar(fs, req['src'], progress)
        return {}
    raise FatError('Unknown operation: %s' % op)


def serve(image):
    out = sys.stdout

    def emit(obj):
        out.write(json.dumps(obj) + '\n')
        out.flush()

    try:
        fs = Fat32(image)
    except (FatError, IOError, OSError) as ex:
        emit({'id': 0, 'ok': False, 'error': str(ex), 'fatal': True})
        return 1
    emit({'id': 0, 'ok': True, 'ready': True})
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        rid = None
        try:
            req = json.loads(line)
            rid = req.get('id')
            fs.begin()
            res = handle(fs, req, lambda p: emit({'id': rid, 'progress': p}))
            fs.flush()
            r = {'id': rid, 'ok': True}
            r.update(res)
            emit(r)
        except FatError as ex:
            try:
                fs.flush()
            except Exception:
                pass
            emit({'id': rid, 'ok': False, 'error': str(ex)})
        except (IOError, OSError) as ex:
            emit({'id': rid, 'ok': False, 'error': 'Disk error: %s' % ex})
        except Exception as ex:
            emit({'id': rid, 'ok': False, 'error': 'Internal error: %r' % (ex,)})
    fs.close()
    return 0


if __name__ == '__main__':
    if len(sys.argv) < 2:
        sys.stderr.write('usage: flipfs.py <sdcard.img>\n')
        sys.exit(2)
    sys.exit(serve(sys.argv[1]))
