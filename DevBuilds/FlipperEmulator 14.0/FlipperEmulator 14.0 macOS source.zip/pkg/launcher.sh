#!/bin/bash
# Flipper Emulator for macOS - starts the bundled Python (installed by the .pkg) with the app.
C="$(cd "$(dirname "$0")/.." && pwd)"
PY="$C/MacOS/FlipperEmulator-python"
if [ ! -x "$PY" ] || [ ! -d "$C/lib/python3.12/site-packages/PySide6" ]; then
  /usr/bin/osascript -e 'display alert "Flipper Emulator is not completely installed" message "Please open the installer (FlipperEmulator-@VERSION@.pkg) again. It needs an internet connection." as critical' >/dev/null 2>&1
  exit 1
fi
export PYTHONHOME="$C"
export PYTHONNOUSERSITE=1
export PYTHONDONTWRITEBYTECODE=1
unset PYTHONPATH PYTHONSTARTUP
[ -f /etc/ssl/cert.pem ] && export SSL_CERT_FILE=/etc/ssl/cert.pem
export FLIP_RES="$C/Resources"
exec "$PY" -s "$C/Resources/app/main.py" "$@"
