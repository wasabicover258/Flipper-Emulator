"""Minimal xar reader/writer for flat macOS installer packages (no signing)."""
import bz2, hashlib, struct, sys, time, zlib
import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape


def read(path):
    """-> (toc_root, {path: bytes}) and verifies all checksums."""
    raw = open(path, "rb").read()
    magic, hsize, ver, tc, tu, alg = struct.unpack(">4sHHQQI", raw[:28])
    assert magic == b"xar!" and alg == 1, (magic, alg)
    ctoc = raw[hsize:hsize + tc]
    toc = zlib.decompress(ctoc)
    assert len(toc) == tu
    heap = hsize + tc
    root = ET.fromstring(toc)
    t = root.find("toc")
    ck = t.find("checksum")
    off, size = int(ck.find("offset").text), int(ck.find("size").text)
    assert raw[heap + off:heap + off + size] == hashlib.sha1(ctoc).digest(), "TOC checksum mismatch"
    files = {}

    def walk(el, prefix):
        for f in el.findall("file"):
            name = f.find("name").text
            p = prefix + name
            if f.find("type").text == "directory":
                files[p + "/"] = None
                walk(f, p + "/")
                continue
            d = f.find("data")
            if d is None:
                files[p] = b""
                continue
            o, ln = int(d.find("offset").text), int(d.find("length").text)
            blob = raw[heap + o:heap + o + ln]
            assert hashlib.sha1(blob).hexdigest() == d.find("archived-checksum").text, p
            enc = d.find("encoding").get("style")
            data = {"application/octet-stream": lambda b: b, "application/x-gzip": zlib.decompress,
                    "application/x-bzip2": bz2.decompress}[enc](blob)
            assert hashlib.sha1(data).hexdigest() == d.find("extracted-checksum").text, p
            assert len(data) == int(d.find("size").text), p
            files[p] = data
    walk(t, "")
    return root, files


def write(path, entries, mtime=None):
    """entries: list of (path, bytes or None for directory, mode). Directories before their files."""
    mtime = mtime or time.time()
    ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(mtime))
    heap = [b"\0" * 20]          # TOC checksum placeholder at offset 0
    pos = 20
    tree = {}
    order = []
    ids = iter(range(1, 100000))

    class Node(object):
        def __init__(s, name, data, mode):
            s.name, s.data, s.mode, s.kids, s.id = name, data, mode, [], next(ids)
    roots = []
    for p, data, mode in entries:
        parts = p.strip("/").split("/")
        n = Node(parts[-1], data, mode)
        parent = "/".join(parts[:-1])
        (tree[parent].kids if parent else roots).append(n)
        if data is None:
            tree["/".join(parts)] = n

    def emit(n, ind):
        nonlocal pos
        sp = " " * ind
        out = ['%s<file id="%d">' % (sp, n.id)]
        if n.data is not None:
            enc = "application/octet-stream"
            arch = n.data
            heap.append(arch)
            out += ['%s <data>' % sp,
                    '%s  <length>%d</length>' % (sp, len(arch)),
                    '%s  <offset>%d</offset>' % (sp, pos),
                    '%s  <size>%d</size>' % (sp, len(n.data)),
                    '%s  <encoding style="%s"/>' % (sp, enc),
                    '%s  <extracted-checksum style="sha1">%s</extracted-checksum>' % (sp, hashlib.sha1(n.data).hexdigest()),
                    '%s  <archived-checksum style="sha1">%s</archived-checksum>' % (sp, hashlib.sha1(arch).hexdigest()),
                    '%s </data>' % sp]
            pos += len(arch)
        out += ['%s <ctime>%s</ctime>' % (sp, ts), '%s <mtime>%s</mtime>' % (sp, ts),
                '%s <group>wheel</group>' % sp, '%s <gid>0</gid>' % sp,
                '%s <user>root</user>' % sp, '%s <uid>0</uid>' % sp,
                '%s <mode>%04o</mode>' % (sp, n.mode),
                '%s <type>%s</type>' % (sp, "directory" if n.data is None else "file"),
                '%s <name>%s</name>' % (sp, escape(n.name))]
        for k in n.kids:
            out += emit(k, ind + 1)
        out.append('%s</file>' % sp)
        return out
    body = []
    for r in roots:
        body += emit(r, 2)
    toc = "\n".join(['<?xml version="1.0" encoding="UTF-8"?>', '<xar>', ' <toc>',
                     '  <creation-time>%s</creation-time>' % ts[:-1],
                     '  <checksum style="sha1">', '   <offset>0</offset>', '   <size>20</size>', '  </checksum>']
                    + body + [' </toc>', '</xar>', '']).encode("utf-8")
    ctoc = zlib.compress(toc, 9)
    heap[0] = hashlib.sha1(ctoc).digest()
    with open(path, "wb") as f:
        f.write(struct.pack(">4sHHQQI", b"xar!", 28, 1, len(ctoc), len(toc), 1))
        f.write(ctoc)
        for b in heap:
            f.write(b)


if __name__ == "__main__":
    root, files = read(sys.argv[1])
    for p, d in files.items():
        print("%-60s %s" % (p, "dir" if d is None else len(d)))
    if len(sys.argv) > 2:
        sys.stdout.write(files[sys.argv[2]].decode("utf-8", "replace"))
