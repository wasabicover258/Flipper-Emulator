"""Drives the Mac app on Linux against the fake VM: python drive.py action [action ...]"""
import os, sys, time, json
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "devres", "app"))
from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QImage
app = QApplication(sys.argv[:1])
import theme, controller, dialogs
from mainwindow import MainWindow
opened = []
controller.open_path = lambda t: opened.append(t)
dialogs.ConfirmDialog.confirm = staticmethod(lambda *a, **k: True)
controller.message = lambda parent, text, title="", kind="": print("MESSAGE[%s]: %s" % (kind, text.splitlines()[0]))
res = os.environ["FLIP_RES"]
theme.load_fonts(os.path.join(res, "fonts"))
form = MainWindow("14.0", QImage(), QImage())
ctl = controller.Controller(form, res, "14.0")
form.show()
for act in sys.argv[1:]:
    t0 = time.time()
    if act.startswith("click:"):
        ctl.invoke(act[6:])
    else:
        ctl.start_action(act)
    while (ctl.busy or ctl.thread is not None) and time.time() - t0 < 1800:
        app.processEvents(); time.sleep(0.05)
    for _ in range(20):
        app.processEvents(); time.sleep(0.05)
    print("=== %s done in %.0fs, exit=%s, activity=%r" % (act, time.time() - t0, ctl.exit_code, form.lblActState.text()))
    log = form.log.toPlainText().splitlines()
    print("\n".join("   | " + l for l in log[-14:]))
# final status
ctl.last_status = 0; ctl.refresh_status(True)
t0 = time.time()
while time.time() - t0 < 30 and (ctl.status_running or not ctl.state):
    app.processEvents(); time.sleep(0.1)
for _ in range(10):
    app.processEvents(); time.sleep(0.05)
print("STATE:", json.dumps(ctl.state))
print("STATUS:", form.lblStatusTitle.text(), "|", form.lblStatusDetail.text())
print("OPENED:", opened)
form.grab().save("/tmp/drive_last.png")
