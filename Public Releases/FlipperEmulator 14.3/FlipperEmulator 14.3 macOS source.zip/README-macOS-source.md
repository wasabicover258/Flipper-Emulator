# Flipper Emulator 14.3 - macOS source and build tools

- `app/` - the macOS app window (Python + PySide6), a port of the Windows window code:
  `main.py`, `mainwindow.py`, `widgets.py`, `dialogs.py`, `theme.py`, `controller.py` (actions, log, status),
  `vm.py` (Multipass VM "flipperone", SSH, port tunnel, one-time Multipass install).
- `flipemu.py` - the Flipper Zero window (13.8 version + remote SD access over SSH for the Mac).
- `pkg/` - `postinstall.in`, `launcher.sh`, `Info.plist`, `Welcome.html`, `Conclusion.html`.
- `pkgtools/xartool.py` - writes/reads xar (flat .pkg) archives without Mac tools.
- `build_pkg.py` - builds the .pkg on Linux:
  `python3 build_pkg.py 14.3 "FlipperEmulator 14.3.sh" out/` (needs `devres/` with img, fonts, zero-ui).
- `test/` - fake `multipass` and a headless driver to run the Mac app on Linux against a fake VM.

Built and tested on Linux only (fake VM, simulated installer run). Not yet tested on a real Mac.
