"""Flipper Emulator for macOS - what happens when something is clicked (port of
FlipGui in Gui.cs). Every action runs in a worker thread that writes the activity
log file; a timer shows new lines, like the Windows and Linux versions."""
import datetime
import hashlib
import json
import os
import platform
import re
import shutil
import signal
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request

from PySide6.QtCore import QObject, QTimer, Signal
from PySide6.QtWidgets import QFileDialog

import vm as vmmod
from vm import Vm, VmError, SHARE, ROOT, FILES_MIRROR
from dialogs import ConfirmDialog, VersionDialog, message, yes_no

IS_MAC = sys.platform == "darwin"
REPO = "wasabicover258/Flipper-Emulator"
COLORWAYS = ["stock", "snow", "desert", "eva", "moss"]
HOST = "Mac" if IS_MAC else "PC"

ADVICE = {
    "external": ("Temporary problem outside of Flipper Emulator", "The server this download comes from (for example GitHub) did not answer properly. That is a problem on the server's side. It is not a bug in Flipper Emulator, and nothing is wrong with your Mac or your internet connection. This usually passes within minutes or a few hours. Please try again later; everything that was already downloaded is kept. For GitHub you can look at www.githubstatus.com.", "Warn"),
    "offline": ("The server could not be reached", "Flipper Emulator could not reach the server at all. Either this Mac is offline, or a firewall, VPN or proxy blocks the connection, or the server is currently down. It is not a bug in Flipper Emulator. Check whether websites open in your browser: if they do not, fix the connection first; if they do, the server is probably down and it will pass. Then try again.", "Warn"),
    "security": ("The secure connection was interrupted", "A secure (HTTPS) connection could not be set up. The usual causes are on this Mac or in its network: security software or a proxy that inspects traffic, or a wrong date or time. It is not a bug in Flipper Emulator. Please check the date and time and try again, or try another network.", "Warn"),
    "notfound": ("Not temporary: the file is not available at this address", "The server says that the file does not exist (any more) at the address this version of Flipper Emulator uses. Waiting will not fix this. Please check for a newer version (Check for updates) and report it under Community & Feedback > Bug report so that it can be fixed.", "Danger"),
    "damaged": ("The download arrived damaged", "The file was downloaded, but it is incomplete or damaged. This is usually caused by a connection that broke off in the middle, so it is normally temporary. The damaged file was thrown away. Please try again. If it fails again with the same message several times, please report it under Community & Feedback > Bug report.", "Warn"),
    "local": ("Caused by this Mac: not a server problem and not a program bug", "The message above says what is missing or blocked (for example free disk space, a port used by another program or the virtualization). Please fix that on this Mac and try again.", "Warn"),
    "install": ("Not temporary: the installation on this Mac is incomplete", "Something that should have been installed earlier is missing. This will not fix itself. Please use Reinstall, or Uninstall Everything and start again (or run the installer .pkg again). If it keeps happening, please report it under Community & Feedback > Bug report.", "Danger"),
}
ADVICE["cancelled"] = ("Cancelled on this Mac", "macOS asked for your password and the dialog was closed, so nothing was installed. Nothing is broken. When you are ready, simply press the button again and enter your Mac password in the macOS dialog.", "Warn")
IMAGE_BUSY = "The Flipper OS image is still open in another program"
IMAGE_ACTIONS = ("preview", "real", "files", "reinstall", "reset", "colorway")
UNCLEAR = ("Unclear cause", "Flipper Emulator cannot tell whether a server or this Mac is to blame. Please try again once after a few minutes. If it fails again in the same way, it is probably a bug in Flipper Emulator: please report it under Community & Feedback > Bug report and add the lines from the activity log.", "Warn")

TITLES = {
    "setup": "One-time setup (Multipass)",
    "preview": "Starting the FlipCTL preview", "real": "Starting the real Flipper OS", "files": "Starting Flipper OS and File Manager",
    "stop": "Stopping everything", "log": "Loading the server log", "reinstall": "Reinstalling Flipper One",
    "reset": "Resetting the Flipper OS", "wipe": "Removing everything from this " + HOST, "zero-install": "Installing the Flipper Zero emulator",
    "zero-reinstall": "Reinstalling the Flipper Zero emulator", "zero-run": "Starting the Flipper Zero emulator",
    "zero-stop": "Stopping the Flipper Zero emulator", "zero-show": "Opening the Flipper Zero display",
    "zero-reset": "Resetting the Flipper Zero flash", "colorway": "Applying the colorway", "update-check": "Checking for updates",
    "update-install": "Installing the update",
}


def open_path(target):
    if IS_MAC:
        subprocess.Popen(["open", target])
    else:
        opener = shutil.which("xdg-open")
        if opener:
            subprocess.Popen([opener, target], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


class Controller(QObject):
    status_ready = Signal(object)

    def __init__(self, form, res_dir, version):
        super().__init__()
        self.form = form
        self.res = res_dir
        self.version = version
        self.work = os.path.join(ROOT, "ui-work")
        os.makedirs(self.work, exist_ok=True)
        self.busy = False
        self.action = ""
        self.log_path = None
        self.log_chars = 0
        self.log_text = ""
        self.thread = None
        self.exit_code = None
        self.pending = ""
        self.mode = "one"
        self.last_status = 0.0
        self.status_running = False
        self.state = {}
        self.zero_branch = "official"
        self.zero_official = "1.5.1"
        self.zero_official_latest = "1.5.1"
        self.zero_momentum = ""
        self.zero_custom = ""
        self.cancelled = False
        self.vm = Vm(os.path.join(res_dir, "linux", "FlipperEmulator.sh"), version, self._log_line)
        self.zero_pid_file = os.path.join(ROOT, "zero-viewer.pid")
        self.settings_file = os.path.join(ROOT, "mac-settings.json")
        self._load_settings()
        form.action_requested.connect(self.invoke)
        form.firmware_changed.connect(self._firmware_changed)
        form.mode_changed.connect(self._mode_changed)
        form.closing.connect(self._closing)
        self.status_ready.connect(self._apply_status)
        form.set_official_label("Official " + self.zero_official)
        form.set_momentum_label("Momentum " + self.zero_momentum if self.zero_momentum else "Momentum (latest)")
        form.firmware_index = {"momentum": 1, "custom": 2}.get(self.zero_branch, 0)
        if self.zero_custom:
            form.set_custom_firmware(os.path.basename(self.zero_custom))
        try:
            form.colorway_index = COLORWAYS.index(self.settings.get("colorway", "stock"))
        except ValueError:
            pass
        self.timer = QTimer(self)
        self.timer.setInterval(650)
        self.timer.timeout.connect(self.tick)
        self.timer.start()

    # ------------------------------------------------------------ settings
    def _load_settings(self):
        try:
            self.settings = json.load(open(self.settings_file))
        except Exception:
            self.settings = {}
        self.zero_branch = self.settings.get("zero_branch", "official")
        self.zero_official = self.settings.get("zero_official", "1.5.1")
        self.zero_momentum = self.settings.get("zero_momentum", "")
        self.zero_custom = self.settings.get("zero_custom", "")

    def _save_settings(self):
        self.settings.update(zero_branch=self.zero_branch, zero_official=self.zero_official,
                             zero_momentum=self.zero_momentum, zero_custom=self.zero_custom)
        try:
            with open(self.settings_file, "w") as f:
                json.dump(self.settings, f, indent=1)
        except Exception:
            pass

    # ------------------------------------------------------------ log
    def add_message(self, msg):
        self.form.append_log("[%s] %s\n" % (datetime.datetime.now().strftime("%H:%M:%S"), msg))

    def _log_line(self, text):
        """called from the worker thread: lines go to the log file of the running action"""
        if self.log_path:
            with open(self.log_path, "a", encoding="utf-8") as f:
                f.write(text.rstrip("\n") + "\n")

    def set_activity(self, text, tone):
        self.form.set_activity(text, tone)

    def set_status(self, title, detail, tone):
        self.form.set_status(title, detail, tone)

    def update_log(self):
        if not self.log_path or not os.path.exists(self.log_path):
            return
        try:
            with open(self.log_path, "r", encoding="utf-8", errors="replace") as f:
                text = f.read()
        except Exception:
            return
        if len(text) <= self.log_chars:
            return
        chunk = text[self.log_chars:]
        self.log_chars = len(text)
        chunk = chunk.replace("\r\n", "\n").replace("\r", "\n").replace("\0", "")
        chunk = re.sub("\x1b\\[[0-9;?]*[ -/]*[@-~]", "", chunk)
        if not chunk:
            return
        self.log_text += chunk
        shown = []
        for line in chunk.splitlines(True):
            m = re.match(r"^UI-EVENT:([A-Z_]+):(.*)$", line.rstrip("\n"))
            if m:
                self._event(m.group(1), m.group(2))
                continue
            shown.append(line)
        if shown:
            self.form.append_log("".join(shown))

    def _event(self, name, value):
        if name == "OPEN_URL":
            v = value.strip()
            if re.match(r"^https?://", v):
                if re.match(r"^http://(127\.0\.0\.1|localhost)(:\d+)?/", v):
                    threading.Thread(target=self._tunnel_then_open, args=(v,), daemon=True).start()
                else:
                    open_path(v)
            else:
                hp = vmmod.host_path(v)
                if hp:
                    os.makedirs(hp, exist_ok=True)
                    open_path(hp)
        elif name == "ZERO_WINDOW":
            try:
                info = json.loads(value)
                with open(os.path.join(ROOT, "zero-window.json"), "w") as f:
                    json.dump(info, f)
                threading.Thread(target=self._start_zero_window, args=(info,), daemon=True).start()
            except Exception as e:
                self.add_message("The Flipper Zero window could not be opened: %s" % e)

    def _tunnel_then_open(self, url):
        try:
            self.vm.ensure_tunnel()
            time.sleep(0.5)
        except Exception:
            pass
        open_path(url)

    # ------------------------------------------------------------ Flipper Zero window (native on the Mac)
    def zero_window_pid(self):
        try:
            pid = int(open(self.zero_pid_file).read().strip())
            os.kill(pid, 0)
            return pid
        except Exception:
            return 0

    def _start_zero_window(self, info):
        try:
            self.vm.ensure_tunnel()
        except Exception:
            pass
        old = self.zero_window_pid()
        if old:
            try:
                os.kill(old, signal.SIGTERM)
            except Exception:
                pass
            time.sleep(0.6)
        zdir = os.path.join(self.res, "zero-ui")
        data = os.path.join(ROOT, "zero-ui-data")
        os.makedirs(data, exist_ok=True)
        fb = vmmod.host_path(info.get("fb", "")) or os.path.join(SHARE, "zero-run", "flipper_fb.raw")
        token = ""
        try:
            token = open(os.path.join(SHARE, "zero-run", "zero-monitor.token")).read().strip()
        except Exception:
            pass
        env = dict(os.environ)
        env["FLIPPER_MONITOR_TOKEN"] = token
        args = [sys.executable, os.path.join(zdir, "flipemu.py"), "--fb", fb, "--sd-img", info.get("sd", ""),
                "--helper", info.get("helper", ""), "--remote-cmd", json.dumps(self.vm.ssh_base() + ["--"]),
                "--share-map", SHARE + "=" + vmmod.VM_SHARE, "--rcc", os.path.join(zdir, "ui.rcc"),
                "--port", str(info.get("port", 1234)), "--fw-version", info.get("version", ""),
                "--fw-date", info.get("date", ""), "--fw-branch", info.get("branch", ""), "--data-dir", data]
        p = subprocess.Popen(args, cwd=zdir, env=env, stdout=open(os.path.join(data, "stdout.log"), "a"),
                             stderr=open(os.path.join(data, "stderr.log"), "a"), start_new_session=True)
        with open(self.zero_pid_file, "w") as f:
            f.write(str(p.pid))

    def stop_zero_window(self):
        pid = self.zero_window_pid()
        if pid:
            try:
                os.kill(pid, signal.SIGTERM)
            except Exception:
                pass
        try:
            os.remove(self.zero_pid_file)
        except OSError:
            pass

    # ------------------------------------------------------------ status
    def refresh_status(self, force=False):
        if self.busy or self.status_running:
            return
        if not vmmod.multipass() or not self.vm.exists_quick():
            self._apply_status({"vm": False})
            return
        self.status_running = True

        def work():
            st = {"vm": False}
            try:
                if self.vm.state() == "Running":
                    st = self.vm.status()
                    st["vm"] = True
            except Exception as e:
                st = {"vm": False, "error": str(e)}
            self.status_running = False
            self.status_ready.emit(st)
        threading.Thread(target=work, daemon=True).start()

    def _apply_status(self, st):
        self.state = st or {}
        if self.busy:
            return
        z_inst = bool(self.state.get("zeroInstalled"))
        z_run = bool(self.state.get("zeroRunning"))
        if self.state.get("zeroOfficialLatest"):
            self.zero_official_latest = self.state["zeroOfficialLatest"]
        self.form.set_zero_state(z_inst, z_run)
        if self.mode == "zero":
            if not z_inst:
                self.set_status("NOT INSTALLED", "The Flipper Zero emulator is not installed yet. Click Install Emulator.", "Warn")
            elif z_run:
                if self.zero_window_pid():
                    self.set_status("EMULATOR RUNNING", "The Flipper Zero is running and its display window is open.", "Success")
                else:
                    self.set_status("EMULATOR RUNNING", "The Flipper Zero is running. Click Open Display to show its screen.", "Success")
            else:
                self.set_status("READY", "The emulator is installed. Choose a firmware and press Start.", "Faint")
            return
        real, preview, shelf = self.state.get("real"), self.state.get("preview"), self.state.get("shelf")
        app_port, shelf_port = self.state.get("appPort", 8899), self.state.get("shelfPort", 8898)
        state, detail, tone = "STOPPED", "No services are running. Choose an action to begin.", "Faint"
        if real:
            state = "REAL OS RUNNING"
            if shelf:
                detail, tone = "The real Flipper OS and the File Manager are running.", "Success"
            else:
                detail, tone = "The real Flipper OS is running. The File Manager is starting or unavailable.", "Accent"
        elif preview:
            state, detail, tone = "PREVIEW RUNNING", "The FlipCTL preview is running in the background.", "Success"
        self.form.set_service_lines("Flipper OS      port %s" % app_port, "File Manager    port %s" % shelf_port)
        self.set_status(state, detail, tone)
        if real or preview:
            threading.Thread(target=self._keep_tunnel, daemon=True).start()

    def _keep_tunnel(self):
        try:
            self.vm.ensure_tunnel()
        except Exception:
            pass

    def _mode_changed(self, zero):
        self.mode = "zero" if zero else "one"
        if not self.busy:
            self._apply_status(self.state)
            self.last_status = time.time() - 4.2

    def _firmware_changed(self, i):
        self.zero_branch = {1: "momentum", 2: "custom"}.get(i, "official")
        self._save_settings()

    # ------------------------------------------------------------ clicks
    def invoke(self, key):
        try:
            self._invoke(key)
        except Exception as e:
            self.add_message("Error: %s" % e)
            self.set_activity("Needs attention", "Danger")

    def _invoke(self, key):
        if key == "exit":
            self.form.close()
        elif key == "cancel":
            self.stop_action()
        elif key == "backup":
            if not self.busy:
                os.makedirs(FILES_MIRROR, exist_ok=True)
                open_path(FILES_MIRROR)
                self.add_message("Opened the %s file backup: %s" % (HOST, FILES_MIRROR))
        elif key == "powermeter":
            open_path("https://dev.repetren.com/power_meter_demo/")
            self.add_message("Opened the Power Meter demo in your browser.")
        elif key.startswith("feedback-"):
            self.open_feedback(key[9:])
        elif key == "refresh":
            if self.busy:
                return
            self.refresh_status(True)
            self.last_status = time.time()
            self.add_message("Status refreshed.")
        elif key == "zero-browse":
            self.select_custom_firmware()
        elif key == "zero-version":
            if not self.busy:
                self.select_firmware_version()
        elif key == "colorway":
            if self.busy:
                return
            idx = self.form.colorway_index
            if 0 <= idx < len(COLORWAYS):
                self.settings["colorway"] = COLORWAYS[idx]
                self._save_settings()
                self.start_action("colorway")
        elif key == "zero-start":
            if self.busy:
                return
            if self.state.get("zeroRunning"):
                self.start_action("zero-stop")
                return
            if self.zero_branch == "custom" and (not self.zero_custom or not os.path.isfile(self.zero_custom)):
                if not self.select_custom_firmware():
                    return
            self.start_action("zero-run")
        else:
            self.start_action(key)

    def open_feedback(self, kind):
        tpl = {"bug": "bug.yml", "idea": "idea.yml", "result": "showcase.yml"}.get(kind, "other.yml")
        osv = ("macOS " + platform.mac_ver()[0]) if IS_MAC else platform.platform()
        q = "template=%s&version=%s&windows=%s" % (tpl, urllib.parse.quote(self.version + " (macOS)"),
                                                     urllib.parse.quote("%s (%s)" % (osv, platform.machine())))
        open_path("https://github.com/%s/issues/new?%s" % (REPO, q))
        self.add_message("Opened the feedback form on GitHub in your browser. Only the version numbers of this program and of macOS are filled in; you can change them there.")

    def select_custom_firmware(self):
        f, _ = QFileDialog.getOpenFileName(self.form, "Choose a Flipper Zero firmware", os.path.expanduser("~"),
                                           "Firmware files (*.tgz *.bin *.dfu);;All files (*)")
        if not f:
            return False
        self.zero_custom = f
        self._save_settings()
        self.form.set_custom_firmware(os.path.basename(f))
        self.add_message("Custom firmware: " + f)
        return True

    def select_firmware_version(self):
        mom = self.zero_branch == "momentum"
        current = self.zero_momentum if mom else self.zero_official
        self.add_message("Loading the list of firmware versions ...")
        items = []
        try:
            if self.vm.exists_quick() and self.vm.state() == "Running":
                code, out = self.vm.cli("zero-versions", "momentum" if mom else "official", timeout=90)
                line = [l for l in out.splitlines() if l.strip().startswith("[")]
                if line:
                    items = [str(x) for x in json.loads(line[-1])]
        except Exception:
            pass
        picked = VersionDialog.ask(self.form, items, current)
        if picked is None:
            return False
        if not picked or re.match(r"^(?i)latest", picked):
            picked = ""
        if mom:
            if picked and not re.match(r"^[A-Za-z0-9._-]+$", picked):
                message(self.form, "This is not a valid Momentum version.", "Firmware version", "Warning")
                return False
            self.zero_momentum = picked
            self.form.set_momentum_label("Momentum " + picked if picked else "Momentum (latest)")
            self.add_message("Momentum version: " + (picked or "latest"))
        else:
            if picked and not re.match(r"^\d+\.\d+\.\d+(-rc)?$", picked):
                message(self.form, "Please enter a version like 1.4.3.", "Firmware version", "Warning")
                return False
            if not picked:
                picked = self.zero_official_latest
            self.zero_official = picked
            self.form.set_official_label("Official " + picked)
            self.add_message("Official firmware version: " + picked)
        self._save_settings()
        return True

    def confirm(self, title, heading, body, phrase, label, tone, case):
        return ConfirmDialog.confirm(self.form, title, heading, body, phrase, label, tone, case)

    def cancel_confirm(self, what):
        self.set_activity("Cancelled", "Faint")
        self.add_message(what + " cancelled. Nothing was changed.")

    # ------------------------------------------------------------ actions
    def start_action(self, action):
        if self.busy:
            return
        if action == "real" and self.form.open_file_manager:
            action = "files"
        title = TITLES.get(action, "Working")
        if action == "wipe":
            body = ("This permanently removes everything Flipper Emulator has put on this Mac:"
                    "\n  - the private Linux environment (Ubuntu VM) with the Flipper Zero emulator and the Flipper OS image"
                    "\n  - all downloaded firmwares and installers"
                    "\n  - your File Manager files and the Mac file backup"
                    "\n  - the program itself and the desktop icon"
                    "\n\nAll of this disk space is free again afterwards. Your own files are not touched; Multipass stays installed "
                    "(like WSL on Windows). macOS asks for your password to remove the program. This window closes when everything is removed.")
            if not self.confirm("Uninstall Everything", "Remove everything from this Mac?", body, "DELETE", "Remove everything", "Danger", True):
                return self.cancel_confirm("Removal")
        if action == "reinstall":
            body = ("This removes the Flipper One setup and its downloads, downloads a fresh copy, and restores the Mac file backup."
                    "\n\nThis needs an internet connection and several GB of free space. It can take several minutes.")
            if self.state.get("zeroInstalled"):
                body += "\n\nThe Flipper Zero emulator lives in the same app folder, so it is removed as well and has to be installed again."
            if not self.confirm("Reinstall Flipper One", "Download a fresh setup?", body, "YES", "Reinstall", "Warn", False):
                return self.cancel_confirm("Reinstall")
        if action == "reset":
            body = ("This deletes the real Flipper OS image with all apps, settings and files inside it."
                    "\nIt also deletes the Mac file backup (" + FILES_MIRROR + ")."
                    "\n\nThe helper, its downloads and the FlipCTL preview are kept.")
            if not self.confirm("Reset Flipper OS", "Factory reset the Flipper OS?", body, "RESET", "Reset Flipper OS", "Danger", True):
                return self.cancel_confirm("Factory reset")
        if action == "zero-reinstall":
            body = ("This deletes the installed Flipper Zero emulator (including its emulated SD card and flash) and downloaded firmwares, then installs it again from scratch."
                    "\n\nThis needs an internet connection and can take 15-30 minutes.")
            if not self.confirm("Reinstall Flipper Zero emulator", "Install the emulator again?", body, "YES", "Reinstall", "Warn", False):
                return self.cancel_confirm("Reinstall")

        stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
        self.log_path = os.path.join(self.work, "run-%s-%s.log" % (stamp, action))
        open(self.log_path, "w").close()
        self.busy, self.action, self.log_chars, self.log_text = True, action, 0, ""
        self.exit_code, self.cancelled = None, False
        self.form.log.clear()
        self.form.append_log("[%s] %s\n" % (datetime.datetime.now().strftime("%H:%M:%S"), title))
        self.form.set_busy(True)
        self.set_status("WORKING", title, "Warn")
        self.set_activity(title, "Warn")
        self.thread = threading.Thread(target=self._run_action, args=(action,), daemon=True)
        self.thread.start()

    def _run_action(self, action):
        code = 1
        try:
            code = self._do(action)
        except VmError as e:
            self._log_line("XX " + str(e))
            self._log_line("UI-EVENT:FAIL_KIND:" + e.kind)
            code = 1
        except Exception as e:
            self._log_line("XX " + str(e))
            code = 1
        self.exit_code = code

    def _remote(self, action):
        p = subprocess.Popen(self.vm.action_command("ui-" + action), stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        self.proc = p
        with open(self.log_path, "ab") as f:
            for raw in iter(p.stdout.readline, b""):
                f.write(raw)
                f.flush()
        return p.wait()

    def _do(self, action):
        if action == "setup":
            self.vm.install_multipass()
            return 0
        if action == "update-check":
            return self._update_check()
        if action == "update-install":
            return self._update_install()
        if action == "wipe":
            return self._wipe()
        if action == "stop" and not self.vm.exists_quick():
            self._log_line("Nothing is running.")
            return 0
        self.vm.ensure()
        if action == "colorway":
            self.vm.cli("set-colorway", self.settings.get("colorway", "stock"))
        if action == "zero-run":
            sel = {"branch": self.zero_branch, "official": self.zero_official, "momentum": self.zero_momentum, "custom": ""}
            if self.zero_branch == "custom" and self.zero_custom:
                d = os.path.join(SHARE, "custom-firmware")
                shutil.rmtree(d, ignore_errors=True)
                os.makedirs(d, exist_ok=True)
                dst = os.path.join(d, os.path.basename(self.zero_custom))
                shutil.copyfile(self.zero_custom, dst)
                sel["custom"] = vmmod.vm_path(dst)
            with open(os.path.join(SHARE, "zero-selection.json"), "w") as f:
                json.dump(sel, f)
        if action in ("zero-stop", "stop"):
            self.stop_zero_window()
        if action == "zero-show":
            info = None
            try:
                info = json.load(open(os.path.join(ROOT, "zero-window.json")))
            except Exception:
                pass
            if info and self.state.get("zeroRunning"):
                self._log_line("UI-EVENT:ZERO_WINDOW:" + json.dumps(info))
                self._log_line("Flipper Zero window opened.")
                return 0
        self.vm.stop_leftovers()
        code = self._remote(action)
        if code != 0 and not self.cancelled and action in IMAGE_ACTIONS and self._log_has(IMAGE_BUSY):
            # Something inside the Linux environment still holds the Flipper OS image (left over
            # from an interrupted run). A restart of the private environment frees it; then once more.
            self._log_line("!!  The Flipper OS image is still held inside the Linux environment. Fixing this automatically ...")
            self.stop_zero_window()
            self.vm.restart()
            self._log_line("==> Trying again ...")
            code = self._remote(action)
        if action in ("preview", "real", "files"):
            try:
                self.vm.ensure_tunnel()
            except Exception:
                pass
        return code

    def _log_has(self, text):
        try:
            with open(self.log_path, encoding="utf-8", errors="replace") as f:
                return text in f.read()
        except OSError:
            return False

    def stop_action(self):
        if not self.busy:
            return
        action = self.action
        self.add_message("Cancelling the running action ...")
        self.cancelled = True
        try:
            if getattr(self, "proc", None) is not None:
                self.proc.terminate()
        except Exception:
            pass

        def bg():
            try:
                self.vm.cancel_action()
                if action == "zero-run":
                    self.vm.cli("ui-zero-stop", timeout=120)
            except Exception:
                pass
        threading.Thread(target=bg, daemon=True).start()
        self.busy, self.action, self.log_path, self.log_chars = False, "", None, 0
        self.form.set_busy(False)
        self.set_activity("Cancelled", "Warn")
        self.add_message("Action cancelled.")
        self.refresh_status(True)

    def failure_kind(self):
        t = self.log_text or ""
        m = re.findall(r"UI-EVENT:FAIL_KIND:([a-z]+)", t)
        if m:
            return m[-1]
        t = t[-6000:]
        if re.search(r"(?i)No space left on device|not enough (free )?(disk )?space", t):
            return "local"
        if re.search(r"(?i)Temporary failure resolving|Could not resolve host|Name or service not known|Network is unreachable", t):
            return "offline"
        if re.search(r"(?i)\b50[234]\b|Bad Gateway|Service Unavailable|Gateway Time-?out|Connection timed out|Failed to fetch|Hash Sum mismatch", t):
            return "external"
        return "unknown"

    def complete_action(self):
        self.update_log()
        code = self.exit_code
        action = self.action
        self.busy, self.log_path, self.log_chars = False, None, 0
        self.thread = None
        self.form.set_busy(False)
        has_warning = re.search(r"(?m)^\s*(!!|XX)\s", self.log_text or "") is not None
        if code != 0:
            kind = self.failure_kind()
            verdict, text, tone = ADVICE.get(kind, UNCLEAR)
            self.set_activity({"external": "Server problem", "offline": "Connection problem", "security": "Connection problem"}.get(kind, "Needs attention"), tone)
            message(self.form, "The action did not finish.\n\n%s\n\n%s\n\n(Technical detail: exit code %s. The activity log shows the exact messages.)" % (verdict, text, code),
                    "Flipper Emulator", "Error" if kind in ("unknown", "notfound", "install") else "Warning")
        elif action == "wipe":
            self.set_activity("Everything removed", "Muted")
            message(self.form, "Everything Flipper Emulator installed has been removed from this Mac: the private Linux environment, all data, the program and the desktop icon.\n\nThis window closes now.", "Removal finished")
            self.form.close()
            return
        elif action == "reset":
            self.set_activity("Reset finished", "Danger")
            message(self.form, "The Flipper OS has been reset to factory state.\n\nThe next start creates a fresh Flipper. Apps, settings and files inside it are gone.", "Factory reset finished")
        elif action in ("zero-install", "zero-reinstall"):
            self.set_activity("Emulator installed", "Success")
            message(self.form, "The Flipper Zero emulator is installed.\n\nChoose a firmware and press Start.", "Flipper Zero")
        elif action == "zero-run":
            self.set_activity("Emulator running", "Success")
        elif action == "zero-stop":
            self.set_activity("Emulator stopped", "Muted")
        elif action == "zero-reset":
            self.set_activity("Flash reset", "Muted")
        elif action == "setup":
            self.set_activity("Ready", "Success")
            message(self.form, "The one-time setup is finished: Multipass is installed.\n\n"
                    "Press Start (Flipper One) or Install (Flipper Zero). The first start creates the private Linux "
                    "environment and downloads about 1-2 GB, which takes a while once.", "Flipper Emulator")
        elif action == "update-check":
            self.show_update_result()
        elif action == "update-install":
            self.set_activity("Installer opened", "Success")
        elif action == "colorway":
            self.set_activity("Finished with warnings" if has_warning else "Colorway applied", "Warn" if has_warning else "Success")
        elif has_warning:
            self.set_activity("Finished with warnings", "Warn")
        else:
            self.set_activity("Finished", "Success")
        self.action = ""
        self.last_status = 0
        self.refresh_status(True)
        if self.pending:
            nxt, self.pending = self.pending, ""
            self.start_action(nxt)

    def tick(self):
        if self.busy:
            self.update_log()
            if self.thread is not None and not self.thread.is_alive() and self.exit_code is not None:
                self.complete_action()
            return
        from theme import theme
        if theme().animating:
            return
        if time.time() - self.last_status >= 5:
            self.refresh_status()
            self.last_status = time.time()

    def _closing(self):
        self.timer.stop()

    # ------------------------------------------------------------ update (macOS: .pkg from GitHub)
    def _gh(self, url):
        req = urllib.request.Request(url, headers={"User-Agent": "FlipperEmulator", "Accept": "application/vnd.github+json"})
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read().decode("utf-8"))

    @staticmethod
    def _ver(t):
        m = re.search(r"(\d+(?:\.\d+){0,3})", t or "")
        if not m:
            return None
        p = [int(x) for x in m.group(1).split(".")]
        while len(p) < 2:
            p.append(0)
        return tuple(p)

    def _update_check(self):
        self._log_line("Checking GitHub for a newer version ...")
        info = {"current": self.version}
        try:
            r = self._gh("https://api.github.com/repos/%s/releases/latest" % REPO)
        except urllib.error.HTTPError as e:
            info.update(status="norelease" if e.code == 404 else "error", message=str(e), kind="external")
            self.update_info = info
            return 0
        except Exception as e:
            info.update(status="error", message=str(e), kind="offline")
            self.update_info = info
            return 0
        latest = r.get("tag_name", "")
        info.update(latest=latest, page=r.get("html_url", ""), notes=(r.get("body") or "")[:1200])
        cur, new = self._ver(self.version), self._ver(latest)
        if not new or not cur or new <= cur:
            info["status"] = "uptodate"
        else:
            info["status"] = "available"
            for a in r.get("assets", []):
                if a.get("name", "").lower().endswith(".pkg"):
                    url = a.get("browser_download_url", "")
                    if url.startswith("https://github.com/%s/releases/download/" % REPO):
                        info.update(url=url, digest=a.get("digest") or "", name=a["name"], size=a.get("size", 0))
        self._log_line("Current version: %s, latest release: %s" % (self.version, latest))
        self.update_info = info
        return 0

    def show_update_result(self):
        info = getattr(self, "update_info", None) or {}
        st = info.get("status")
        if st == "norelease":
            self.set_activity("No release yet", "Muted")
            message(self.form, "Nothing is wrong with your Mac or your installation.\n\nThe project page on GitHub has no published release yet. Please try again later.", "Check for updates")
        elif st == "uptodate":
            self.set_activity("Up to date", "Success")
            message(self.form, "Flipper Emulator %s is up to date." % self.version, "Check for updates")
        elif st == "available":
            self.set_activity("Update available", "Warn")
            text = "Version %s is available. You have version %s." % (info.get("latest"), self.version)
            if info.get("notes"):
                text += "\n\nWhat is new:\n" + info["notes"]
            if info.get("url"):
                if yes_no(self.form, text + "\n\nDownload and open the installer now? Your data and settings are kept.", "Update available", False):
                    self.pending = "update-install"
            elif yes_no(self.form, text + "\n\nThis release has no macOS file yet. Open the download page?", "Update available", False):
                if info.get("page", "").startswith("https://github.com/"):
                    open_path(info["page"])
        else:
            self.set_activity("Update check failed", "Warn")
            message(self.form, "The update check did not work.\n\n" + str(info.get("message", "")), "Check for updates", "Warning")

    def _update_install(self):
        info = getattr(self, "update_info", None) or {}
        m = re.match(r"^sha256:([0-9a-f]{64})$", info.get("digest", ""))
        if not info.get("url") or not m:
            self._log_line("XX GitHub published no checksum (SHA-256) for this file, so it is not installed. Please download the new version from the release page.")
            return 1
        dst = os.path.join(os.path.expanduser("~/Downloads") if IS_MAC else ROOT, info["name"])
        self._log_line("Downloading %s ..." % info["name"])
        h = hashlib.sha256()
        req = urllib.request.Request(info["url"], headers={"User-Agent": "FlipperEmulator"})
        with urllib.request.urlopen(req, timeout=60) as r, open(dst + ".part", "wb") as f:
            while True:
                b = r.read(1 << 20)
                if not b:
                    break
                h.update(b)
                f.write(b)
        if h.hexdigest() != m.group(1):
            os.remove(dst + ".part")
            self._log_line("XX The download does not match the checksum GitHub publishes. It was deleted.")
            self._log_line("UI-EVENT:FAIL_KIND:damaged")
            return 1
        os.replace(dst + ".part", dst)
        self._log_line("Checksum (SHA-256) is correct. Opening the installer ...")
        open_path(dst)
        return 0

    # ------------------------------------------------------------ uninstall everything
    def _wipe(self):
        self.stop_zero_window()
        try:
            self.vm.delete()
        except Exception as e:
            self._log_line("!! " + str(e))
        self._log_line("Removing the app data (%s) ..." % ROOT)
        for d in (ROOT,):
            shutil.rmtree(d, ignore_errors=True)
        if IS_MAC:
            app = "/Applications/Flipper Emulator.app"
            desk = os.path.expanduser("~/Desktop/Flipper Emulator")
            script = 'do shell script "rm -rf %s %s; pkgutil --forget io.github.wasabicover258.flipper-emulator >/dev/null 2>&1; true" with administrator privileges' % (
                app.replace(" ", "\\\\ "), desk.replace(" ", "\\\\ "))
            r = subprocess.run(["osascript", "-e", script], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            if r.returncode != 0:
                self._log_line("!! The program itself was not removed (no password given). You can drag it from Applications to the Trash.")
        self._log_line("Everything was removed.")
        return 0
