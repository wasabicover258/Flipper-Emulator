"""Flipper Emulator for macOS - the private Ubuntu VM (Multipass).

On Windows the Linux parts run in the private WSL environment "FlipperOne".
On the Mac the same job is done by a Multipass instance of the same name. The
tested Linux version of Flipper Emulator runs inside it (FLIP_HEADLESS=1) and
does the work; this file starts it, installs it, mounts the shared folder and
forwards the local ports (ssh -L) so the web pages open at 127.0.0.1 on the Mac.
"""
import hashlib
import json
import os
import shlex
import shutil
import signal
import subprocess
import sys
import time
import urllib.request

IS_MAC = sys.platform == "darwin"
NAME = os.environ.get("FLIP_VM_NAME", "flipperone")
VM_SHARE = os.environ.get("FLIP_VM_SHARE", "/mnt/flipper-share")
VM_USER = "ubuntu"
VM_LAUNCHER = "/home/%s/.local/share/flipper-emulator/flipper-emulator" % VM_USER
PORTS = [8898, 8899, 1234] + list(range(8910, 8960))
# (test hooks for running the Mac app on Linux against a fake VM)
SSH_PORT = os.environ.get("FLIP_VM_SSH_PORT", "")
TUNNEL_BIND = os.environ.get("FLIP_TUNNEL_BIND", "127.0.0.1")

# Multipass (Canonical, free, GPL-3.0) - pinned release, checked by SHA-256 AND by Apple's
# Developer ID signature of Canonical before it is installed.
MULTIPASS_VERSION = "1.17.0"
MULTIPASS_URL = ("https://github.com/canonical/multipass/releases/download/v1.17.0/"
                 "multipass-1.17.0%2Bmac-Darwin.pkg")
MULTIPASS_SHA256 = "e293db5631c952dc48a756c7cde35323832961ddeea9a54b9447957c4c17ccc5"
MULTIPASS_SIGNER = "Developer ID Installer: Canonical Group Limited (X4QN7LTP59)"


def mac_root():
    r = os.environ.get("FLIP_MAC_ROOT")
    if r:
        return r
    if IS_MAC:
        return os.path.expanduser("~/Library/Application Support/FlipperOneDemo")
    return os.path.expanduser("~/.local/share/FlipperOneDemo-mac")


ROOT = mac_root()
SHARE = os.path.join(ROOT, "share")
VMDIR = os.path.join(ROOT, "vm")
KEY = os.path.join(VMDIR, "id_ed25519")
KNOWN = os.path.join(VMDIR, "known_hosts")
TUNNEL_PID = os.path.join(VMDIR, "tunnel.pid")
FILES_MIRROR = os.path.join(SHARE, "FlipperOneDemoFiles")


def multipass():
    for p in (os.environ.get("FLIP_MULTIPASS"), "/usr/local/bin/multipass", "/opt/homebrew/bin/multipass",
              "/Library/Application Support/com.canonical.multipass/bin/multipass", shutil.which("multipass")):
        if p and os.path.isfile(p) and os.access(p, os.X_OK):
            return p
    return None


def host_path(vm_path):
    """VM path of the shared folder -> path on the Mac (for OPEN_URL events)"""
    if vm_path.startswith(VM_SHARE):
        return SHARE + vm_path[len(VM_SHARE):]
    if vm_path.rstrip("/").endswith("/.local/share/FlipperOneDemoFiles"):
        return FILES_MIRROR
    return None


def vm_path(host):
    real = os.path.realpath(host)
    share = os.path.realpath(SHARE)
    if real == share or real.startswith(share + "/"):
        return VM_SHARE + real[len(share):]
    return None


class VmError(Exception):
    def __init__(self, msg, kind="unknown"):
        Exception.__init__(self, msg)
        self.kind = kind


class Vm(object):
    def __init__(self, bundled_installer, version, log):
        self.installer = bundled_installer      # FlipperEmulator <version>.sh inside the app
        self.version = version
        self.log = log                          # log(text) -> appended to the activity log
        for d in (ROOT, SHARE, VMDIR, FILES_MIRROR):
            os.makedirs(d, exist_ok=True)

    # ------------------------------------------------------------ multipass
    def mp(self, *args, timeout=600, check=False):
        exe = multipass()
        if not exe:
            raise VmError("Multipass is not installed yet. Close and open Flipper Emulator again to install it.", "install")
        r = subprocess.run([exe] + list(args), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout)
        out = r.stdout.decode("utf-8", "replace")
        if check and r.returncode != 0:
            raise VmError("multipass %s failed: %s" % (args[0], out.strip()[-600:]), self._kind(out))
        return r.returncode, out

    @staticmethod
    def _kind(out):
        o = out.lower()
        if "no space" in o or "not enough disk" in o:
            return "local"
        if "could not resolve" in o or "network is unreachable" in o or "failed to download" in o or "timed out" in o:
            return "offline"
        return "unknown"

    def info(self):
        try:
            code, out = self.mp("info", NAME, "--format", "json", timeout=60)
        except VmError:
            raise
        except Exception:
            return None
        if code != 0:
            return None
        try:
            return json.loads(out[out.index("{"):]).get("info", {}).get(NAME)
        except Exception:
            return None

    def state(self):
        i = self.info()
        return (i or {}).get("state", "Missing") if i is not None else "Missing"

    def ip(self):
        i = self.info() or {}
        for a in i.get("ipv4", []) or []:
            if a:
                return a
        return None

    def exists_quick(self):
        return os.path.exists(os.path.join(VMDIR, "created.flag"))

    # ------------------------------------------------------------ Multipass (once)
    def install_multipass(self):
        """Downloads the pinned Multipass installer, checks it twice and installs it.
        macOS shows its own password dialog for this (one time)."""
        if multipass():
            return False
        if not IS_MAC:
            raise VmError("Multipass is missing (set FLIP_MULTIPASS for tests).", "install")
        pkg = os.path.join(VMDIR, "multipass-%s.pkg" % MULTIPASS_VERSION)
        self.log("One-time setup: Flipper Emulator uses Multipass (free, by Canonical) for its private Linux "
                 "environment - the Mac counterpart of WSL on Windows.")
        if not (os.path.isfile(pkg) and self._sha256(pkg) == MULTIPASS_SHA256):
            self.log("Downloading Multipass %s (about 160 MB) ..." % MULTIPASS_VERSION)
            self._download(MULTIPASS_URL, pkg)
        if self._sha256(pkg) != MULTIPASS_SHA256:
            os.remove(pkg)
            raise VmError("The Multipass download is damaged (SHA-256 does not match). It was deleted. Please try again.", "damaged")
        r = subprocess.run(["/usr/sbin/pkgutil", "--check-signature", pkg], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        sig = r.stdout.decode("utf-8", "replace")
        if r.returncode != 0 or MULTIPASS_SIGNER not in sig or "signed by a developer certificate issued by Apple" not in sig:
            raise VmError("The Multipass installer is not signed by Canonical. It is not installed.\n" + sig.strip()[-400:], "security")
        self.log("Checksum and Canonical's Apple signature are correct.")
        self.log("macOS now asks for your password once to install Multipass ...")
        script = ('do shell script "/usr/sbin/installer -pkg " & quoted form of "%s" & " -target /" '
                  'with prompt "Flipper Emulator installs Multipass (by Canonical) once. It runs the private Linux '
                  'environment, like WSL on Windows." with administrator privileges') % pkg.replace('"', '')
        r = subprocess.run(["/usr/bin/osascript", "-e", script], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        out = r.stdout.decode("utf-8", "replace")
        if r.returncode != 0:
            if "-128" in out:
                raise VmError("Multipass was not installed because no password was given. "
                              "It is offered again the next time you start something.", "cancelled")
            raise VmError("Multipass could not be installed: " + out.strip()[-400:], "install")
        for line in out.strip().splitlines()[-3:]:
            self.log("  " + line.strip())
        self.log("Waiting for Multipass to start ...")
        for _ in range(90):
            exe = multipass()
            if exe:
                v = subprocess.run([exe, "version"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
                if v.returncode == 0 and "multipassd" in v.stdout.decode("utf-8", "replace"):
                    self.log("Multipass is ready.")
                    try:
                        os.remove(pkg)
                    except OSError:
                        pass
                    return True
            time.sleep(2)
        raise VmError("Multipass was installed but does not answer yet. Please restart the Mac once and try again.", "install")

    @staticmethod
    def _sha256(path):
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for b in iter(lambda: f.read(1 << 20), b""):
                h.update(b)
        return h.hexdigest()

    def _download(self, url, dst):
        req = urllib.request.Request(url, headers={"User-Agent": "FlipperEmulator"})
        try:
            with urllib.request.urlopen(req, timeout=60) as r, open(dst + ".part", "wb") as f:
                total = int(r.headers.get("Content-Length") or 0)
                done, step = 0, 10
                while True:
                    b = r.read(1 << 20)
                    if not b:
                        break
                    f.write(b)
                    done += len(b)
                    if total and done * 100 // total >= step:
                        self.log("  %d %%" % (done * 100 // total))
                        step += 10
        except OSError as e:
            raise VmError("Download failed: %s" % e, "offline")
        os.replace(dst + ".part", dst)

    # ------------------------------------------------------------ provisioning
    def ensure(self):
        """VM running, shared folder mounted, Linux version installed. Logs every step."""
        self.install_multipass()
        if not os.path.isfile(KEY):
            self.log("Creating the key for the private Linux environment ...")
            subprocess.run(["ssh-keygen", "-q", "-t", "ed25519", "-N", "", "-C", "flipper-emulator", "-f", KEY], check=True)
        st = self.state()
        if st == "Missing":
            self._launch()
            st = self.state()
        if st in ("Stopped", "Suspended"):
            self.log("Starting the private Linux environment (Ubuntu) ...")
            self.mp("start", NAME, timeout=900, check=True)
        elif st not in ("Running",):
            self.log("The private Linux environment is %s; waiting ..." % st)
            self.mp("start", NAME, timeout=900)
        self._ensure_mount()
        self._wait_ssh()
        self._ensure_linux_app()
        return True

    def _resources(self):
        cores = os.cpu_count() or 4
        cpus = max(2, min(4, cores // 2))
        mem_gb = 8
        try:
            if IS_MAC:
                mem_gb = int(subprocess.run(["sysctl", "-n", "hw.memsize"], stdout=subprocess.PIPE).stdout.strip()) // (1 << 30)
            else:
                mem_gb = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") // (1 << 30)
        except Exception:
            pass
        mem = "6G" if mem_gb >= 16 else ("4G" if mem_gb >= 8 else "3G")
        return cpus, mem

    def _launch(self):
        cpus, mem = self._resources()
        pub = open(KEY + ".pub").read().strip()
        ci = os.path.join(VMDIR, "cloud-init.yaml")
        with open(ci, "w") as f:
            f.write("#cloud-config\n# Flipper Emulator: private Linux environment (like WSL on Windows)\n"
                    "ssh_authorized_keys:\n  - %s\n" % pub)
        self.log("Creating the private Linux environment (Ubuntu 24.04, %s CPUs, %s RAM). "
                 "This downloads about 600 MB and takes a few minutes ..." % (cpus, mem))
        code, out = self.mp("launch", "24.04", "--name", NAME, "--cpus", str(cpus), "--memory", mem, "--disk", "40G",
                            "--cloud-init", ci, "--timeout", "1800", timeout=2400)
        for l in out.strip().splitlines()[-6:]:
            if l.strip():
                self.log("  " + l.strip())
        if code != 0 and self.state() == "Missing":
            raise VmError("The private Linux environment could not be created.", self._kind(out))
        open(os.path.join(VMDIR, "created.flag"), "w").write(time.strftime("%Y-%m-%d %H:%M:%S\n"))

    def _ensure_mount(self):
        i = self.info() or {}
        mounts = i.get("mounts") or {}
        if VM_SHARE in mounts:
            return
        self.log("Connecting the shared folder (%s) ..." % SHARE)
        code, out = self.mp("mount", "--type", "native", SHARE, NAME + ":" + VM_SHARE, timeout=300)
        if code != 0 and "stop" in out.lower():
            self.mp("stop", NAME, timeout=600)
            code, out = self.mp("mount", "--type", "native", SHARE, NAME + ":" + VM_SHARE, timeout=300)
            self.mp("start", NAME, timeout=900, check=True)
        if code != 0:
            self.log("  (native mount not possible: %s) using the standard mount" % out.strip()[-200:])
            self.mp("mount", SHARE, NAME + ":" + VM_SHARE, timeout=900, check=True)

    def ssh_base(self, ip=None, tty=False):
        ip = ip or self.ip()
        if not ip:
            raise VmError("The private Linux environment has no network address yet.")
        a = ["ssh", "-i", KEY, "-o", "IdentitiesOnly=yes", "-o", "StrictHostKeyChecking=no",
             "-o", "UserKnownHostsFile=" + KNOWN, "-o", "LogLevel=ERROR", "-o", "ConnectTimeout=15",
             "-o", "ServerAliveInterval=20", "-o", "BatchMode=yes"]
        if SSH_PORT:
            a += ["-p", SSH_PORT]
        if tty:
            a.append("-tt")
        return a + [VM_USER + "@" + ip]

    def ssh(self, command, timeout=120):
        r = subprocess.run(self.ssh_base() + ["--", command], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           timeout=timeout)
        return r.returncode, r.stdout.decode("utf-8", "replace")

    def _wait_ssh(self):
        t0 = time.time()
        last = ""
        while time.time() - t0 < 300:
            try:
                code, out = self.ssh("true", timeout=30)
                if code == 0:
                    return
                last = out
            except Exception as e:
                last = str(e)
            time.sleep(3)
        raise VmError("The private Linux environment does not answer (ssh): " + last.strip()[-300:])

    def remote_env(self):
        return "FLIP_HEADLESS=1 FLIP_SHARE=%s FLIP_UI=1" % VM_SHARE

    def _ensure_linux_app(self):
        code, out = self.ssh("test -x %s && %s --version" % (VM_LAUNCHER, VM_LAUNCHER), timeout=120)
        have = out.strip().splitlines()[-1].strip() if code == 0 and out.strip() else ""
        if have == self.version:
            self._ensure_files_link()
            return
        self.log("Installing Flipper Emulator %s in the private Linux environment%s ..." %
                 (self.version, " (was " + have + ")" if have else ""))
        self.log("This installs QEMU, Mono and the other tools once and takes several minutes.")
        inst_dir = os.path.join(SHARE, "install")
        os.makedirs(inst_dir, exist_ok=True)
        dst = os.path.join(inst_dir, "FlipperEmulator.sh")
        shutil.copyfile(self.installer, dst)
        p = subprocess.Popen(self.ssh_base() + ["--", "bash %s/install/FlipperEmulator.sh --text --no-start 2>&1" % VM_SHARE],
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        for raw in iter(p.stdout.readline, b""):
            line = raw.decode("utf-8", "replace").rstrip()
            if line:
                self.log("  " + line)
        code = p.wait()
        if code != 0:
            raise VmError("Flipper Emulator could not be installed in the private Linux environment (code %d)." % code, "install")
        self._ensure_files_link()

    def _ensure_files_link(self):
        # the PC file backup of the File Manager lives in the shared folder (visible in Finder)
        cmd = ("set -e; m=$HOME/.local/share/FlipperOneDemoFiles; s=%s/FlipperOneDemoFiles; mkdir -p \"$s\" $HOME/.local/share; "
               "if [ -d \"$m\" ] && [ ! -L \"$m\" ]; then cp -a \"$m\"/. \"$s\"/ 2>/dev/null || true; rm -rf \"$m\"; fi; "
               "[ -L \"$m\" ] || ln -s \"$s\" \"$m\"") % VM_SHARE
        self.ssh(cmd, timeout=120)

    # ------------------------------------------------------------ actions
    def action_command(self, action, pidfile="/tmp/flipper-mac-action.pid"):
        inner = "echo $$ > %s; exec env %s %s %s" % (pidfile, self.remote_env(), shlex.quote(VM_LAUNCHER), shlex.quote(action))
        return self.ssh_base() + ["--", "setsid bash -c %s 2>&1" % shlex.quote(inner)]

    # The administrator helper runs through sudo in its own session, so stopping the
    # action's process group does not reach it: it is stopped separately (it cleans up
    # its mounts and gives the image back when it gets TERM).
    HELPER_STOP = ("if pgrep -f 'flipper-emulator/[f]lipper-root' >/dev/null 2>&1; then "
                   "echo 'Stopping an unfinished helper step ...'; "
                   "sudo -n pkill -TERM -f 'flipper-emulator/[f]lipper-root' 2>/dev/null; "
                   "for i in 1 2 3 4 5 6 7 8 9 10; do pgrep -f 'flipper-emulator/[f]lipper-root' >/dev/null 2>&1 || break; sleep 1; done; "
                   "sudo -n pkill -KILL -f 'flipper-emulator/[f]lipper-root' 2>/dev/null; fi; ")

    def cancel_action(self, pidfile="/tmp/flipper-mac-action.pid"):
        self.ssh("p=$(cat %s 2>/dev/null); [ -n \"$p\" ] && kill -TERM -- -$p 2>/dev/null; sleep 1; "
                 "[ -n \"$p\" ] && kill -KILL -- -$p 2>/dev/null; rm -f %s; %s true" % (pidfile, pidfile, self.HELPER_STOP), timeout=60)

    def stop_leftovers(self, pidfile="/tmp/flipper-mac-action.pid"):
        """An action of an earlier run of the app can still be working inside the VM (the app
        was closed, the Mac slept, the connection dropped). Two actions at the same time get in
        each other's way (for example both want the Flipper OS image), so it is stopped first.
        Running emulators are not touched (they run in their own sessions)."""
        code, out = self.ssh("p=$(cat %s 2>/dev/null); if [ -n \"$p\" ] && kill -0 -- -$p 2>/dev/null; then "
                             "echo 'An earlier action is still working inside the Linux environment - stopping it first ...'; "
                             "kill -TERM -- -$p 2>/dev/null; sleep 2; kill -KILL -- -$p 2>/dev/null; fi; rm -f %s; %s true"
                             % (pidfile, pidfile, self.HELPER_STOP), timeout=90)
        for line in out.strip().splitlines():
            if line.strip():
                self.log(line.strip())

    def restart(self):
        """Restarts the private Linux environment (frees everything that hangs inside it)."""
        self.stop_tunnel()
        self.log("Restarting the private Linux environment once (about a minute) ...")
        code, out = self.mp("restart", NAME, timeout=600)
        if code != 0:
            self.mp("stop", NAME, timeout=300)
            self.mp("start", NAME, timeout=600, check=True)
        self.ensure()

    def status(self):
        code, out = self.ssh("env %s %s status-json" % (self.remote_env(), VM_LAUNCHER), timeout=60)
        for line in reversed(out.strip().splitlines()):
            line = line.strip()
            if line.startswith("{"):
                return json.loads(line)
        raise VmError("No status: " + out.strip()[-200:])

    def cli(self, *args, timeout=120):
        return self.ssh("env %s %s %s" % (self.remote_env(), VM_LAUNCHER, " ".join(shlex.quote(a) for a in args)), timeout=timeout)

    # ------------------------------------------------------------ port forwarding
    def tunnel_alive(self):
        try:
            pid, ip = open(TUNNEL_PID).read().split()
            pid = int(pid)
            os.kill(pid, 0)
            cmd = subprocess.run(["ps", "-p", str(pid), "-o", "command="], stdout=subprocess.PIPE).stdout.decode()
            return ("ssh" in cmd and " -N " in cmd and KEY in cmd), ip
        except Exception:
            return False, None

    def ensure_tunnel(self):
        ip = self.ip()
        if not ip:
            return False
        alive, old_ip = self.tunnel_alive()
        if alive and old_ip == ip:
            return True
        if alive:
            self.stop_tunnel()
        a = self.ssh_base(ip)[:-1] + ["-N", "-o", "ExitOnForwardFailure=no", "-o", "ServerAliveCountMax=3"]
        for port in PORTS:
            a += ["-L", "%s:%d:127.0.0.1:%d" % (TUNNEL_BIND, port, port)]
        a.append(VM_USER + "@" + ip)
        p = subprocess.Popen(a, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             start_new_session=True)
        with open(TUNNEL_PID, "w") as f:
            f.write("%d %s\n" % (p.pid, ip))
        time.sleep(1.0)
        return p.poll() is None

    def stop_tunnel(self):
        alive, _ = self.tunnel_alive()
        if alive:
            try:
                pid = int(open(TUNNEL_PID).read().split()[0])
                os.kill(pid, signal.SIGTERM)
            except Exception:
                pass
        try:
            os.remove(TUNNEL_PID)
        except OSError:
            pass

    # ------------------------------------------------------------ removal
    def delete(self):
        self.stop_tunnel()
        if multipass() and self.state() != "Missing":
            self.log("Deleting the private Linux environment ...")
            self.mp("delete", "--purge", NAME, timeout=900)
